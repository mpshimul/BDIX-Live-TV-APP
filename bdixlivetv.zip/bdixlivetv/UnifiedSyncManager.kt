package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Log
import androidx.compose.runtime.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File

/**
 * UnifiedSyncManager - Merges all LaunchedEffect loops into one
 * Improvements:
 * - Single loop instead of 3 separate infinite loops
 * - Better battery usage
 * - No race conditions between loops
 * - Consolidated timing logic
 */
@Composable
fun UnifiedSyncManager(
    context: Context,
    allChannels: List<Channel>,
    // ✅ REMOVED: githubTokenAvailable parameter - now checking token directly
    onCacheAgeChanged: (Long) -> Unit,
    onSyncStatusChanged: (String) -> Unit,
    onBackgroundSyncTriggered: (username: String?, password: String?) -> Unit,
    onAutoRefreshTriggered: () -> Unit,
    onSportsDataUpdated: () -> Unit  // New callback for sports data updates
) {
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        var lastCacheCheck = 0L
        var lastGithubSyncCheck = 0L
        var lastAutoRefreshCheck = 0L
        var lastMoviesCheck = 0L
        var lastSeriesCheck = 0L
        var lastSportsCheck = 0L
        var cacheAgeMinutes = 0L
        var backgroundSyncing = false
        var lastSyncTime = 0L

        Log.d("UnifiedSyncManager", "🚀 Starting unified sync manager")

        // Load last sync time from log
        try {
            val syncLogFile = File(context.filesDir, "github_sync_log.json")
            if (syncLogFile.exists()) {
                val log = JSONObject(syncLogFile.readText())
                lastSyncTime = log.optLong("last_sync_time", 0)
                Log.d("UnifiedSyncManager", "📂 Loaded last sync time: ${lastSyncTime}")
            }
        } catch (e: Exception) {
            Log.e("UnifiedSyncManager", "Error loading sync log: ${e.message}")
        }

        while (isActive) {
            try {
                val now = System.currentTimeMillis()

                // ========== TASK 1: Cache age check (every 10 seconds) ==========
                if (now - lastCacheCheck >= SyncConfig.CACHE_AGE_UPDATE_INTERVAL_MS) {
                    lastCacheCheck = now
                    val cacheFile = File(context.filesDir, "all_channels_cache.json")
                    if (cacheFile.exists()) {
                        cacheAgeMinutes = (now - cacheFile.lastModified()) / (60 * 1000)
                        onCacheAgeChanged(cacheAgeMinutes)
                        Log.d("UnifiedSyncManager", "📊 Cache age: ${cacheAgeMinutes}m")
                    } else {
                        onCacheAgeChanged(0L)
                    }
                }

                // ========== TASK 2: GitHub sync check (every 5 minutes) ==========
                if (now - lastGithubSyncCheck >= SyncConfig.GITHUB_SYNC_CHECK_INTERVAL_MS) {
                    lastGithubSyncCheck = now

                    // ✅ FIX: Check GitHub token availability directly instead of relying on removed parameter
                    val firebaseManager = FirebaseManager(context)
                    val token = firebaseManager.getGitHubToken()
                    val tokenAvailable = token.isNotEmpty()

                    if (tokenAvailable && !backgroundSyncing) {
                        // Initialize GitHubDataManager if needed
                        if (!GitHubDataManager.isInitialized()) {
                            GitHubDataManager.initialize(token)
                        }

                        val shouldSync = GitHubDataManager.shouldRunSync(context)

                        if (shouldSync) {
                            Log.d("UnifiedSyncManager", "🔄 Triggering GitHub sync...")
                            backgroundSyncing = true
                            onSyncStatusChanged("🔄 Checking GitHub data...")

                            scope.launch(Dispatchers.IO) {
                                try {
                                    val result = GitHubDataManager.checkAndSyncData(context)

                                    onSyncStatusChanged(when (result) {
                                        is GitHubDataManager.SyncResult.NoToken -> "⚠️ No GitHub token"
                                        is GitHubDataManager.SyncResult.Downloaded ->
                                                "✅ Using GitHub data (${result.ageMinutes}m old)"
                                            is GitHubDataManager.SyncResult.ScrapedAndUploaded ->
                                                "✅ Fresh data scraped & uploaded (${result.channelCount} channels)"
                                            is GitHubDataManager.SyncResult.ScrapedOnly ->
                                                "✅ Fresh data scraped (${result.channelCount} channels)"
                                            is GitHubDataManager.SyncResult.ScrapingFailed ->
                                                "❌ Scraping failed"
                                            is GitHubDataManager.SyncResult.Error ->
                                                "⚠️ Sync error: ${result.message}"
                                        })

                                    lastSyncTime = now
                                    saveSyncLog(context, result)
                                } catch (e: Exception) {
                                    onSyncStatusChanged("❌ Sync error: ${e.message}")
                                    Log.e("UnifiedSyncManager", "Sync error: ${e.message}")
                                } finally {
                                    backgroundSyncing = false
                                }
                            }
                        } else {
                            Log.d("UnifiedSyncManager", "⏭ Skipping GitHub sync (shouldSync=$shouldSync, backgroundSyncing=$backgroundSyncing)")
                        }
                    } else {
                        Log.d("UnifiedSyncManager", "⏭ Skipping GitHub sync (no GitHub token)")
                    }
                }

                // ========== TASK 3: Auto-refresh check (every 30 seconds) ==========
                if (now - lastAutoRefreshCheck >= SyncConfig.BACKGROUND_REFRESH_CHECK_INTERVAL_MS) {
                    lastAutoRefreshCheck = now

                    if (allChannels.isNotEmpty()) {
                        val cacheIsOld = ChannelCacheManager.isCacheOlderThan(
                            context = context,
                            minutes = SyncConfig.getChannelCacheExpiryMinutes()
                        )

                        if (cacheIsOld) {
                            Log.d("UnifiedSyncManager", "🔄 Cache is old, triggering auto-refresh...")
                            onAutoRefreshTriggered()

                            val firebaseManager = FirebaseManager(context)
                            val username = firebaseManager.getAynaUsername()
                            val password = firebaseManager.getAynaPassword()

                            onBackgroundSyncTriggered(username, password)
                        } else {
                            Log.d("UnifiedSyncManager", "✅ Cache is fresh (${cacheAgeMinutes}m old)")
                        }
                    }
                }

                // ========== TASK 4: Movies data freshness check (every 5 minutes) ==========
                if (now - lastMoviesCheck >= SyncConfig.GITHUB_SYNC_CHECK_INTERVAL_MS) {
                    lastMoviesCheck = now

                    // ✅ FIX: Check GitHub token availability directly instead of relying on stale parameter
                    val firebaseManager = FirebaseManager(context)
                    val token = firebaseManager.getGitHubToken()
                    val tokenAvailable = token.isNotEmpty()

                    if (tokenAvailable) {
                        // Initialize GitHubDataManager if needed
                        if (!GitHubDataManager.isInitialized()) {
                            GitHubDataManager.initialize(token)
                        }

                        Log.d("UnifiedSyncManager", "📽 Checking movie data freshness...")
                        val isMovieFresh = GitHubDataManager.isMovieDataFresh()
                        Log.d("UnifiedSyncManager", "📽 Movie fresh: $isMovieFresh (threshold: ${SyncConfig.MOVIE_FRESHNESS_THRESHOLD_MINUTES}m)")

                        if (!isMovieFresh) {
                            Log.d("UnifiedSyncManager", "🎬 Movie data is old, triggering sync...")
                            onSyncStatusChanged("🔄 Syncing movies...")

                            scope.launch(Dispatchers.IO) {
                                try {
                                    val result = MovieSyncService.syncMovies(context)
                                    onSyncStatusChanged(when (result) {
                                        is MovieSyncService.SyncResult.NoToken -> "⚠️ No GitHub token"
                                        is MovieSyncService.SyncResult.GitHubDownload -> "✅ Downloaded ${result.count} movies"
                                        is MovieSyncService.SyncResult.ScrapedAndUploaded -> "✅ Synced & uploaded ${result.count} movies"
                                        is MovieSyncService.SyncResult.ScrapedOnly -> "✅ Synced ${result.count} movies"
                                        is MovieSyncService.SyncResult.ScrapingFailed -> "❌ Movie sync failed"
                                        is MovieSyncService.SyncResult.Error -> "⚠️ Movie sync error"
                                    })
                                } catch (e: Exception) {
                                    onSyncStatusChanged("❌ Movie sync error")
                                    Log.e("UnifiedSyncManager", "Movie sync error: ${e.message}")
                                }
                            }
                        } else {
                            Log.d("UnifiedSyncManager", "✅ Movie data is fresh (${SyncConfig.MOVIE_FRESHNESS_THRESHOLD_MINUTES}m threshold)")
                        }
                    } else {
                        Log.d("UnifiedSyncManager", "⏭ Skipping movie check (no GitHub token)")
                    }
                }

                // ========== TASK 5: Series data freshness check (every 5 minutes) ==========
                if (now - lastSeriesCheck >= SyncConfig.GITHUB_SYNC_CHECK_INTERVAL_MS) {
                    lastSeriesCheck = now

                    // ✅ FIX: Check GitHub token availability directly instead of relying on stale parameter
                    val firebaseManager = FirebaseManager(context)
                    val token = firebaseManager.getGitHubToken()
                    val tokenAvailable = token.isNotEmpty()

                    if (tokenAvailable) {
                        // Initialize GitHubDataManager if needed
                        if (!GitHubDataManager.isInitialized()) {
                            GitHubDataManager.initialize(token)
                        }

                        Log.d("UnifiedSyncManager", "📺 Checking series data freshness...")
                        val isSeriesFresh = GitHubDataManager.isSeriesDataFresh()
                        Log.d("UnifiedSyncManager", "📺 Series fresh: $isSeriesFresh (threshold: ${SyncConfig.SERIES_FRESHNESS_THRESHOLD_MINUTES}m)")

                        if (!isSeriesFresh) {
                            Log.d("UnifiedSyncManager", "📺 Series data is old, triggering sync...")
                            onSyncStatusChanged("🔄 Syncing series...")

                            scope.launch(Dispatchers.IO) {
                                try {
                                    val result = SeriesSyncService.syncSeries(context)
                                    onSyncStatusChanged(when (result) {
                                        is SeriesSyncService.SyncResult.NoToken -> "⚠️ No GitHub token"
                                        is SeriesSyncService.SyncResult.GitHubDownload -> "✅ Downloaded ${result.count} series"
                                        is SeriesSyncService.SyncResult.ScrapedAndUploaded -> "✅ Synced & uploaded ${result.count} series"
                                        is SeriesSyncService.SyncResult.ScrapedOnly -> "✅ Synced ${result.count} series"
                                        is SeriesSyncService.SyncResult.ScrapingFailed -> "❌ Series sync failed"
                                        is SeriesSyncService.SyncResult.Error -> "⚠️ Series sync error"
                                    })
                                } catch (e: Exception) {
                                    onSyncStatusChanged("❌ Series sync error")
                                    Log.e("UnifiedSyncManager", "Series sync error: ${e.message}")
                                }
                            }
                        } else {
                            Log.d("UnifiedSyncManager", "✅ Series data is fresh (${SyncConfig.SERIES_FRESHNESS_THRESHOLD_MINUTES}m threshold)")
                        }
                    } else {
                        Log.d("UnifiedSyncManager", "⏭ Skipping series check (no GitHub token)")
                    }
                }

                // ========== TASK 6: Sports data sync check (every 10 minutes) ==========
                if (now - lastSportsCheck >= SyncConfig.SPORTS_SYNC_CHECK_INTERVAL_MS) {
                    lastSportsCheck = now

                    Log.d("UnifiedSyncManager", "⚽ Checking sports data...")

                    scope.launch(Dispatchers.IO) {
                        try {
                            val sportsService = com.shimulfp.bdixlivetv.SportsService
                            val shouldSync = sportsService.shouldSync(context)

                            if (shouldSync) {
                                Log.d("UnifiedSyncManager", "🔄 Sports data needs refresh, triggering sync...")
                                onSyncStatusChanged("🔄 Syncing sports events...")

                                val data = sportsService.refreshSportsData(context)

                                if (data != null) {
                                    val liveCount = data.getLiveEvents().size
                                    val upcomingCount = data.getUpcomingEvents().size
                                    
                                    onSyncStatusChanged(
                                        when {
                                            data.hasEvents() -> "✅ Sports: $liveCount live, $upcomingCount upcoming"
                                            else -> "✅ Sports data updated (no events)"
                                        }
                                    )
                                    
                                    // Notify UI to update sports section
                                    onSportsDataUpdated()
                                } else {
                                    onSyncStatusChanged("⚠️ Sports refresh failed")
                                }
                            } else {
                                val status = sportsService.getCacheStatus(context)
                                when (status) {
                                    is CacheStatus.Available -> {
                                        val liveCount = status.liveCount
                                        val upcomingCount = status.upcomingCount
                                        Log.d("UnifiedSyncManager", "✅ Sports data is fresh: $liveCount live, $upcomingCount upcoming (${status.ageMinutes}m old)")
                                    }
                                    is CacheStatus.NotAvailable -> {
                                        Log.d("UnifiedSyncManager", "⏭ No sports cache available")
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            onSyncStatusChanged("❌ Sports sync error: ${e.message}")
                            Log.e("UnifiedSyncManager", "Sports sync error: ${e.message}")
                        }
                    }
                }

                // ========== SLEEP: Wait for 5 seconds (minimum of all intervals) ==========
                delay(5_000)

            } catch (e: Exception) {
                Log.e("UnifiedSyncManager", "Error in sync loop: ${e.message}", e)
                delay(10_000) // Longer delay on error
            }
        }
    }
}

/**
 * Save sync log after successful sync
 */
private fun saveSyncLog(context: Context, result: GitHubDataManager.SyncResult) {
    try {
        val syncLogFile = File(context.filesDir, "github_sync_log.json")

        val syncData = JSONObject().apply {
            put("last_sync_time", System.currentTimeMillis())
            put("timestamp", System.currentTimeMillis())
            put("last_sync_date", java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date()))

            val resultType = when (result) {
                is GitHubDataManager.SyncResult.Downloaded -> "downloaded"
                is GitHubDataManager.SyncResult.ScrapedAndUploaded -> "scraped_and_uploaded"
                is GitHubDataManager.SyncResult.ScrapedOnly -> "scraped_only"
                is GitHubDataManager.SyncResult.ScrapingFailed -> "scraping_failed"
                is GitHubDataManager.SyncResult.Error -> "error"
                is GitHubDataManager.SyncResult.NoToken -> "no_token"
                else -> "unknown"
            }
            put("last_sync_result", resultType)

            when (result) {
                is GitHubDataManager.SyncResult.Downloaded -> {
                    put("age_minutes", result.ageMinutes)
                    put("message", "Downloaded fresh data from GitHub")
                }
                is GitHubDataManager.SyncResult.ScrapedAndUploaded -> {
                    put("channel_count", result.channelCount)
                    put("message", "Scraped fresh data and uploaded to GitHub")
                }
                is GitHubDataManager.SyncResult.ScrapedOnly -> {
                    put("channel_count", result.channelCount)
                    put("message", "Scraped fresh data (upload failed)")
                }
                is GitHubDataManager.SyncResult.Error -> {
                    put("error_message", result.message)
                    put("message", "Error during sync")
                }
                is GitHubDataManager.SyncResult.NoToken -> {
                    put("message", "No GitHub token available")
                }
                else -> {
                    put("message", "Unknown sync result")
                }
            }
        }

        syncLogFile.writeText(syncData.toString())
        Log.d("UnifiedSyncManager", "✅ Sync log saved")
    } catch (e: Exception) {
        Log.e("UnifiedSyncManager", "❌ Error saving sync log: ${e.message}")
    }
}

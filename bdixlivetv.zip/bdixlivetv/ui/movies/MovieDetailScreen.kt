package com.shimulfp.bdixlivetv.ui.movies

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.models.StreamUrl

@Composable
fun MovieDetailScreen(
    movie: Movie,
    isFavorite: Boolean,
    relatedMovies: List<Movie> = emptyList(),
    onPlayClick: (StreamUrl) -> Unit,
    onBackClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    onRelatedMovieClick: (Movie) -> Unit
) {
    var selectedServer by remember { mutableStateOf(movie.streamUrls.firstOrNull()) }
    var showServerDialog by remember { mutableStateOf(false) }

    // Focus states for TV navigation
    var backButtonFocused by remember { mutableStateOf(false) }
    var playButtonFocused by remember { mutableStateOf(false) }
    var serverButtonFocused by remember { mutableStateOf(false) }
    var favoriteButtonFocused by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // Hero Section
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp)
            ) {
                // Backdrop/Poster
                if (!movie.poster.isNullOrEmpty()) {
                    AsyncImage(
                        model = movie.poster,
                        contentDescription = movie.title ?: "Movie poster",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                // Gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0xFF0A0A0A).copy(alpha = 0.7f),
                                    Color(0xFF0A0A0A)
                                )
                            )
                        )
                )

                // Back button - TV OPTIMIZED
                val backScale by animateFloatAsState(
                    targetValue = if (backButtonFocused) 1.2f else 1f,
                    animationSpec = tween(150),
                    label = "backScale"
                )

                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .padding(16.dp)
                        .align(Alignment.TopStart)
                        .scale(backScale)
                        .background(
                            if (backButtonFocused) Color.Red else Color.Black.copy(alpha = 0.5f),
                            CircleShape
                        )
                        .size(56.dp)
                        .onFocusChanged { backButtonFocused = it.hasFocus || it.isFocused }
                        .focusable(true)
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        "Back",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Content
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp)
                    .offset(y = (-80).dp)
            ) {
                // Title
                Text(
                    text = movie.title ?: "Unknown Movie",
                    color = Color.White,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Meta info
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!movie.year.isNullOrEmpty()) {
                        InfoChip(text = movie.year, color = Color.White)
                    }
                    InfoChip(text = movie.quality ?: "HD", color = Color.Green)
                    InfoChip(text = movie.language ?: "Unknown", color = Color.Cyan)
                    if (!movie.rating.isNullOrEmpty()) {
                        InfoChip(text = "⭐ ${movie.rating}", color = Color.Yellow)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Genres
                if (!movie.genres.isNullOrEmpty()) {
                    Text(
                        text = movie.genres.joinToString(" • "),
                        color = Color.Gray,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Description
                if (!movie.description.isNullOrEmpty()) {
                    Text(
                        text = movie.description,
                        color = Color.LightGray,
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                }

                // Action buttons - TV OPTIMIZED
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Play button
                    val playScale by animateFloatAsState(
                        targetValue = if (playButtonFocused) 1.08f else 1f,
                        label = "playScale"
                    )

                    Button(
                        onClick = { selectedServer?.let { onPlayClick(it) } },
                        modifier = Modifier
                            .weight(1f)
                            .height(64.dp)
                            .scale(playScale)
                            .onFocusChanged {
                                playButtonFocused = it.hasFocus || it.isFocused
                            }
                            .focusable(true),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                        enabled = selectedServer != null,
                        elevation = ButtonDefaults.buttonElevation(
                            defaultElevation = if (playButtonFocused) 8.dp else 4.dp
                        )
                    ) {
                        Icon(
                            Icons.Filled.PlayArrow,
                            null,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Play", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }

                    // Server selection
                    if (movie.streamUrls.size > 1) {
                        val serverScale by animateFloatAsState(
                            targetValue = if (serverButtonFocused) 1.08f else 1f,
                            label = "serverScale"
                        )

                        OutlinedButton(
                            onClick = { showServerDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .height(64.dp)
                                .scale(serverScale)
                                .onFocusChanged {
                                    serverButtonFocused = it.hasFocus || it.isFocused
                                }
                                .focusable(true),
                            border = BorderStroke(
                                2.dp,
                                if (serverButtonFocused) Color.Red else Color.White
                            ),
                            elevation = ButtonDefaults.buttonElevation(
                                defaultElevation = if (serverButtonFocused) 8.dp else 0.dp
                            )
                        ) {
                            Icon(
                                Icons.Filled.Dns,
                                null,
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                selectedServer?.server ?: "Server",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Favorite button
                    val favScale by animateFloatAsState(
                        targetValue = if (favoriteButtonFocused) 1.15f else 1f,
                        label = "favScale"
                    )

                    OutlinedButton(
                        onClick = onFavoriteClick,
                        modifier = Modifier
                            .height(64.dp)
                            .scale(favScale)
                            .onFocusChanged {
                                favoriteButtonFocused = it.hasFocus || it.isFocused
                            }
                            .focusable(true),
                        border = BorderStroke(
                            2.dp,
                            if (isFavorite) Color.Red else if (favoriteButtonFocused) Color.Red else Color.White
                        ),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isFavorite) Color.Red.copy(alpha = 0.2f) else Color.Transparent
                        )
                    ) {
                        Icon(
                            if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            null,
                            tint = if (isFavorite) Color.Red else Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                // Available Servers Section
                Text(
                    "Available Servers",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))

                movie.streamUrls.forEach { stream ->
                    ServerItem(
                        streamUrl = stream,
                        isSelected = stream == selectedServer,
                        onClick = { selectedServer = stream }
                    )
                }

                // Additional info
                if (!movie.duration.isNullOrEmpty() || !movie.director.isNullOrEmpty() || !movie.cast.isNullOrEmpty()) {
                    Spacer(modifier = Modifier.height(32.dp))

                    Column(
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        if (!movie.duration.isNullOrEmpty()) {
                            InfoRow("Duration", movie.duration)
                        }
                        if (!movie.director.isNullOrEmpty()) {
                            InfoRow("Director", movie.director)
                        }
                        if (!movie.cast.isNullOrEmpty()) {
                            InfoRow("Cast", movie.cast.take(3).joinToString(", "))
                        }
                        if (!movie.audioInfo.isNullOrEmpty()) {
                            InfoRow("Audio", movie.audioInfo)
                        }
                        if (!movie.codec.isNullOrEmpty()) {
                            InfoRow("Codec", movie.codec)
                        }
                    }
                }

                // Related movies
                if (relatedMovies.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(40.dp))

                    Text(
                        "Related Movies",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(relatedMovies) { related ->
                            MovieCard(
                                movie = related,
                                onClick = { onRelatedMovieClick(related) },
                                modifier = Modifier.width(140.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }

    // Server dialog - TV OPTIMIZED
    if (showServerDialog) {
        AlertDialog(
            onDismissRequest = { showServerDialog = false },
            title = {
                Text(
                    "Select Server",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    movie.streamUrls.forEachIndexed { index, stream ->
                        var itemFocused by remember { mutableStateOf(false) }

                        val itemScale by animateFloatAsState(
                            targetValue = if (itemFocused) 1.05f else 1f,
                            label = "itemScale"
                        )

                        Card(
                            onClick = {
                                selectedServer = stream
                                showServerDialog = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .scale(itemScale)
                                .onFocusChanged {
                                    itemFocused = it.hasFocus || it.isFocused
                                }
                                .focusable(true),
                            colors = CardDefaults.cardColors(
                                containerColor = when {
                                    stream == selectedServer -> Color.Red.copy(alpha = 0.3f)
                                    itemFocused -> Color(0xFF3A3A3A)
                                    else -> Color(0xFF2A2A2A)
                                }
                            ),
                            border = if (itemFocused) BorderStroke(2.dp, Color.Red) else null,
                            elevation = CardDefaults.cardElevation(
                                defaultElevation = if (itemFocused) 6.dp else 2.dp
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (stream == selectedServer) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                                    null,
                                    tint = if (stream == selectedServer) Color.Red else Color.Gray,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "Server ${index + 1}",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                    if (!stream.server.isNullOrEmpty()) {
                                        Text(
                                            stream.server,
                                            color = Color.Gray,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Text(
                                        stream.quality ?: "HD",
                                        color = Color.Cyan,
                                        fontSize = 12.sp
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .background(
                                            if (stream.isWorking) Color.Green else Color.Red,
                                            CircleShape
                                        )
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                var closeFocused by remember { mutableStateOf(false) }

                val closeScale by animateFloatAsState(
                    targetValue = if (closeFocused) 1.1f else 1f,
                    label = "closeScale"
                )

                TextButton(
                    onClick = { showServerDialog = false },
                    modifier = Modifier
                        .scale(closeScale)
                        .onFocusChanged { closeFocused = it.hasFocus || it.isFocused }
                        .focusable(true)
                ) {
                    Text("Close", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF1A1A1A),
            tonalElevation = 8.dp
        )
    }
}

@Composable
private fun ServerItem(
    streamUrl: StreamUrl,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.03f else 1f,
        label = "serverItemScale"
    )

    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .scale(scale)
            .onFocusChanged { isFocused = it.hasFocus || it.isFocused }
            .focusable(true),
        colors = CardDefaults.cardColors(
            containerColor = when {
                isSelected -> Color.Red.copy(alpha = 0.2f)
                isFocused -> Color(0xFF2A2A2A)
                else -> Color(0xFF1A1A1A)
            }
        ),
        border = when {
            isSelected && isFocused -> BorderStroke(2.dp, Color.Red)
            isSelected -> BorderStroke(1.dp, Color.Red)
            isFocused -> BorderStroke(2.dp, Color.White)
            else -> null
        },
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isFocused) 6.dp else 2.dp
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                null,
                tint = if (isSelected) Color.Red else Color.Gray,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    streamUrl.server ?: "Unknown Server",
                    color = Color.White,
                    fontWeight = if (isFocused || isSelected) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 16.sp
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        streamUrl.quality ?: "HD",
                        color = if (isFocused) Color.Green else Color.Gray,
                        fontSize = 14.sp
                    )
                    if (!streamUrl.fileName.isNullOrEmpty()) {
                        Text("•", color = Color.Gray, fontSize = 12.sp)
                        Text(
                            streamUrl.fileName.take(40) + if (streamUrl.fileName.length > 40) "..." else "",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(
                        if (streamUrl.isWorking) Color.Green else Color.Red,
                        CircleShape
                    )
            )
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "$label:",
            color = Color.Gray,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(100.dp)
        )
        Text(
            text = value,
            color = Color.LightGray,
            fontSize = 15.sp,
            modifier = Modifier.weight(1f)
        )
    }
}
package com.shimulfp.bdixlivetv.ui.movies

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.models.MovieCategory

// ============ SUPER VISIBLE TV-OPTIMIZED MOVIE CARD ============

@Composable
fun MovieCard(
    movie: Movie,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    showProgress: Boolean = false,
    isFavorite: Boolean = false,
    modifier: Modifier = Modifier
) {
    var isFocused by remember { mutableStateOf(false) }

    // ENHANCED: Bigger scale for better visibility
    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.2f else 1f,  // Increased from 1.15f
        animationSpec = tween(durationMillis = 200),
        label = "scale"
    )

    // ENHANCED: Much higher elevation
    val elevation by animateFloatAsState(
        targetValue = if (isFocused) 16f else 2f,  // Increased from 12f
        animationSpec = tween(durationMillis = 200),
        label = "elevation"
    )

    Column(
        modifier = modifier
            .width(140.dp)
            .scale(scale)
            .shadow(
                elevation = elevation.dp,
                shape = RoundedCornerShape(12.dp),
                spotColor = if (isFocused) Color.Red else Color.Black  // Red shadow when focused
            )
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (isFocused) Color(0xFF2A0000) else Color(0xFF1E1E1E)  // Dark red bg when focused
            )
            .onFocusChanged {
                isFocused = it.hasFocus || it.isFocused
            }
            .focusable(true)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { onClick() }
    ) {
        // Poster
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(Color(0xFF0A0A0A))
                // CRITICAL: THICK VISIBLE BORDER - 6dp red border when focused!
                .border(
                    width = if (isFocused) 6.dp else 0.dp,  // Increased from 4dp
                    color = if (isFocused) Color(0xFFFF0000) else Color.Transparent,  // Bright red
                    shape = RoundedCornerShape(12.dp)
                )
        ) {
            // Movie poster
            if (!movie.poster.isNullOrEmpty()) {
                AsyncImage(
                    model = movie.poster,
                    contentDescription = movie.title ?: "Movie poster",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                // Placeholder
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Filled.Movie,
                            contentDescription = null,
                            tint = if (isFocused) Color.White else Color.Gray,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = (movie.title ?: "Unknown").take(15),
                            color = if (isFocused) Color.White else Color.Gray,
                            fontSize = 12.sp,
                            fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal,
                            textAlign = TextAlign.Center,
                            maxLines = 2
                        )
                    }
                }
            }

            // ENHANCED: Brighter gradient overlay when focused
            if (isFocused) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.Black.copy(alpha = 0.8f)  // Darker for contrast
                                )
                            )
                        )
                )
            }

            // Quality badge - BRIGHTER when focused
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .background(
                        if (isFocused) Color(movie.getQualityBadgeColor()).copy(alpha = 1f)
                        else Color(movie.getQualityBadgeColor()).copy(alpha = 0.8f),
                        RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = movie.quality ?: "HD",
                    color = Color.White,
                    fontSize = if (isFocused) 11.sp else 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Favorite indicator - BIGGER when focused
            if (isFavorite) {
                Icon(
                    Icons.Filled.Favorite,
                    contentDescription = "Favorite",
                    tint = Color.Red,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .size(if (isFocused) 24.dp else 16.dp)
                )
            }

            // Year badge
            if (!movie.year.isNullOrEmpty()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                        .background(
                            if (isFocused) Color(0xCC000000) else Color.Black.copy(alpha = 0.7f),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = movie.year,
                        color = Color.White,
                        fontSize = if (isFocused) 12.sp else 10.sp,
                        fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }

            // ENHANCED: MUCH MORE VISIBLE play overlay
            if (isFocused) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.6f)),  // Darker overlay
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // GLOWING play icon effect
                        Box(
                            modifier = Modifier
                                .size(80.dp)  // Bigger
                                .background(Color.Red.copy(alpha = 0.3f), CircleShape)
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Filled.PlayCircle,
                                contentDescription = "Play",
                                tint = Color.White,
                                modifier = Modifier.size(64.dp)  // Much bigger
                            )
                        }
                        Text(
                            text = "▶ PLAY",
                            color = Color.White,
                            fontSize = 16.sp,  // Bigger text
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp
                        )
                    }
                }
            }

            // Watch progress bar
            if (showProgress && movie.watchProgress > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(5.dp)  // Thicker
                        .background(Color.Gray.copy(alpha = 0.5f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(movie.watchProgress)
                            .background(Color.Red)
                    )
                }
            }
        }

        // Title - MUCH MORE VISIBLE when focused
        Text(
            text = movie.title ?: "Unknown Movie",
            color = if (isFocused) Color.White else Color(0xFFAAAAAA),  // Brighter unfocused too
            fontSize = if (isFocused) 14.sp else 12.sp,  // Bigger when focused
            fontWeight = if (isFocused) FontWeight.ExtraBold else FontWeight.Medium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .padding(horizontal = 8.dp, vertical = 8.dp)
                .background(
                    if (isFocused) Color(0xFF1A0000) else Color.Transparent,
                    RoundedCornerShape(4.dp)
                )
                .padding(horizontal = 4.dp)
        )

        // Category & Language - BRIGHTER
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
        ) {
            Text(
                text = movie.language ?: "Unknown",
                color = if (isFocused) Color(0xFF00FFFF) else Color(0xFF888888),  // Bright cyan
                fontSize = if (isFocused) 11.sp else 10.sp,
                fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal
            )
            if (!movie.serverName.isNullOrEmpty()) {
                Text(
                    text = "•",
                    color = Color.Gray,
                    fontSize = 10.sp
                )
                Text(
                    text = movie.serverName,
                    color = if (isFocused) Color.White else Color.Gray,
                    fontSize = 10.sp,
                    fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

// ============ SUPER VISIBLE MOVIE ROW ============

@Composable
fun MovieRow(
    title: String,
    movies: List<Movie>,
    onMovieClick: (Movie) -> Unit,
    onSeeAllClick: (() -> Unit)? = null,
    showProgress: Boolean = false,
    favoriteIds: Set<String> = emptySet(),
    accentColor: Color = Color.Red,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)  // More spacing
    ) {
        // Section header - BRIGHTER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 22.sp,  // Bigger
                fontWeight = FontWeight.ExtraBold  // Bolder
            )

            if (onSeeAllClick != null) {
                var seeAllFocused by remember { mutableStateOf(false) }

                val seeAllScale by animateFloatAsState(
                    targetValue = if (seeAllFocused) 1.15f else 1f,
                    label = "seeAllScale"
                )

                TextButton(
                    onClick = onSeeAllClick,
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = if (seeAllFocused) Color.White else accentColor
                    ),
                    modifier = Modifier
                        .scale(seeAllScale)
                        .onFocusChanged { seeAllFocused = it.hasFocus || it.isFocused }
                        .focusable(true)
                        .border(
                            width = if (seeAllFocused) 3.dp else 0.dp,
                            color = if (seeAllFocused) Color.Red else Color.Transparent,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .background(
                            if (seeAllFocused) Color(0xFF2A0000) else Color.Transparent,
                            RoundedCornerShape(8.dp)
                        )
                ) {
                    Text(
                        "See All",
                        fontSize = if (seeAllFocused) 16.sp else 14.sp,
                        fontWeight = if (seeAllFocused) FontWeight.Bold else FontWeight.Normal
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(if (seeAllFocused) 20.dp else 16.dp)
                    )
                }
            }
        }

        // Movie cards
        LazyRow(
            contentPadding = PaddingValues(horizontal = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp)  // More spacing between cards
        ) {
            items(movies) { movie ->
                MovieCard(
                    movie = movie,
                    onClick = { onMovieClick(movie) },
                    showProgress = showProgress,
                    isFavorite = movie.id in favoriteIds
                )
            }
        }
    }
}

// ============ SUPER VISIBLE CATEGORY CHIPS ============

@Composable
fun CategoryChips(
    selectedCategory: MovieCategory,
    onCategorySelect: (MovieCategory) -> Unit,
    movieCounts: Map<MovieCategory, Int>,
    modifier: Modifier = Modifier
) {
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)  // More spacing
    ) {
        items(MovieCategory.values().toList()) { category ->
            val isSelected = category == selectedCategory
            val count = movieCounts[category] ?: 0

            var isFocused by remember { mutableStateOf(false) }

            val scale by animateFloatAsState(
                targetValue = if (isFocused) 1.15f else 1f,  // Bigger scale
                animationSpec = tween(durationMillis = 200),
                label = "chipScale"
            )

            FilterChip(
                selected = isSelected,
                onClick = { onCategorySelect(category) },
                label = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            category.displayName,
                            fontSize = if (isFocused || isSelected) 16.sp else 14.sp,  // Bigger
                            fontWeight = if (isSelected || isFocused) FontWeight.ExtraBold else FontWeight.Normal
                        )
                        if (count > 0) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "($count)",
                                fontSize = if (isFocused) 13.sp else 11.sp,
                                color = if (isSelected) Color.White.copy(alpha = 0.9f) else Color.Gray
                            )
                        }
                    }
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color.Red,
                    selectedLabelColor = Color.White,
                    containerColor = if (isFocused) Color(0xFF2A2A2A) else Color(0xFF1A1A1A),
                    labelColor = if (isFocused) Color.White else Color.Gray
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = isSelected,
                    borderColor = if (isFocused) Color(0xFFFF0000) else Color.Transparent,  // Bright red
                    selectedBorderColor = Color.Red,
                    borderWidth = if (isFocused) 4.dp else if (isSelected) 2.dp else 1.dp  // Thick border
                ),
                modifier = Modifier
                    .scale(scale)
                    .shadow(
                        elevation = if (isFocused) 12.dp else 4.dp,
                        shape = RoundedCornerShape(8.dp),
                        spotColor = if (isFocused) Color.Red else Color.Black
                    )
                    .onFocusChanged { isFocused = it.hasFocus || it.isFocused }
                    .focusable(true)
            )
        }
    }
}

// ============ SUPER VISIBLE HERO BANNER ============

@Composable
fun MovieHeroBanner(
    movie: Movie?,
    onPlayClick: () -> Unit,
    onInfoClick: (() -> Unit)? = null
) {
    var playButtonFocused by remember { mutableStateOf(false) }
    var infoButtonFocused by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(400.dp)  // Taller
    ) {
        // Background
        if (movie?.poster?.isNotEmpty() == true) {
            AsyncImage(
                model = movie.poster,
                contentDescription = movie.title ?: "Movie poster",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(Color(0xFF1A1A2E), Color(0xFF16213E))
                        )
                    )
            )
        }

        // Gradient overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0xFF0A0A0A).copy(alpha = 0.8f),
                            Color(0xFF0A0A0A)
                        )
                    )
                )
        )

        // Content
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(32.dp)  // More padding
        ) {
            if (movie != null) {
                Text(
                    text = movie.title ?: "Unknown Movie",
                    color = Color.White,
                    fontSize = 36.sp,  // Much bigger
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Info row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!movie.year.isNullOrEmpty()) {
                        InfoChip(text = movie.year, size = "large")
                    }
                    InfoChip(text = movie.quality ?: "HD", color = Color.Green, size = "large")
                    InfoChip(text = movie.language ?: "Unknown", color = Color.Cyan, size = "large")
                    if (movie.streamUrls.isNotEmpty()) {
                        InfoChip(text = "${movie.streamUrls.size} servers", size = "large")
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Buttons - SUPER VISIBLE
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    val playScale by animateFloatAsState(
                        targetValue = if (playButtonFocused) 1.12f else 1f,
                        label = "playScale"
                    )

                    Button(
                        onClick = onPlayClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (playButtonFocused) Color(0xFFFF0000) else Color.Red
                        ),
                        modifier = Modifier
                            .scale(playScale)
                            .shadow(
                                elevation = if (playButtonFocused) 16.dp else 8.dp,
                                shape = RoundedCornerShape(12.dp),
                                spotColor = Color.Red
                            )
                            .border(
                                width = if (playButtonFocused) 4.dp else 0.dp,
                                color = if (playButtonFocused) Color.White else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .onFocusChanged { playButtonFocused = it.hasFocus || it.isFocused }
                            .focusable(true),
                        contentPadding = PaddingValues(horizontal = 40.dp, vertical = 20.dp)  // Bigger
                    ) {
                        Icon(
                            Icons.Filled.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(32.dp)  // Bigger icon
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            "Play Now",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                    }

                    if (onInfoClick != null) {
                        val infoScale by animateFloatAsState(
                            targetValue = if (infoButtonFocused) 1.12f else 1f,
                            label = "infoScale"
                        )

                        OutlinedButton(
                            onClick = onInfoClick,
                            border = BorderStroke(
                                width = if (infoButtonFocused) 4.dp else 2.dp,
                                color = if (infoButtonFocused) Color(0xFFFF0000) else Color.White
                            ),
                            modifier = Modifier
                                .scale(infoScale)
                                .shadow(
                                    elevation = if (infoButtonFocused) 16.dp else 4.dp,
                                    shape = RoundedCornerShape(12.dp),
                                    spotColor = if (infoButtonFocused) Color.Red else Color.White
                                )
                                .background(
                                    if (infoButtonFocused) Color(0xFF2A0000) else Color.Transparent,
                                    RoundedCornerShape(12.dp)
                                )
                                .onFocusChanged { infoButtonFocused = it.hasFocus || it.isFocused }
                                .focusable(true),
                            contentPadding = PaddingValues(horizontal = 36.dp, vertical = 20.dp)
                        ) {
                            Icon(
                                Icons.Filled.Info,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                "More Info",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// ============ HELPER COMPOSABLES ============

@Composable
fun InfoChip(text: String, color: Color = Color.Gray, size: String = "normal") {
    val fontSize = if (size == "large") 15.sp else 13.sp
    val padding = if (size == "large") 12.dp else 10.dp

    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
            .border(2.dp, color.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
            .padding(horizontal = padding, vertical = 8.dp)
    ) {
        Text(
            text = text,
            color = color,
            fontSize = fontSize,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun LoadingScreen(message: String = "Loading movies...") {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            CircularProgressIndicator(
                color = Color.Red,
                strokeWidth = 6.dp,  // Thicker
                modifier = Modifier.size(80.dp)  // Bigger
            )
            Text(
                message,
                color = Color.White,  // Brighter
                fontSize = 18.sp,  // Bigger
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ErrorScreen(message: String, onRetry: () -> Unit) {
    var retryButtonFocused by remember { mutableStateOf(false) }

    val retryScale by animateFloatAsState(
        targetValue = if (retryButtonFocused) 1.15f else 1f,
        label = "retryScale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Icon(
                Icons.Filled.Error,
                contentDescription = null,
                tint = Color.Red,
                modifier = Modifier.size(96.dp)  // Bigger
            )
            Text(
                "Error loading movies",
                color = Color.White,
                fontSize = 24.sp,  // Bigger
                fontWeight = FontWeight.Bold
            )
            Text(
                message,
                color = Color(0xFFAAAAAA),  // Brighter gray
                fontSize = 16.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (retryButtonFocused) Color(0xFFFF0000) else Color.Red
                ),
                modifier = Modifier
                    .scale(retryScale)
                    .shadow(
                        elevation = if (retryButtonFocused) 16.dp else 8.dp,
                        shape = RoundedCornerShape(12.dp),
                        spotColor = Color.Red
                    )
                    .border(
                        width = if (retryButtonFocused) 4.dp else 0.dp,
                        color = if (retryButtonFocused) Color.White else Color.Transparent,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .onFocusChanged { retryButtonFocused = it.hasFocus || it.isFocused }
                    .focusable(true),
                contentPadding = PaddingValues(horizontal = 48.dp, vertical = 20.dp)
            ) {
                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text("Retry", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun EmptyScreen(message: String = "No movies found") {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Icon(
                Icons.Filled.Movie,
                contentDescription = null,
                tint = Color.Gray,
                modifier = Modifier.size(96.dp)
            )
            Text(
                message,
                color = Color(0xFFAAAAAA),
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
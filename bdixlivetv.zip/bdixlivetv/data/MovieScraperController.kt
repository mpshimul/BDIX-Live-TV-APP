package com.shimulfp.bdixlivetv.data

import android.util.Log

object MovieScraperController {
    private const val TAG = "MovieScraperController"

    @Volatile
    private var shouldStopScraping = false

    @Volatile
    private var isScrapingActive = false

    /**
     * Signal to stop any ongoing scraping
     */
    fun stopAllScraping() {
        shouldStopScraping = true
        Log.d(TAG, "🛑 STOP SIGNAL SENT to all scraping processes")
    }

    /**
     * Reset stop signal (call before starting new scraping)
     */
    fun resetStopSignal() {
        shouldStopScraping = false
    }

    /**
     * Check if scraping should stop
     */
    fun shouldStopScraping(): Boolean {
        return shouldStopScraping
    }

    /**
     * Set scraping active state
     */
    fun setScrapingActive(active: Boolean) {
        isScrapingActive = active
        Log.d(TAG, "📊 Scraping active: $active")
    }

    /**
     * Check if scraping is currently active
     */
    fun isScrapingActive(): Boolean {
        return isScrapingActive
    }

    /**
     * Force stop all scraping immediately
     */
    fun emergencyStop() {
        shouldStopScraping = true
        isScrapingActive = false
        Log.w(TAG, "🚨 EMERGENCY STOP - All scraping terminated")
    }
}
package com.shimulfp.bdixlivetv.data

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.shimulfp.bdixlivetv.FirebaseManager
import com.shimulfp.bdixlivetv.GitHubDataManager
import com.shimulfp.bdixlivetv.models.Series
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

class SeriesRepository(private val context: Context) {

    private val gson = Gson()
    private val cacheFile = File(context.filesDir, "series_cache.json")
    private val favoritesFile = File(context.filesDir, "series_favorites.json")
    private val syncStatusFile = File(context.filesDir, "series_sync_status.json")
    private val stopFlagFile = File(context.filesDir, "stop_series_scraping.flag")

    private val loadMutex = Mutex()
    private val refreshMutex = Mutex()

    @Volatile
    private var isCurrentlyLoading = false
    @Volatile
    private var lastLoadTime = 0L
    @Volatile
    private var cachedSeries: List<Series>? = null

    @Volatile
    private var isScrapingInProgress = false

    companion object {
        private const val TAG = "SeriesRepository"
        private const val FRESHNESS_THRESHOLD_MINUTES = 120L
        private const val MAX_RETRY_ATTEMPTS = 3
        private const val MIN_LOAD_INTERVAL_MS = 3000L
        private const val BACKGROUND_REFRESH_DELAY_MS = 30 * 60 * 1000L

        @Volatile
        private var instance: SeriesRepository? = null
        private val instanceMutex = Mutex()

        suspend fun getInstance(context: Context): SeriesRepository {
            return instance ?: instanceMutex.withLock {
                instance ?: SeriesRepository(context.applicationContext).also {
                    Log.d(TAG, "✅ Created new SeriesRepository instance")
                    instance = it
                }
            }
        }
    }

    // ============ TOKEN MANAGEMENT ============
    private fun getGitHubToken(): String {
        return try {
            val fromGitHubManager = GitHubDataManager.getToken()
            if (fromGitHubManager.isNotEmpty()) {
                Log.d(TAG, "🔑 Got token from GitHubDataManager")
                return fromGitHubManager
            }
            val firebaseManager = FirebaseManager(context)
            val fromFirebase = firebaseManager.getGitHubToken()
            if (fromFirebase.isNotEmpty()) {
                Log.d(TAG, "🔑 Got token from Firebase")
                if (!GitHubDataManager.isInitialized()) GitHubDataManager.initialize(fromFirebase)
                return fromFirebase
            }
            val fromPrefs = tryGetTokenFromSharedPrefs()
            if (fromPrefs.isNotEmpty()) {
                Log.d(TAG, "🔑 Got token from SharedPreferences")
                return fromPrefs
            }
            Log.d(TAG, "⚠️ No GitHub token available from any source")
            ""
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting GitHub token: ${e.message}")
            ""
        }
    }

    private fun tryGetTokenFromSharedPrefs(): String {
        return try {
            val prefs = context.getSharedPreferences("github_prefs", Context.MODE_PRIVATE)
            prefs.getString("github_token", "") ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    private fun saveTokenLocally(token: String) {
        try {
            val prefs = context.getSharedPreferences("github_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString("github_token", token).apply()
            val tokenFile = File(context.filesDir, "github_token.txt")
            tokenFile.writeText(token)
            Log.d(TAG, "💾 Saved GitHub token locally")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving token locally: ${e.message}")
        }
    }

    // ============ SCRAPING CONTROL ============
    private fun createStopFlag() {
        try {
            stopFlagFile.writeText("STOP")
            Log.d(TAG, "🛑 Created stop flag for series scraper")
        } catch (e: Exception) {
            Log.e(TAG, "Error creating stop flag: ${e.message}")
        }
    }

    private fun removeStopFlag() {
        try {
            if (stopFlagFile.exists()) stopFlagFile.delete()
        } catch (e: Exception) { /* ignore */ }
    }

    private fun stopAllScraping() {
        createStopFlag()
        isScrapingInProgress = false
        Log.d(TAG, "🚨 FORCE STOPPED all series scraping processes")
    }

    // ============ MAIN LOADING FUNCTION ============
    suspend fun getSeriesSmart(): List<Series> = withContext(Dispatchers.IO) {
        Log.d(TAG, "🚀 SMART SERIES LOADING - GITHUB-FIRST")
        removeStopFlag()

        if (shouldUseCachedSeries()) {
            Log.d(TAG, "⚡ Using cached in-memory series (${cachedSeries?.size ?: 0} items)")
            return@withContext cachedSeries ?: emptyList()
        }

        val localFile = File(context.filesDir, "series_cache.json")
        if (localFile.exists() && localFile.length() > 50000) {
            Log.d(TAG, "📥 Found local GitHub cache file (${localFile.length()} bytes)")
            try {
                val content = localFile.readText()
                val series = parseSeriesFromJson(content)
                if (series.isNotEmpty()) {
                    Log.d(TAG, "✅ Loaded ${series.size} series from local GitHub cache")
                    stopAllScraping()
                    cachedSeries = series
                    lastLoadTime = System.currentTimeMillis()
                    saveSyncStatus("github_cache", series.size)
                    return@withContext series
                } else Log.w(TAG, "⚠️ Local cache file exists but parsing returned empty")
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error loading from local cache: ${e.message}")
            }
        }

        val githubToken = getGitHubToken()
        if (githubToken.isNotEmpty()) {
            Log.d(TAG, "🔑 GitHub token available, trying to download...")
            saveTokenLocally(githubToken)
            try {
                if (!GitHubDataManager.isInitialized()) GitHubDataManager.initialize(githubToken)
                val series = GitHubDataManager.downloadSeries(context)
                if (series.isNotEmpty()) {
                    Log.d(TAG, "✅ Downloaded ${series.size} series from GitHub")
                    stopAllScraping()
                    cachedSeries = series
                    lastLoadTime = System.currentTimeMillis()
                    saveToCache(series)
                    saveSyncStatus("github_download", series.size)
                    return@withContext series
                } else Log.w(TAG, "⚠️ GitHub download returned empty")
            } catch (e: Exception) {
                Log.e(TAG, "❌ GitHub download error: ${e.message}")
            }
        } else Log.d(TAG, "⚠️ No GitHub token available from any source")

        val cached = loadFromCache()
        if (cached.isNotEmpty()) {
            Log.d(TAG, "✅ Loaded ${cached.size} series from existing cache")
            stopAllScraping()
            cachedSeries = cached
            lastLoadTime = System.currentTimeMillis()
            saveSyncStatus("existing_cache", cached.size)
            return@withContext cached
        }

        Log.d(TAG, "⚠️ All other sources failed, scraping as last resort...")
        return@withContext loadMutex.withLock {
            if (cachedSeries != null && shouldUseCachedSeries()) {
                stopAllScraping()
                return@withLock cachedSeries ?: emptyList()
            }
            try {
                isCurrentlyLoading = true
                val series = scrapeFreshSeries()
                if (series.isNotEmpty()) {
                    Log.d(TAG, "✅ Scraped ${series.size} series")
                    cachedSeries = series
                    lastLoadTime = System.currentTimeMillis()
                    saveToCache(series)
                    saveSyncStatus("scraped", series.size)
                    if (githubToken.isNotEmpty()) {
                        try {
                            GitHubDataManager.initialize(githubToken)
                            GitHubDataManager.uploadSeries(context, series)
                            Log.d(TAG, "📤 Uploaded scraped series to GitHub")
                        } catch (e: Exception) {
                            Log.e(TAG, "⚠️ Failed to upload to GitHub: ${e.message}")
                        }
                    }
                    return@withLock series
                }
                return@withLock emptyList()
            } catch (e: Exception) {
                Log.e(TAG, "❌ Scraping error: ${e.message}")
                return@withLock emptyList()
            } finally {
                isCurrentlyLoading = false
            }
        }
    }

    private fun shouldUseCachedSeries(): Boolean {
        if (cachedSeries == null) return false
        val timeSinceLastLoad = System.currentTimeMillis() - lastLoadTime
        return timeSinceLastLoad < MIN_LOAD_INTERVAL_MS && cachedSeries!!.isNotEmpty()
    }

    private suspend fun scrapeFreshSeries(): List<Series> = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "🔄 Scraping fresh series from BDIX servers...")
            val series = SeriesScraper.scrapeAllSeries(context)
            Log.d(TAG, "✅ Scraped ${series.size} series")
            series
        } catch (e: Exception) {
            Log.e(TAG, "❌ Series scraping error: ${e.message}", e)
            emptyList()
        }
    }

    private fun saveToCache(series: List<Series>) {
        try {
            val json = gson.toJson(series)
            cacheFile.writeText(json)
            cacheFile.setLastModified(System.currentTimeMillis())
            Log.d(TAG, "💾 Saved ${series.size} series to cache")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving to cache: ${e.message}")
        }
    }

    private fun loadFromCache(): List<Series> {
        return try {
            if (!cacheFile.exists()) return emptyList()
            val content = cacheFile.readText()
            if (content.isEmpty()) return emptyList()
            parseSeriesFromJson(content)
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error loading from cache: ${e.message}")
            emptyList()
        }
    }

    private fun parseSeriesFromJson(json: String): List<Series> {
        return try {
            val type = object : TypeToken<List<Series>>() {}.type
            val series = gson.fromJson<List<Series>>(json, type) ?: emptyList()
            // Populate seasonNumber for episodes that don't have it (for backward compatibility)
            series.map { s ->
                s.copy(
                    seasons = s.seasons.map { season ->
                        season.copy(
                            episodes = season.episodes.map { episode ->
                                if (episode.seasonNumber == 0) {
                                    episode.copy(seasonNumber = season.seasonNumber)
                                } else episode
                            }
                        )
                    }
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ JSON parsing error: ${e.message}")
            emptyList()
        }
    }

    private fun saveSyncStatus(source: String, count: Int) {
        try {
            val status = mapOf(
                "source" to source,
                "count" to count,
                "timestamp" to System.currentTimeMillis(),
                "datetime" to java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            )
            syncStatusFile.writeText(gson.toJson(status))
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving sync status: ${e.message}")
        }
    }

    // ============ FAVORITES ============
    suspend fun getFavorites(): List<Series> = withContext(Dispatchers.IO) {
        return@withContext try {
            if (!favoritesFile.exists()) return@withContext emptyList()
            val content = favoritesFile.readText()
            val type = object : TypeToken<List<Series>>() {}.type
            gson.fromJson<List<Series>>(content, type) ?: emptyList()
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error loading favorites: ${e.message}")
            emptyList()
        }
    }

    suspend fun toggleFavorite(series: Series): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            var favorites = getFavorites().toMutableList()
            if (favorites.any { it.id == series.id }) {
                favorites.removeAll { it.id == series.id }
                Log.d(TAG, "❌ Removed from favorites: ${series.title}")
                false
            } else {
                favorites.add(series.copy(isFavorite = true))
                Log.d(TAG, "⭐ Added to favorites: ${series.title}")
                true
            }
            favoritesFile.writeText(gson.toJson(favorites))
            cachedSeries?.let { cached ->
                cachedSeries = cached.map { s ->
                    if (s.id == series.id) s.copy(isFavorite = !s.isFavorite) else s
                }
            }
            !favorites.any { it.id == series.id && !it.isFavorite }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error toggling favorite: ${e.message}")
            false
        }
    }

    suspend fun forceRefresh(): List<Series> = withContext(Dispatchers.IO) {
        refreshMutex.withLock {
            Log.d(TAG, "🔄 Force refreshing series...")
            cachedSeries = null
            lastLoadTime = 0
            val githubToken = getGitHubToken()
            if (githubToken.isNotEmpty()) {
                try {
                    if (!GitHubDataManager.isInitialized()) GitHubDataManager.initialize(githubToken)
                    val series = GitHubDataManager.downloadSeries(context)
                    if (series.isNotEmpty()) {
                        cachedSeries = series
                        lastLoadTime = System.currentTimeMillis()
                        saveToCache(series)
                        saveSyncStatus("force_github", series.size)
                        return@withLock series
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "❌ GitHub refresh failed: ${e.message}")
                }
            }
            try {
                val series = scrapeFreshSeries()
                if (series.isNotEmpty()) {
                    cachedSeries = series
                    lastLoadTime = System.currentTimeMillis()
                    saveToCache(series)
                    saveSyncStatus("force_scraped", series.size)
                    if (githubToken.isNotEmpty()) {
                        try {
                            GitHubDataManager.initialize(githubToken)
                            GitHubDataManager.uploadSeries(context, series)
                        } catch (e: Exception) {
                            Log.e(TAG, "⚠️ Failed to upload to GitHub: ${e.message}")
                        }
                    }
                    return@withLock series
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Force refresh failed: ${e.message}")
            }
            cachedSeries ?: emptyList()
        }
    }

    fun getLocalCacheAge(): Long {
        return try {
            if (cacheFile.exists()) (System.currentTimeMillis() - cacheFile.lastModified()) / (60 * 1000) else -1L
        } catch (e: Exception) {
            -1L
        }
    }

    fun isLoading(): Boolean = isCurrentlyLoading
    fun getCachedCount(): Int = cachedSeries?.size ?: 0

    suspend fun clearCache() = withContext(Dispatchers.IO) {
        try {
            cacheFile.delete()
            cachedSeries = null
            lastLoadTime = 0
            Log.d(TAG, "🧹 Cleared series cache")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error clearing cache: ${e.message}")
        }
    }
}
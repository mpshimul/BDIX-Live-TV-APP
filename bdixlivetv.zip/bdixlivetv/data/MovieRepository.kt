package com.shimulfp.bdixlivetv.data

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.shimulfp.bdixlivetv.FirebaseManager
import com.shimulfp.bdixlivetv.GitHubDataManager
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.models.MovieCategory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

class MovieRepository(private val context: Context) {

    private val gson = Gson()
    private val cacheFile = File(context.filesDir, "movies_cache.json")
    private val favoritesFile = File(context.filesDir, "movie_favorites.json")
    private val watchHistoryFile = File(context.filesDir, "movie_watch_history.json")
    private val syncStatusFile = File(context.filesDir, "movie_sync_status.json")
    private val stopFlagFile = File(context.filesDir, "stop_scraping.flag")

    private val loadMutex = Mutex()
    private val refreshMutex = Mutex()

    @Volatile
    private var isCurrentlyLoading = false
    @Volatile
    private var lastLoadTime = 0L
    @Volatile
    private var cachedMovies: List<Movie>? = null

    @Volatile
    private var isScrapingInProgress = false

    companion object {
        private const val TAG = "MovieRepository"
        private const val FRESHNESS_THRESHOLD_MINUTES = 120L
        private const val MAX_RETRY_ATTEMPTS = 3
        private const val MIN_LOAD_INTERVAL_MS = 3000L
        private const val BACKGROUND_REFRESH_DELAY_MS = 30 * 60 * 1000L

        @Volatile
        private var instance: MovieRepository? = null
        private val instanceMutex = Mutex()

        suspend fun getInstance(context: Context): MovieRepository {
            return instance ?: instanceMutex.withLock {
                instance ?: MovieRepository(context.applicationContext).also {
                    Log.d(TAG, "✅ Created new MovieRepository instance")
                    instance = it
                }
            }
        }
    }

    // ============ TOKEN MANAGEMENT ============
    private fun getGitHubToken(): String {
        return try {
            val fromGitHubManager = GitHubDataManager.getToken()
            if (fromGitHubManager.isNotEmpty()) {
                Log.d(TAG, "🔑 Got token from GitHubDataManager")
                return fromGitHubManager
            }
            val firebaseManager = FirebaseManager(context)
            val fromFirebase = firebaseManager.getGitHubToken()
            if (fromFirebase.isNotEmpty()) {
                Log.d(TAG, "🔑 Got token from Firebase")
                if (!GitHubDataManager.isInitialized()) {
                    GitHubDataManager.initialize(fromFirebase)
                }
                return fromFirebase
            }
            val fromPrefs = tryGetTokenFromSharedPrefs()
            if (fromPrefs.isNotEmpty()) {
                Log.d(TAG, "🔑 Got token from SharedPreferences")
                return fromPrefs
            }
            Log.d(TAG, "⚠️ No GitHub token available from any source")
            ""
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting GitHub token: ${e.message}")
            ""
        }
    }

    private fun tryGetTokenFromSharedPrefs(): String {
        return try {
            val prefs = context.getSharedPreferences("github_prefs", Context.MODE_PRIVATE)
            prefs.getString("github_token", "") ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    private fun saveTokenLocally(token: String) {
        try {
            val prefs = context.getSharedPreferences("github_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString("github_token", token).apply()
            val tokenFile = File(context.filesDir, "github_token.txt")
            tokenFile.writeText(token)
            Log.d(TAG, "💾 Saved GitHub token locally")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving token locally: ${e.message}")
        }
    }

    // ============ SCRAPING CONTROL ============
    private fun createStopFlag() {
        try {
            stopFlagFile.writeText("STOP")
            Log.d(TAG, "🛑 Created stop flag for Python scraper")
        } catch (e: Exception) {
            Log.e(TAG, "Error creating stop flag: ${e.message}")
        }
    }

    private fun removeStopFlag() {
        try {
            if (stopFlagFile.exists()) stopFlagFile.delete()
        } catch (e: Exception) { /* ignore */ }
    }

    private fun shouldStopScraping(): Boolean {
        return try { stopFlagFile.exists() } catch (e: Exception) { false }
    }

    private fun stopAllScraping() {
        createStopFlag()
        isScrapingInProgress = false
        Log.d(TAG, "🚨 FORCE STOPPED all scraping processes")
    }

    // ============ ULTRA-SIMPLE GITHUB-FIRST LOADING ============
    suspend fun getMoviesSmart(): List<Movie> = withContext(Dispatchers.IO) {
        Log.d(TAG, "🚀 ULTRA-SIMPLE GITHUB-FIRST LOADING")
        removeStopFlag()

        if (shouldUseCachedMovies()) {
            Log.d(TAG, "⚡ Using cached in-memory movies (${cachedMovies?.size ?: 0} items)")
            return@withContext cachedMovies ?: emptyList()
        }

        val localFile = File(context.filesDir, "movies_cache.json")
        if (localFile.exists() && localFile.length() > 100000) {
            Log.d(TAG, "📥 Found local GitHub cache file (${localFile.length()} bytes)")
            try {
                val content = localFile.readText()
                val movies = parseMoviesFromJson(content)
                if (movies.isNotEmpty()) {
                    Log.d(TAG, "✅ Loaded ${movies.size} movies from local GitHub cache")
                    stopAllScraping()
                    cachedMovies = movies
                    lastLoadTime = System.currentTimeMillis()
                    saveSyncStatus("github_cache", movies.size)
                    return@withContext movies
                } else Log.w(TAG, "⚠️ Local cache file exists but parsing returned empty")
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error loading from local cache: ${e.message}")
            }
        }

        val githubToken = getGitHubToken()
        if (githubToken.isNotEmpty()) {
            Log.d(TAG, "🔑 GitHub token available, trying to download...")
            saveTokenLocally(githubToken)
            try {
                if (!GitHubDataManager.isInitialized()) GitHubDataManager.initialize(githubToken)
                val movies = GitHubDataManager.downloadMovies(context)
                if (movies.isNotEmpty()) {
                    Log.d(TAG, "✅ Downloaded ${movies.size} movies from GitHub")
                    stopAllScraping()
                    cachedMovies = movies
                    lastLoadTime = System.currentTimeMillis()
                    saveToCache(movies)
                    saveSyncStatus("github_download", movies.size)
                    return@withContext movies
                } else Log.w(TAG, "⚠️ GitHub download returned empty")
            } catch (e: Exception) {
                Log.e(TAG, "❌ GitHub download error: ${e.message}")
            }
        } else Log.d(TAG, "⚠️ No GitHub token available from any source")

        val cached = loadFromCache()
        if (cached.isNotEmpty()) {
            Log.d(TAG, "✅ Loaded ${cached.size} movies from existing cache")
            stopAllScraping()
            cachedMovies = cached
            lastLoadTime = System.currentTimeMillis()
            saveSyncStatus("existing_cache", cached.size)
            return@withContext cached
        }

        Log.d(TAG, "⚠️ All other sources failed, scraping as last resort...")
        return@withContext loadMutex.withLock {
            if (cachedMovies != null && shouldUseCachedMovies()) {
                stopAllScraping()
                return@withLock cachedMovies ?: emptyList()
            }
            try {
                isCurrentlyLoading = true
                val movies = scrapeFreshMovies()
                if (movies.isNotEmpty()) {
                    Log.d(TAG, "✅ Scraped ${movies.size} movies")
                    cachedMovies = movies
                    lastLoadTime = System.currentTimeMillis()
                    saveToCache(movies)
                    saveSyncStatus("scraped", movies.size)
                    if (githubToken.isNotEmpty()) {
                        try {
                            GitHubDataManager.initialize(githubToken)
                            GitHubDataManager.uploadMovies(context, movies)
                            Log.d(TAG, "📤 Uploaded scraped movies to GitHub")
                        } catch (e: Exception) {
                            Log.e(TAG, "⚠️ Failed to upload to GitHub: ${e.message}")
                        }
                    }
                    return@withLock movies
                }
                return@withLock emptyList()
            } catch (e: Exception) {
                Log.e(TAG, "❌ Scraping error: ${e.message}")
                return@withLock emptyList()
            } finally {
                isCurrentlyLoading = false
            }
        }
    }

    private fun shouldUseCachedMovies(): Boolean {
        if (cachedMovies == null) return false
        val timeSinceLastLoad = System.currentTimeMillis() - lastLoadTime
        return timeSinceLastLoad < MIN_LOAD_INTERVAL_MS && cachedMovies!!.isNotEmpty()
    }

    private suspend fun tryGitHubWithRetry(githubToken: String): List<Movie> = withContext(Dispatchers.IO) {
        var attempt = 0
        while (attempt < MAX_RETRY_ATTEMPTS) {
            try {
                attempt++
                Log.d(TAG, "📥 Attempt $attempt: Trying GitHub...")
                if (!GitHubDataManager.isInitialized()) GitHubDataManager.initialize(githubToken)
                val movies = GitHubDataManager.downloadMovies(context)
                if (movies.isNotEmpty()) return@withContext movies
            } catch (e: Exception) {
                Log.e(TAG, "❌ GitHub attempt $attempt failed: ${e.message}")
                if (attempt == MAX_RETRY_ATTEMPTS) return@withContext emptyList()
                delay(1000L * attempt)
            }
        }
        return@withContext emptyList()
    }

    private suspend fun downloadMoviesFromGitHub(githubToken: String): List<Movie> = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "📥 Downloading movies from GitHub...")
            if (!GitHubDataManager.isInitialized()) GitHubDataManager.initialize(githubToken)
            val movies = GitHubDataManager.downloadMovies(context)
            if (movies.isNotEmpty()) {
                saveToCache(movies)
                Log.d(TAG, "✅ Downloaded ${movies.size} movies from GitHub")
                movies
            } else {
                Log.w(TAG, "⚠️ No movies downloaded from GitHub")
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ GitHub movie download error: ${e.message}")
            emptyList()
        }
    }

    private fun parseMoviesFromJson(jsonString: String): List<Movie> {
        return try {
            val type = object : TypeToken<List<Movie>>() {}.type
            gson.fromJson<List<Movie>>(jsonString, type) ?: emptyList()
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error parsing movies JSON: ${e.message}")
            emptyList()
        }
    }

    private fun shouldRefreshInBackground(source: String): Boolean {
        return when (source) {
            "github", "cache" -> getCacheAgeMinutes() > FRESHNESS_THRESHOLD_MINUTES
            else -> true
        }
    }

    private fun startBackgroundRefresh(githubToken: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                delay(BACKGROUND_REFRESH_DELAY_MS)
                Log.d(TAG, "🔄 Starting background refresh...")
                val movies = scrapeFreshMovies()
                if (movies.isNotEmpty()) {
                    saveToCache(movies)
                    cachedMovies = movies
                    lastLoadTime = System.currentTimeMillis()
                    if (githubToken.isNotEmpty()) {
                        try {
                            if (!GitHubDataManager.isInitialized()) GitHubDataManager.initialize(githubToken)
                            val uploaded = GitHubDataManager.uploadMovies(context, movies)
                            if (uploaded) saveSyncStatus("background_uploaded", movies.size)
                            else saveSyncStatus("background_failed", movies.size)
                        } catch (e: Exception) {
                            Log.e(TAG, "❌ Background upload error: ${e.message}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Background refresh error: ${e.message}")
            }
        }
    }

    private suspend fun scrapeFreshMovies(): List<Movie> = withContext(Dispatchers.IO) {
        return@withContext try {
            if (shouldStopScraping()) {
                Log.d(TAG, "🛑 Scraping cancelled before start")
                return@withContext emptyList()
            }
            if (isScrapingInProgress) {
                Log.d(TAG, "⚠️ Scraping already in progress, skipping")
                return@withContext emptyList()
            }
            isScrapingInProgress = true
            Log.d(TAG, "🔄 Scraping fresh movies...")
            val movies = MovieScraper.scrapeAllMovies(context)
            if (shouldStopScraping()) {
                Log.d(TAG, "🛑 Scraping results discarded")
                return@withContext emptyList()
            }
            if (movies.isNotEmpty()) saveToCache(movies)
            movies
        } catch (e: Exception) {
            Log.e(TAG, "❌ Scraping error: ${e.message}")
            emptyList()
        } finally {
            isScrapingInProgress = false
        }
    }

    // ============ PUBLIC API ============
    suspend fun getAllMovies(): List<Movie> = getMoviesSmart()
    suspend fun forceRefresh(): List<Movie> = withContext(Dispatchers.IO) {
        refreshMutex.withLock {
            Log.d(TAG, "🔄 FORCE REFRESH REQUESTED")
            removeStopFlag()
            try {
                val githubToken = getGitHubToken()
                val movies = scrapeFreshMovies()
                if (movies.isEmpty()) return@withLock emptyList()
                cachedMovies = movies
                lastLoadTime = System.currentTimeMillis()
                if (githubToken.isNotEmpty()) {
                    try {
                        if (!GitHubDataManager.isInitialized()) GitHubDataManager.initialize(githubToken)
                        val uploaded = GitHubDataManager.uploadMovies(context, movies)
                        if (uploaded) saveSyncStatus("force_refresh_uploaded", movies.size)
                        else saveSyncStatus("force_refresh_failed", movies.size)
                    } catch (e: Exception) {
                        saveSyncStatus("force_refresh_error", movies.size)
                    }
                } else saveSyncStatus("force_refresh_no_token", movies.size)
                movies
            } catch (e: Exception) {
                Log.e(TAG, "❌ Force refresh error: ${e.message}")
                emptyList()
            }
        }
    }

    suspend fun getMoviesByCategory(category: MovieCategory): List<Movie> {
        val all = getAllMovies()
        return if (category == MovieCategory.ALL) all else all.filter { it.category == category }
    }

    suspend fun searchMovies(query: String): List<Movie> {
        if (query.isBlank()) return emptyList()
        val all = getAllMovies()
        val q = query.lowercase()
        return all.filter { movie ->
            movie.title.lowercase().contains(q) ||
                    movie.originalTitle.lowercase().contains(q) ||
                    movie.genres.any { it.lowercase().contains(q) }
        }
    }

    suspend fun getRecentlyAdded(limit: Int = 20): List<Movie> {
        return getAllMovies().sortedByDescending { it.folderModifiedTimestamp }.take(limit)
    }

    suspend fun getMoviesByYear(year: String): List<Movie> {
        return getAllMovies().filter { it.year == year }
    }

    suspend fun clearCacheAndReload(): List<Movie> {
        clearCache()
        cachedMovies = null
        lastLoadTime = 0L
        removeStopFlag()
        return getMoviesSmart()
    }

    fun stopAllOperations() {
        stopAllScraping()
        Log.d(TAG, "🛑 All movie operations stopped")
    }

    // ============ CACHE MANAGEMENT ============
    private fun getCacheAgeMinutes(): Long {
        return if (cacheFile.exists()) (System.currentTimeMillis() - cacheFile.lastModified()) / (60 * 1000) else -1L
    }

    private fun loadFromCache(): List<Movie> {
        return try {
            if (cacheFile.exists()) {
                val json = cacheFile.readText()
                if (json.isBlank() || json == "[]" || json == "{}") return emptyList()
                val type = object : TypeToken<List<Movie>>() {}.type
                val movies = gson.fromJson<List<Movie>>(json, type)
                movies ?: emptyList()
            } else emptyList()
        } catch (e: Exception) {
            Log.e(TAG, "Cache load error: ${e.message}")
            emptyList()
        }
    }

    private fun saveToCache(movies: List<Movie>) {
        try {
            val json = gson.toJson(movies)
            cacheFile.writeText(json)
            cacheFile.setLastModified(System.currentTimeMillis())
            Log.d(TAG, "💾 Saved ${movies.size} movies to cache (${cacheFile.length()} bytes)")
        } catch (e: Exception) {
            Log.e(TAG, "Cache save error: ${e.message}")
        }
    }

    private fun saveSyncStatus(syncType: String, movieCount: Int) {
        try {
            val syncData = mapOf(
                "last_sync_time" to System.currentTimeMillis(),
                "last_sync_type" to syncType,
                "movie_count" to movieCount,
                "cache_file_size" to cacheFile.length(),
                "cache_last_modified" to cacheFile.lastModified(),
                "timestamp" to System.currentTimeMillis()
            )
            syncStatusFile.writeText(gson.toJson(syncData))
        } catch (e: Exception) {
            Log.e(TAG, "Error saving sync status: ${e.message}")
        }
    }

    fun clearCache() {
        try {
            if (cacheFile.exists()) cacheFile.delete()
            cachedMovies = null
            lastLoadTime = 0L
        } catch (e: Exception) {
            Log.e(TAG, "Cache clear error: ${e.message}")
        }
    }

    fun getCacheInfo(): CacheInfo {
        return if (cacheFile.exists()) {
            val ageMinutes = getCacheAgeMinutes()
            val sizeKb = cacheFile.length() / 1024
            CacheInfo(
                exists = true,
                ageMinutes = ageMinutes,
                sizeKb = sizeKb,
                isExpired = ageMinutes > FRESHNESS_THRESHOLD_MINUTES
            )
        } else CacheInfo(exists = false, ageMinutes = 0, sizeKb = 0, isExpired = true)
    }

    fun getSyncInfo(): SyncInfo {
        return try {
            if (syncStatusFile.exists()) {
                val json = syncStatusFile.readText()
                val type = object : TypeToken<Map<String, Any>>() {}.type
                val data = gson.fromJson<Map<String, Any>>(json, type)
                SyncInfo(
                    lastSyncTime = (data["last_sync_time"] as? Double)?.toLong() ?: 0L,
                    syncType = data["last_sync_type"] as? String ?: "unknown",
                    movieCount = (data["movie_count"] as? Double)?.toInt() ?: 0
                )
            } else SyncInfo()
        } catch (e: Exception) {
            Log.e(TAG, "Error reading sync info: ${e.message}")
            SyncInfo()
        }
    }

    // ============ FAVORITES ============
    fun getFavoriteIds(): Set<String> = synchronized(favoritesFile) {
        try {
            if (favoritesFile.exists()) {
                val type = object : TypeToken<Set<String>>() {}.type
                gson.fromJson<Set<String>>(favoritesFile.readText(), type) ?: emptySet()
            } else emptySet()
        } catch (e: Exception) {
            emptySet()
        }
    }

    fun toggleFavorite(movieId: String): Boolean = synchronized(favoritesFile) {
        val favorites = getFavoriteIds().toMutableSet()
        val isNowFavorite = if (favorites.contains(movieId)) {
            favorites.remove(movieId)
            false
        } else {
            favorites.add(movieId)
            true
        }
        favoritesFile.writeText(gson.toJson(favorites))
        return isNowFavorite
    }

    fun isFavorite(movieId: String): Boolean = getFavoriteIds().contains(movieId)

    suspend fun getFavoriteMovies(): List<Movie> {
        val ids = getFavoriteIds()
        return getAllMovies().filter { it.id in ids }
    }

    // ============ WATCH HISTORY (THREAD‑SAFE) ============
    suspend fun saveWatchProgress(movieId: String, progress: Float, position: Long) = withContext(Dispatchers.IO) {
        synchronized(watchHistoryFile) {
            try {
                val history = getWatchHistoryInternal().toMutableMap()
                val normalizedProgress = if (progress > 1.5f) progress / 100f else progress  // normalize if needed
                history[movieId] = WatchRecord(normalizedProgress, position, System.currentTimeMillis())
                watchHistoryFile.writeText(gson.toJson(history))
                Log.d(TAG, "💾 Saved watch progress: id=$movieId, progress=${String.format("%.2f%%", normalizedProgress * 100)}%, position=$position")
            } catch (e: Exception) {
                Log.e(TAG, "❌ Failed to save watch progress for: $movieId", e)
            }
        }
    }

    fun getWatchProgress(movieId: String): WatchRecord? {
        return synchronized(watchHistoryFile) { getWatchHistoryInternal()[movieId] }
    }

    fun getWatchHistory(): Map<String, WatchRecord> = synchronized(watchHistoryFile) { getWatchHistoryInternal() }

    private fun getWatchHistoryInternal(): Map<String, WatchRecord> {
        return try {
            if (!watchHistoryFile.exists()) return emptyMap()
            val content = watchHistoryFile.readText()
            if (content.isBlank() || content == "[]" || content == "{}") return emptyMap()
            val type = object : TypeToken<Map<String, WatchRecord>>() {}.type
            gson.fromJson<Map<String, WatchRecord>>(content, type) ?: emptyMap()
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error loading watch history: ${e.message}")
            emptyMap()
        }
    }

    suspend fun getContinueWatching(): List<Movie> {
        val history = getWatchHistory()
        val allMovies = getAllMovies()
        return allMovies
            .filter { movie ->
                val record = history[movie.id]
                val normalizedProgress = if ((record?.progress ?: 0f) > 1.5f) (record?.progress ?: 0f) / 100f else record?.progress ?: 0f
                record != null && normalizedProgress > 0.05f
            }
            .sortedByDescending { history[it.id]?.timestamp ?: 0 }
            .take(10)
    }

    suspend fun getContinueWatchingEpisodes(): List<ContinueWatchingEntry> {
        val history = getWatchHistory()
        val entries = mutableListOf<ContinueWatchingEntry>()
        val allMovies = getAllMovies()  // used for series? actually we need series data – omitted for simplicity
        history.forEach { (id, record) ->
            val normalizedProgress = if (record.progress > 1.5f) record.progress / 100f else record.progress
            if (normalizedProgress > 0.05f) {
                val episodeMatch = Regex("(.+)_S(\\d+)_E(\\d+)").find(id)
                if (episodeMatch != null) {
                    val (seriesId, seasonStr, episodeStr) = episodeMatch.destructured
                    entries.add(
                        ContinueWatchingEntry(
                            id = id,
                            title = "Episode ${episodeStr.toInt()}",
                            poster = "",
                            type = ContinueWatchingType.SERIES_EPISODE,
                            movie = null,
                            seriesId = seriesId,
                            seasonNumber = seasonStr.toInt(),
                            episodeNumber = episodeStr.toInt(),
                            progress = normalizedProgress.coerceIn(0f, 1f),
                            position = record.position,
                            timestamp = record.timestamp
                        )
                    )
                } else {
                    // movie case
                    val movie = allMovies.find { it.id == id }
                    if (movie != null) {
                        entries.add(
                            ContinueWatchingEntry(
                                id = id,
                                title = movie.title,
                                poster = movie.poster,
                                type = ContinueWatchingType.MOVIE,
                                movie = movie,
                                seriesId = null,
                                seasonNumber = 0,
                                episodeNumber = 0,
                                progress = normalizedProgress.coerceIn(0f, 1f),
                                position = record.position,
                                timestamp = record.timestamp
                            )
                        )
                    }
                }
            }
        }
        return entries.sortedByDescending { it.timestamp }.take(15)
    }

    suspend fun getRecentlyWatched(limit: Int = 10): List<Movie> {
        val history = getWatchHistory()
        val allMovies = getAllMovies()
        return allMovies
            .filter { movie -> history.containsKey(movie.id) }
            .sortedByDescending { history[it.id]?.timestamp ?: 0 }
            .take(limit)
    }

    // ============ DATA CLASSES ============
    enum class ContinueWatchingType { MOVIE, SERIES_EPISODE }
    data class ContinueWatchingEntry(
        val id: String,
        var title: String,
        var poster: String,
        val type: ContinueWatchingType,
        val movie: Movie?,
        val seriesId: String?,
        val seasonNumber: Int,
        val episodeNumber: Int,
        val progress: Float,
        val position: Long,
        val timestamp: Long
    )
    data class WatchRecord(val progress: Float, val position: Long, val timestamp: Long)
    data class CacheInfo(val exists: Boolean, val ageMinutes: Long, val sizeKb: Long, val isExpired: Boolean) {
        fun getStatus(): String = when {
            !exists -> "No cache"
            isExpired -> "${ageMinutes}m old (stale)"
            else -> "${ageMinutes}m old (fresh)"
        }
    }
    data class SyncInfo(val lastSyncTime: Long = 0L, val syncType: String = "never", val movieCount: Int = 0) {
        fun getStatus(): String {
            if (lastSyncTime == 0L) return "Never synced"
            val hoursAgo = (System.currentTimeMillis() - lastSyncTime) / (1000 * 60 * 60)
            val minutesAgo = (System.currentTimeMillis() - lastSyncTime) / (1000 * 60)
            return when {
                hoursAgo < 1 -> "${minutesAgo}m ago"
                hoursAgo < 24 -> "${hoursAgo}h ago"
                else -> "${hoursAgo / 24}d ago"
            }
        }
        fun getSource(): String = when (syncType) {
            "github" -> "GitHub"
            "github_cache" -> "GitHub Cache"
            "github_download" -> "GitHub Download"
            "cache" -> "Local Cache"
            "scraped" -> "Fresh Scrape"
            "force_refresh_uploaded" -> "Force Refresh & Uploaded"
            "background_uploaded" -> "Background Upload"
            else -> syncType.replace("_", " ").replaceFirstChar { it.uppercase() }
        }
    }
}
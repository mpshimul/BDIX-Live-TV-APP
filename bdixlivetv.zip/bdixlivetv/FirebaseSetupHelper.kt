package com.shimulfp.bdixlivetv

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import android.util.Log

object FirebaseSetupHelper {
    private const val TAG = "FirebaseSetupHelper"

    fun initializeFirebase(context: Context) {
        try {
            // Check if Firebase is already initialized
            if (FirebaseApp.getApps(context).isEmpty()) {
                // For testing, you can create a dummy app
                val firebaseApp = FirebaseApp.initializeApp(context)
                Log.d(TAG, "Firebase initialized: ${firebaseApp?.name}")
            } else {
                Log.d(TAG, "Firebase already initialized")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Firebase initialization failed: ${e.message}")
        }
    }

    fun testRemoteConfig(context: Context) {
        val firebaseManager = FirebaseManager(context)

        // Test get methods
        val username = firebaseManager.getAynaUsername()
        val password = firebaseManager.getAynaPassword()
        val deviceId = firebaseManager.getDeviceId()

        Log.d(TAG, "Firebase Test Results:")
        Log.d(TAG, "Username: ${username ?: "null"}")
        Log.d(TAG, "Password: ${password ?: "null"}")
        Log.d(TAG, "Device ID: $deviceId")
    }
}
package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.shimulfp.bdixlivetv.models.SportsData
import com.shimulfp.bdixlivetv.models.SportsEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * SportsService - Manages live sports events data
 *
 * Responsibilities:
 * - Download sports script from GitHub
 * - Execute Python script to get sports data
 * - Cache sports data locally
 * - Provide sports events to UI
 */
object SportsService {
    private const val TAG = "SportsService"

    // File names
    private const val SCRIPT_FILENAME = "live_sports_events.py"
    private const val DATA_FILENAME = "sports.json"
    private const val METADATA_FILENAME = "sports_metadata.json"

    // Sync interval (10 minutes)
    const val SYNC_INTERVAL_MINUTES = 10L
    const val SYNC_INTERVAL_MS = SYNC_INTERVAL_MINUTES * 60 * 1000L

    // Cache expiry (15 minutes) - Live sports need fresh data
    private const val CACHE_EXPIRY_MINUTES = 15L
    private const val CACHE_EXPIRY_MS = CACHE_EXPIRY_MINUTES * 60 * 1000L

    /**
     * Load sports data (from cache or refresh if needed)
     */
    suspend fun loadSportsData(context: Context): SportsData? = withContext(Dispatchers.IO) {
        try {
            val dataFile = File(context.filesDir, DATA_FILENAME)
            val metadataFile = File(context.filesDir, METADATA_FILENAME)

            // Check if data exists and is fresh
            if (dataFile.exists() && metadataFile.exists()) {
                val dataAge = System.currentTimeMillis() - dataFile.lastModified()

                if (dataAge < CACHE_EXPIRY_MS) {
                    // Cache is fresh, load from local file
                    Log.d(TAG, "✅ Loading sports from cache (${dataAge / 60000}m old)")
                    return@withContext loadSportsDataFromFile(context)
                } else {
                    // Cache is expired, refresh
                    Log.d(TAG, "⚠️ Sports cache expired, refreshing...")
                    return@withContext refreshSportsData(context)
                }
            } else {
                // No cache, fetch fresh data
                Log.d(TAG, "📥 No cache found, fetching fresh data...")
                return@withContext refreshSportsData(context)
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error loading sports data: ${e.message}", e)
            null
        }
    }

    /**
     * Refresh sports data from GitHub and Python script
     */
    suspend fun refreshSportsData(context: Context): SportsData? = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "🔄 === REFRESHING SPORTS DATA ===")

            val firebaseManager = FirebaseManager(context)
            val githubToken = firebaseManager.getGitHubToken()

            if (githubToken.isEmpty()) {
                Log.w(TAG, "⚠️ No GitHub token, cannot refresh sports")
                return@withContext null
            }

            // Step 1: Download script from GitHub
            val scriptDownloaded = downloadSportsScript(context, githubToken)
            if (!scriptDownloaded) {
                Log.w(TAG, "⚠️ Failed to download sports script")
                return@withContext null
            }

            // Step 2: Execute Python script to get sports data
            val sportsData = executeSportsScript(context)

            if (sportsData != null && sportsData.events.isNotEmpty()) {
                // Step 3: Save to local cache
                saveSportsData(context, sportsData)
                Log.d(TAG, "✅ Refreshed ${sportsData.events.size} sports events")
                return@withContext sportsData
            } else {
                Log.w(TAG, "⚠️ No sports events found")
                return@withContext SportsData() // Return empty data
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error refreshing sports data: ${e.message}", e)
            null
        }
    }

    /**
     * Download sports script from GitHub
     */
    private suspend fun downloadSportsScript(context: Context, githubToken: String): Boolean {
        return try {
            Log.d(TAG, "📥 Downloading sports script from GitHub...")

            // Initialize GitHubDataManager with token
            GitHubDataManager.initialize(githubToken)

            // Download the script using the public method
            val scriptContent = GitHubDataManager.downloadScriptFile(SCRIPT_FILENAME)

            if (scriptContent.isEmpty()) {
                Log.e(TAG, "❌ Downloaded empty script content")
                return false
            }

            // Save script to files directory
            val scriptFile = File(context.filesDir, SCRIPT_FILENAME)
            scriptFile.writeText(scriptContent)
            scriptFile.setLastModified(System.currentTimeMillis())

            Log.d(TAG, "✅ Sports script downloaded successfully (${scriptContent.length} chars)")
            true
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error downloading sports script: ${e.message}", e)
            false
        }
    }

    /**
     * Execute Python script to get sports data
     * The script saves to sports.json file, then we read and parse it
     */
    private suspend fun executeSportsScript(context: Context): SportsData? {
        return try {
            Log.d(TAG, "🐍 Executing sports script...")

            // Initialize Python
            PythonHelper.initialize(context)

            val py = com.chaquo.python.Python.getInstance()

            // Add files directory to Python path
            val sys = py.getModule("sys")
            val pathObj = sys["path"]
            if (pathObj != null) {
                try {
                    val pathList: List<*> = pathObj.asList()
                    val filesDirPath = context.filesDir.absolutePath

                    var pathExists = false
                    for (item in pathList) {
                        if (item?.toString() == filesDirPath) {
                            pathExists = true
                            break
                        }
                    }

                    if (!pathExists) {
                        pathObj.callAttr("append", filesDirPath)
                        Log.d(TAG, "✅ Added files dir to Python path: $filesDirPath")
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "⚠️ Could not modify Python path: ${e.message}")
                }
            }

            // Import the script
            val module = py.getModule(SCRIPT_FILENAME.removeSuffix(".py"))

            // Call fetch_sports function with output file path (the actual function in the script)
            val outputFilePath = File(context.filesDir, DATA_FILENAME).absolutePath
            try {
                module.callAttr("fetch_sports", null, outputFilePath)
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error calling fetch_sports: ${e.message}")
                // Continue anyway - the script may have saved the file
            }

            // The script saves to sports.json, so read that file
            val jsonFile = File(context.filesDir, DATA_FILENAME)

            if (!jsonFile.exists()) {
                Log.w(TAG, "⚠️ Script did not create $DATA_FILENAME")
                return null
            }

            val jsonContent = jsonFile.readText()
            Log.d(TAG, "📊 Read ${jsonContent.length} chars from $DATA_FILENAME")

            // Parse the JSON - the script saves as {"a": [streams]}
            val gson = Gson()
            val sportsData = try {
                val rawJson = gson.fromJson(jsonContent, Map::class.java) as? Map<String, Any>
                val streamsArray = rawJson?.get("a") as? List<Map<String, Any>>

                if (streamsArray != null) {
                    // Convert script format to SportsEvent format with URL validation
                    val events = streamsArray.mapNotNull { stream ->
                        try {
                            // Collect all URLs from the script
                            val urlsList = (stream["urls"] as? List<*>)
                                ?.mapNotNull { it?.toString() }
                                ?.filter { it.isNotEmpty() && it.startsWith("http") }
                                ?: emptyList()

                            // Validate each URL - check if accessible
                            val validUrls = validateUrls(urlsList)

                            // Only create event if there are working URLs
                            if (validUrls.isNotEmpty()) {
                                SportsEvent(
                                    id = (stream["name"]?.toString() ?: System.currentTimeMillis().toString()).hashCode().toString(),
                                    title = stream["name"]?.toString() ?: "Unknown Event",
                                    sport = stream["category"]?.toString() ?: "Sports",
                                    league = stream["tournament"]?.toString() ?: "",
                                    teams = "", // The script combines this in title
                                    startTime = "", // Live events don't have start time
                                    thumbnail = stream["logo"]?.toString() ?: "",
                                    streamUrls = validUrls,  // All validated URLs
                                    isLive = true, // All matches in script are LIVE
                                    category = stream["category"]?.toString() ?: "Sports",
                                    language = "English",
                                    quality = "HD",
                                    viewers = "",
                                    description = "Live stream from ${stream["source"]?.toString() ?: "FanCode"} (${validUrls.size} streams)"
                                )
                            } else {
                                Log.w(TAG, "⚠️ Skipping event with no valid URLs: ${stream["name"]}")
                                null
                            }
                        } catch (e: Exception) {
                            Log.w(TAG, "⚠️ Failed to parse stream: ${e.message}")
                            null
                        }
                    }

                    Log.d(TAG, "✅ Processed ${streamsArray.size} streams, ${events.size} have valid URLs")
                    SportsData(events = events)
                } else {
                    Log.w(TAG, "⚠️ Invalid JSON format - missing 'a' array")
                    null
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error parsing sports JSON: ${e.message}")
                Log.e(TAG, "JSON sample: ${jsonContent.take(200)}")
                null
            }

            if (sportsData != null) {
                Log.d(TAG, "✅ Parsed ${sportsData.events.size} sports events")
            }
            sportsData
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error executing sports script: ${e.message}", e)
            null
        }
    }

    /**
     * Save sports data to local cache
     */
    private fun saveSportsData(context: Context, sportsData: SportsData) {
        try {
            val gson = Gson()

            // Save data
            val dataFile = File(context.filesDir, DATA_FILENAME)
            dataFile.writeText(gson.toJson(sportsData))
            dataFile.setLastModified(System.currentTimeMillis())

            // Save metadata
            val metadata = mapOf(
                "timestamp" to System.currentTimeMillis(),
                "event_count" to sportsData.events.size,
                "live_count" to sportsData.getLiveEvents().size,
                "upcoming_count" to sportsData.getUpcomingEvents().size,
                "version" to sportsData.version
            )
            val metadataFile = File(context.filesDir, METADATA_FILENAME)
            metadataFile.writeText(gson.toJson(metadata))
            metadataFile.setLastModified(System.currentTimeMillis())

            Log.d(TAG, "💾 Saved ${sportsData.events.size} sports events to cache")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving sports data: ${e.message}", e)
        }
    }

    /**
     * Load sports data from local cache file
     */
    private fun loadSportsDataFromFile(context: Context): SportsData? {
        return try {
            val dataFile = File(context.filesDir, DATA_FILENAME)

            if (!dataFile.exists()) {
                Log.d(TAG, "⚠️ Sports data file not found")
                return null
            }

            val content = dataFile.readText()
            val gson = Gson()
            val sportsData = gson.fromJson(content, SportsData::class.java)

            Log.d(TAG, "📂 Loaded ${sportsData.events.size} sports events from cache")
            sportsData
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error loading sports data from file: ${e.message}", e)
            // Delete corrupted file
            try {
                File(context.filesDir, DATA_FILENAME).delete()
                Log.d(TAG, "🗑️ Deleted corrupted sports data file")
            } catch (deleteEx: Exception) {
                // Ignore
            }
            null
        }
    }

    /**
     * Validate URLs - Check if they are accessible via HEAD request
     * Returns only the URLs that respond successfully
     */
    private suspend fun validateUrls(urls: List<String>): List<String> = withContext(Dispatchers.IO) {
        if (urls.isEmpty()) return@withContext emptyList()

        val client = OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(3, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()

        val validUrls = mutableListOf<String>()

        for (url in urls) {
            try {
                val request = Request.Builder()
                    .url(url)
                    .head()
                    .build()

                val response: Response = client.newCall(request).execute()

                if (response.isSuccessful) {
                    validUrls.add(url)
                    Log.d(TAG, "✅ Valid URL: ${url.take(60)}...")
                } else {
                    Log.w(TAG, "⚠️ URL returned ${response.code}: ${url.take(60)}...")
                }
                response.close()
            } catch (e: Exception) {
                Log.w(TAG, "❌ URL validation failed: ${url.take(60)}... - ${e.message}")
                // Continue checking other URLs
            }
        }

        Log.d(TAG, "🔍 Validated ${urls.size} URLs, ${validUrls.size} are working")
        validUrls
    }

    /**
     * Get sports cache status
     */
    fun getCacheStatus(context: Context): CacheStatus {
        return try {
            val dataFile = File(context.filesDir, DATA_FILENAME)
            val metadataFile = File(context.filesDir, METADATA_FILENAME)

            if (!dataFile.exists()) {
                return CacheStatus.NotAvailable
            }

            val ageMinutes = (System.currentTimeMillis() - dataFile.lastModified()) / (60 * 1000)
            val isExpired = ageMinutes > CACHE_EXPIRY_MINUTES

            // Load metadata if available
            var eventCount = 0
            var liveCount = 0
            var upcomingCount = 0

            if (metadataFile.exists()) {
                try {
                    val gson = Gson()
                    val metadata = gson.fromJson(metadataFile.readText(), Map::class.java)
                    eventCount = (metadata["event_count"] as? Double)?.toInt() ?: 0
                    liveCount = (metadata["live_count"] as? Double)?.toInt() ?: 0
                    upcomingCount = (metadata["upcoming_count"] as? Double)?.toInt() ?: 0
                } catch (e: Exception) {
                    // Use default values
                }
            }

            CacheStatus.Available(
                ageMinutes = ageMinutes,
                isExpired = isExpired,
                eventCount = eventCount,
                liveCount = liveCount,
                upcomingCount = upcomingCount
            )
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting cache status: ${e.message}")
            CacheStatus.NotAvailable
        }
    }

    /**
     * Clear sports cache
     */
    fun clearCache(context: Context) {
        try {
            val dataFile = File(context.filesDir, DATA_FILENAME)
            val metadataFile = File(context.filesDir, METADATA_FILENAME)
            val scriptFile = File(context.filesDir, SCRIPT_FILENAME)

            dataFile.delete()
            metadataFile.delete()
            scriptFile.delete()

            Log.d(TAG, "🗑️ Cleared sports cache")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error clearing sports cache: ${e.message}")
        }
    }

    /**
     * Check if sync is needed
     */
    fun shouldSync(context: Context): Boolean {
        val status = getCacheStatus(context)
        return when (status) {
            is CacheStatus.Available -> status.isExpired
            is CacheStatus.NotAvailable -> true
        }
    }
}

/**
 * Sports cache status
 */
sealed class CacheStatus {
    data class Available(
        val ageMinutes: Long,
        val isExpired: Boolean,
        val eventCount: Int,
        val liveCount: Int,
        val upcomingCount: Int
    ) : CacheStatus()

    object NotAvailable : CacheStatus()
}

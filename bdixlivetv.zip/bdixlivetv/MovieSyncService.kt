package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Log
import com.shimulfp.bdixlivetv.FirebaseManager
import com.shimulfp.bdixlivetv.GitHubDataManager
import com.shimulfp.bdixlivetv.data.MovieRepository
import com.shimulfp.bdixlivetv.data.MovieScraper
import kotlinx.coroutines.*
import kotlinx.coroutines.Dispatchers.IO

object MovieSyncService {
    private const val TAG = "MovieSyncService"

    /**
     * Start periodic sync (simplified)
     */
    fun startPeriodicSync(context: Context) {
        CoroutineScope(IO).launch {
            try {
                Log.d(TAG, "🔄 Starting movie sync...")
                syncMovies(context)
            } catch (e: Exception) {
                Log.e(TAG, "Sync error: ${e.message}")
            }
        }
    }

    /**
     * Main sync function
     */
    suspend fun syncMovies(context: Context): SyncResult = withContext(IO) {
        Log.d(TAG, "🚀 === MOVIE SYNC START ===")

        return@withContext try {
            val firebaseManager = FirebaseManager(context)
            val githubToken = firebaseManager.getGitHubToken()

            if (githubToken.isEmpty()) {
                Log.w(TAG, "⚠️ No GitHub token available")
                return@withContext SyncResult.NoToken
            }

            // Initialize GitHubDataManager
            GitHubDataManager.initialize(githubToken)

            // Strategy: Try GitHub first, fallback to scraping
            val result = tryGitHubFirst(context, githubToken)

            Log.d(TAG, "✅ Sync completed: ${result.getMessage()}")
            result

        } catch (e: Exception) {
            Log.e(TAG, "❌ Movie sync error: ${e.message}", e)
            SyncResult.Error(e.message ?: "Unknown error")
        }
    }

    /**
     * Try GitHub first, fallback to scraping
     *
     * LOGIC:
     * - If GitHub data is FRESH (<2 hours) → Download only (NO scraping needed)
     * - If GitHub data is OLD or missing → Scrape & Upload immediately
     */
    private suspend fun tryGitHubFirst(
        context: Context,
        githubToken: String
    ): SyncResult = withContext(IO) {
        return@withContext try {
            // Check if GitHub data is fresh (<2 hours)
            val isGitHubFresh = GitHubDataManager.isMovieDataFresh()
            Log.d(TAG, "🔍 GitHub movie data fresh check: $isGitHubFresh")

            if (isGitHubFresh) {
                Log.d(TAG, "✅ GitHub movie data is fresh, downloading only...")
                val movies = GitHubDataManager.downloadMovies(context)

                if (movies.isNotEmpty()) {
                    // Save to repository cache
                    MovieRepository.getInstance(context).clearCache()
                    saveMoviesToCache(context, movies)

                    Log.d(TAG, "✅ Downloaded ${movies.size} movies from GitHub (no scraping needed)")
                    return@withContext SyncResult.GitHubDownload(movies.size)
                } else {
                    Log.w(TAG, "⚠️ GitHub said data was fresh but download returned empty, falling back to scrape...")
                }
            } else {
                Log.d(TAG, "📅 GitHub data is old/missing, will scrape & upload")
            }

            // If GitHub failed, returned empty, or not fresh, scrape fresh and upload
            Log.d(TAG, "🔄 Starting scrape & upload process...")
            scrapeAndUpload(context, githubToken)

        } catch (e: Exception) {
            Log.e(TAG, "GitHub first strategy failed: ${e.message}", e)
            // Fallback to scraping
            scrapeAndUpload(context, githubToken)
        }
    }

    /**
     * Scrape fresh movies and upload to GitHub
     * CRITICAL: When scraping happens, we MUST upload to GitHub immediately
     */
    private suspend fun scrapeAndUpload(
        context: Context,
        githubToken: String
    ): SyncResult = withContext(IO) {
        return@withContext try {
            Log.d(TAG, "🔄 Scraping fresh movie data...")

            // ✅ No limit passed – Python uses its own default (now 1000)
            val movies = MovieScraper.scrapeAllMovies(context)

            if (movies.isEmpty()) {
                Log.e(TAG, "❌ Scraping failed, no movies found")
                return@withContext SyncResult.ScrapingFailed
            }

            Log.d(TAG, "✅ Scraped ${movies.size} movies successfully")

            // Save locally FIRST
            MovieRepository.getInstance(context).clearCache()
            saveMoviesToCache(context, movies)

            // CRITICAL: Upload to GitHub IMMEDIATELY after scraping
            // This ensures scraped data is preserved for future users
            Log.d(TAG, "🚀 CRITICAL: Uploading ${movies.size} scraped movies to GitHub...")

            if (!GitHubDataManager.isInitialized()) {
                Log.w(TAG, "⚠️ GitHubDataManager not initialized, re-initializing...")
                GitHubDataManager.initialize(githubToken)
            }

            if (githubToken.isEmpty()) {
                Log.e(TAG, "❌ Cannot upload: GitHub token is empty")
                return@withContext SyncResult.ScrapedOnly(movies.size)
            }

            return@withContext try {
                Log.d(TAG, "📊 Pre-upload check:")
                Log.d(TAG, "   - GitHubDataManager.isInitialized: ${GitHubDataManager.isInitialized()}")
                Log.d(TAG, "   - githubToken.isEmpty: ${githubToken.isEmpty()}")
                Log.d(TAG, "   - Movies size: ${movies.size}")
                Log.d(TAG, "   - Token length: ${githubToken.length}")
                Log.d(TAG, "📊 Calling GitHubDataManager.uploadMovies()...")

                val uploaded = GitHubDataManager.uploadMovies(context, movies)

                Log.d(TAG, "📊 uploadMovies() returned: $uploaded")

                if (uploaded) {
                    Log.d(TAG, "✅ SUCCESS: Uploaded ${movies.size} movies to GitHub!")
                    Log.d(TAG, "   Future users will download this data instead of re-scraping")
                    SyncResult.ScrapedAndUploaded(movies.size)
                } else {
                    Log.e(TAG, "❌ FAILED: Upload returned false")
                    Log.e(TAG, "   Scraped data is saved locally but NOT uploaded to GitHub")
                    Log.e(TAG, "   This data will be lost if the app is cleared!")
                    SyncResult.ScrapedOnly(movies.size)
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ EXCEPTION during upload: ${e.message}", e)
                Log.e(TAG, "   Scraped data is saved locally but NOT uploaded to GitHub")
                SyncResult.ScrapedOnly(movies.size)
            }

        } catch (e: Exception) {
            Log.e(TAG, "❌ Scrape and upload error: ${e.message}", e)
            SyncResult.Error(e.message ?: "Unknown error")
        }
    }

    /**
     * Save movies to cache
     */
    private fun saveMoviesToCache(context: Context, movies: List<com.shimulfp.bdixlivetv.models.Movie>) {
        try {
            val file = java.io.File(context.filesDir, "movies_cache.json")
            file.writeText(com.google.gson.Gson().toJson(movies))
            file.setLastModified(System.currentTimeMillis())
            Log.d(TAG, "💾 Saved ${movies.size} movies to cache")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving movies to cache: ${e.message}")
        }
    }

    // ============ DATA CLASSES ============

    sealed class SyncResult {
        object NoToken : SyncResult()
        data class GitHubDownload(val count: Int) : SyncResult()
        data class ScrapedAndUploaded(val count: Int) : SyncResult()
        data class ScrapedOnly(val count: Int) : SyncResult()
        object ScrapingFailed : SyncResult()

        // Alternative fix: Use @JvmField to avoid generating getter
        data class Error(@JvmField val message: String) : SyncResult()

        fun getMessage(): String {
            return when (this) {
                is GitHubDownload -> "Downloaded $count movies from GitHub"
                is ScrapedAndUploaded -> "Scraped and uploaded $count movies"
                is ScrapedOnly -> "Scraped $count movies"
                is ScrapingFailed -> "Scraping failed"
                is Error -> "Error: ${this.message}"
                NoToken -> "No GitHub token"
            }
        }
    }
}
package com.shimulfp.bdixlivetv.utils

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.Modifier

/**
 * TV Focus Manager - Handles D-pad navigation and focus management for TV
 *
 * This utility class provides functions to manage focus for TV navigation,
 * ensuring proper D-pad support and visual feedback.
 */
object TVFocusManager {

    /**
     * Creates a focus requester that remembers the focus state
     */
    @Composable
    fun rememberFocusRequester(): FocusRequester {
        return remember { FocusRequester() }
    }

    /**
     * Creates a modifier with focus request and proper TV focus properties
     *
     * @param focusRequester The focus requester to use
     * @param nextUp Focus target when user presses UP (optional)
     * @param nextDown Focus target when user presses DOWN (optional)
     * @param nextLeft Focus target when user presses LEFT (optional)
     * @param nextRight Focus target when user presses RIGHT (optional)
     */
    @Composable
    fun Modifier.tvFocusable(
        focusRequester: FocusRequester,
        nextUp: FocusRequester? = null,
        nextDown: FocusRequester? = null,
        nextLeft: FocusRequester? = null,
        nextRight: FocusRequester? = null,
        enabled: Boolean = true
    ): Modifier {
        return this
            .focusRequester(focusRequester)
            .focusProperties {
                if (enabled) {
                    nextUp?.let { up = it }
                    nextDown?.let { down = it }
                    nextLeft?.let { left = it }
                    nextRight?.let { right = it }
                } else {
                    canFocus = false
                }
            }
    }

    /**
     * Request focus on a specific focus requester
     *
     * @param focusRequester The focus requester to request focus on
     */
    fun requestFocus(focusRequester: FocusRequester) {
        focusRequester.requestFocus()
    }

    /**
     * Free focus (remove focus from current item)
     *
     * @param focusRequester The focus requester to free focus from
     */
    fun freeFocus(focusRequester: FocusRequester) {
        focusRequester.freeFocus()
    }

    /**
     * TV Grid Focus Manager - Manages focus for grid layouts
     */
    class GridFocusManager(
        private val columns: Int,
        private val itemCount: Int
    ) {
        private val focusRequesters = mutableMapOf<Int, FocusRequester>()

        /**
         * Get or create focus requester for a specific item
         */
        @Composable
        fun getItemFocusRequester(index: Int): FocusRequester {
            return focusRequesters.getOrPut(index) {
                remember { FocusRequester() }
            }
        }

        /**
         * Calculate the next focus index based on direction
         *
         * @param currentIndex Current focused item index
         * @param direction Direction of navigation (UP, DOWN, LEFT, RIGHT)
         * @return Next focus index or null if no valid navigation
         */
        fun getNextFocusIndex(
            currentIndex: Int,
            direction: Direction
        ): Int? {
            return when (direction) {
                Direction.UP -> {
                    val newIndex = currentIndex - columns
                    if (newIndex >= 0) newIndex else null
                }
                Direction.DOWN -> {
                    val newIndex = currentIndex + columns
                    if (newIndex < itemCount) newIndex else null
                }
                Direction.LEFT -> {
                    if (currentIndex % columns != 0) currentIndex - 1 else null
                }
                Direction.RIGHT -> {
                    if ((currentIndex + 1) % columns != 0 && currentIndex + 1 < itemCount) {
                        currentIndex + 1
                    } else null
                }
            }
        }

        enum class Direction {
            UP, DOWN, LEFT, RIGHT
        }
    }

    /**
     * TV Row Focus Manager - Manages focus for horizontal row layouts
     */
    class RowFocusManager(
        private val itemCount: Int
    ) {
        private val focusRequesters = mutableMapOf<Int, FocusRequester>()

        /**
         * Get or create focus requester for a specific item
         */
        @Composable
        fun getItemFocusRequester(index: Int): FocusRequester {
            return focusRequesters.getOrPut(index) {
                remember { FocusRequester() }
            }
        }

        /**
         * Calculate the next focus index in row
         *
         * @param currentIndex Current focused item index
         * @param direction Direction of navigation (LEFT or RIGHT)
         * @return Next focus index or null if no valid navigation
         */
        fun getNextFocusIndex(
            currentIndex: Int,
            direction: RowDirection
        ): Int? {
            return when (direction) {
                RowDirection.LEFT -> if (currentIndex > 0) currentIndex - 1 else null
                RowDirection.RIGHT -> if (currentIndex < itemCount - 1) currentIndex + 1 else null
            }
        }

        enum class RowDirection {
            LEFT, RIGHT
        }
    }
}

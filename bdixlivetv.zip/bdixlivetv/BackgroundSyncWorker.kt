package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * BackgroundSyncWorker - Runs periodic sync in the background
 * This worker is scheduled by WorkManager and runs even when the app is closed
 *
 * Features:
 * - Runs periodically (default: every 60 minutes)
 * - Works even when app is killed
 * - Respects battery optimization and Doze mode
 * - Handles network constraints
 * - Syncs channels, movies, and series
 */
class BackgroundSyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        private const val TAG = "BackgroundSyncWorker"
        const val WORK_NAME = "BDIXBackgroundSyncWork"

        /**
         * Get the sync interval (in minutes)
         * Can be customized based on your needs
         */
        fun getSyncIntervalMinutes(): Long {
            return 60L // Sync every 60 minutes
        }

        /**
         * Get the flex interval (in minutes)
         * WorkManager can run the work anytime within the flex period before the interval ends
         */
        fun getFlexIntervalMinutes(): Long {
            return 15L // Can run 15 minutes before or after the scheduled time
        }
    }

    override suspend fun doWork(): Result {
        return try {
            Log.d(TAG, "🚀 === BACKGROUND SYNC WORKER STARTED ===")
            Log.d(TAG, "⏰ Running at: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())}")

            // Initialize FirebaseManager to get credentials
            val firebaseManager = FirebaseManager(applicationContext)
            val githubToken = firebaseManager.getGitHubToken()

            if (githubToken.isEmpty()) {
                Log.w(TAG, "⚠️ No GitHub token available, skipping sync")
                return Result.success() // Return success to avoid retries
            }

            // Initialize GitHubDataManager
            GitHubDataManager.initialize(githubToken)

            // Sync Channels
            syncChannels()

            // Sync Movies
            syncMovies()

            // Sync Series
            syncSeries()

            Log.d(TAG, "✅ === BACKGROUND SYNC WORKER COMPLETED ===")
            Result.success()

        } catch (e: Exception) {
            Log.e(TAG, "❌ Background sync worker failed: ${e.message}", e)
            // Return retry to try again later
            if (runAttemptCount < 3) {
                Result.retry()
            } else {
                // After 3 failed attempts, give up and try again on next scheduled run
                Result.success()
            }
        }
    }

    /**
     * Sync channels in the background
     */
    private suspend fun syncChannels() {
        try {
            // Check if channel sync is enabled in settings
            if (!BackgroundSyncSettings.shouldSyncChannels(applicationContext)) {
                Log.d(TAG, "⏭ Channel sync disabled in settings, skipping")
                return
            }

            Log.d(TAG, "📺 Syncing channels...")

            val result = GitHubDataManager.checkAndSyncData(applicationContext)

            when (result) {
                is GitHubDataManager.SyncResult.Downloaded -> {
                    Log.d(TAG, "✅ Channels downloaded from GitHub (${result.ageMinutes}m old)")
                }
                is GitHubDataManager.SyncResult.ScrapedAndUploaded -> {
                    Log.d(TAG, "✅ Channels scraped & uploaded (${result.channelCount} channels)")
                }
                is GitHubDataManager.SyncResult.ScrapedOnly -> {
                    Log.d(TAG, "⚠️ Channels scraped but upload failed (${result.channelCount} channels)")
                }
                is GitHubDataManager.SyncResult.ScrapingFailed -> {
                    Log.e(TAG, "❌ Channel scraping failed")
                }
                is GitHubDataManager.SyncResult.Error -> {
                    Log.e(TAG, "❌ Channel sync error: ${result.message}")
                }
                is GitHubDataManager.SyncResult.NoToken -> {
                    Log.w(TAG, "⚠️ No GitHub token for channels")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Channel sync exception: ${e.message}", e)
        }
    }

    /**
     * Sync movies in the background
     */
    private suspend fun syncMovies() {
        try {
            // Check if movie sync is enabled in settings
            if (!BackgroundSyncSettings.shouldSyncMovies(applicationContext)) {
                Log.d(TAG, "⏭ Movie sync disabled in settings, skipping")
                return
            }

            Log.d(TAG, "🎬 Syncing movies...")

            val result = MovieSyncService.syncMovies(applicationContext)

            when (result) {
                is MovieSyncService.SyncResult.GitHubDownload -> {
                    Log.d(TAG, "✅ Movies downloaded from GitHub (${result.count} movies)")
                }
                is MovieSyncService.SyncResult.ScrapedAndUploaded -> {
                    Log.d(TAG, "✅ Movies scraped & uploaded (${result.count} movies)")
                }
                is MovieSyncService.SyncResult.ScrapedOnly -> {
                    Log.d(TAG, "⚠️ Movies scraped but upload failed (${result.count} movies)")
                }
                is MovieSyncService.SyncResult.ScrapingFailed -> {
                    Log.e(TAG, "❌ Movie scraping failed")
                }
                is MovieSyncService.SyncResult.Error -> {
                    Log.e(TAG, "❌ Movie sync error")
                }
                is MovieSyncService.SyncResult.NoToken -> {
                    Log.w(TAG, "⚠️ No GitHub token for movies")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Movie sync exception: ${e.message}", e)
        }
    }

    /**
     * Sync series in the background
     */
    private suspend fun syncSeries() {
        try {
            // Check if series sync is enabled in settings
            if (!BackgroundSyncSettings.shouldSyncSeries(applicationContext)) {
                Log.d(TAG, "⏭ Series sync disabled in settings, skipping")
                return
            }

            Log.d(TAG, "📺 Syncing series...")

            val result = SeriesSyncService.syncSeries(applicationContext)

            when (result) {
                is SeriesSyncService.SyncResult.GitHubDownload -> {
                    Log.d(TAG, "✅ Series downloaded from GitHub (${result.count} series)")
                }
                is SeriesSyncService.SyncResult.ScrapedAndUploaded -> {
                    Log.d(TAG, "✅ Series scraped & uploaded (${result.count} series)")
                }
                is SeriesSyncService.SyncResult.ScrapedOnly -> {
                    Log.d(TAG, "⚠️ Series scraped but upload failed (${result.count} series)")
                }
                is SeriesSyncService.SyncResult.ScrapingFailed -> {
                    Log.e(TAG, "❌ Series scraping failed")
                }
                is SeriesSyncService.SyncResult.Error -> {
                    Log.e(TAG, "❌ Series sync error")
                }
                is SeriesSyncService.SyncResult.NoToken -> {
                    Log.w(TAG, "⚠️ No GitHub token for series")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Series sync exception: ${e.message}", e)
        }
    }
}

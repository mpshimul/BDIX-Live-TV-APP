package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.util.concurrent.TimeUnit

object PythonScriptsDownloader {
    private const val TAG = "ScriptDownloader"
    private const val GITHUB_RAW_BASE = "https://raw.githubusercontent.com"
    private const val GITHUB_API_BASE = "https://api.github.com"
    private const val REPO_OWNER = "mpshimul"
    private const val REPO_NAME = "BDIX-TV"
    private const val BRANCH = "main"
    private const val SCRIPTS_DIR = "scripts/python"

    private const val VERSION_FILE = "version.txt"

    // GitHub token – now nullable and fetched on demand
    private var githubToken: String? = null

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    // All required files
    private val REQUIRED_FILES = listOf(
        "aynaott_auth_refresh.py",
        "aynaott_with_cache.py",
        //"basnet.py",
        "bootstrap.py",
        "channel_cache.py",
        "get_channels.py",
        //"ksb.py",
        "master_scraper.py",
        //"redforce.py",
        "restructure_channels.py",
        "scraper_main.py",
        "token_manager.py",
        "update_config.py",
        "__init__.py",
        "requirements.txt",
        "version.txt",
        //"basnet.json",
        //"ksb.json",
        //"redforce.json",
        "series_scraper.py",
        "movie_scraper.py"
    )

    /**
     * Initialize with GitHub token (optional – kept for backward compatibility)
     */
    fun initializeWithToken(token: String) {
        githubToken = token.trim()
        Log.d(TAG, "✅ GitHub token initialized: ${githubToken?.isNotEmpty() == true}")
    }

    /**
     * Check if we have GitHub token
     */
    fun hasGitHubToken(): Boolean = !githubToken.isNullOrEmpty()

    /**
     * Ensure a valid GitHub token is available – fetches from Firebase if needed.
     */
    private suspend fun ensureToken(context: Context): Boolean = withContext(Dispatchers.IO) {
        // If we already have a token, use it
        if (hasGitHubToken()) {
            return@withContext true
        }

        return@withContext try {
            Log.d(TAG, "🔑 No cached token – fetching from Firebase...")
            val firebaseManager = FirebaseManager(context)
            val fetchSuccess = firebaseManager.fetchAndActivate()
            if (!fetchSuccess) {
                Log.e(TAG, "❌ Failed to fetch remote config")
                return@withContext false
            }

            val token = firebaseManager.getGitHubToken()
            if (token.isNotEmpty()) {
                initializeWithToken(token)
                true
            } else {
                Log.e(TAG, "❌ GitHub token is empty in remote config")
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error fetching token: ${e.message}")
            false
        }
    }

    /**
     * PUBLIC: Check if scripts exist locally
     */
    fun scriptsExistLocally(context: Context): Boolean {
        val scriptsDir = File(context.filesDir, "python_scripts")

        if (!scriptsDir.exists() || !scriptsDir.isDirectory) {
            return false
        }

        // Check for critical files
        val criticalFiles = listOf(
            "aynaott_with_cache.py",
            "master_scraper.py",
            "bootstrap.py",
            "__init__.py"
        )

        return criticalFiles.all { fileName ->
            val file = File(scriptsDir, fileName)
            file.exists() && file.length() > 100
        }
    }

    /**
     * Initialize - Auto-download scripts on app start if needed
     */
    suspend fun initialize(context: Context): Boolean = withContext(Dispatchers.IO) {
        Log.d(TAG, "🚀 Initializing Python Scripts Downloader...")

        return@withContext try {
            // Ensure we have a token first
            if (!ensureToken(context)) {
                return@withContext false
            }

            // Now token is available, check scripts
            if (!scriptsExistLocally(context)) {
                Log.d(TAG, "📥 No local scripts found, downloading from GitHub...")
                downloadAllScripts(context)
            } else {
                checkAndUpdateScripts(context)
            }

            true
        } catch (e: Exception) {
            Log.e(TAG, "❌ Initialization failed: ${e.message}", e)
            false
        }
    }

    /**
     * Check for updates and download if needed
     */
    private suspend fun checkAndUpdateScripts(context: Context): Boolean = withContext(Dispatchers.IO) {
        Log.d(TAG, "🔍 Checking for script updates...")

        return@withContext try {
            if (!ensureToken(context)) {
                return@withContext false
            }

            val localVersion = getLocalVersion(context)
            val remoteVersion = getRemoteVersion(context)

            Log.d(TAG, "📊 Version - Local: $localVersion, Remote: $remoteVersion")

            if (remoteVersion > localVersion) {
                Log.d(TAG, "🔄 New version available ($remoteVersion > $localVersion), updating...")
                downloadAllScripts(context)
            } else {
                Log.d(TAG, "✅ Scripts are up to date")
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error checking updates: ${e.message}")
            false
        }
    }

    /**
     * Get local script version
     */
    private fun getLocalVersion(context: Context): Int {
        return try {
            val versionFile = File(getScriptsDir(context), "version.txt")
            if (versionFile.exists()) {
                versionFile.readText().trim().toIntOrNull() ?: 0
            } else {
                0
            }
        } catch (e: Exception) {
            0
        }
    }

    /**
     * Get remote script version from GitHub API (supports private repos)
     */
    private suspend fun getRemoteVersion(context: Context): Int = withContext(Dispatchers.IO) {
        return@withContext try {
            if (!ensureToken(context)) {
                return@withContext 0
            }

            // Use GitHub API for private repos
            val url = "$GITHUB_API_BASE/repos/$REPO_OWNER/$REPO_NAME/contents/$SCRIPTS_DIR/version.txt"

            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $githubToken")
                .header("Accept", "application/vnd.github.v3+json")
                .get()
                .build()

            val response = client.newCall(request).execute()

            if (response.isSuccessful) {
                val jsonString = response.body?.string() ?: "{}"
                // Parse JSON response for GitHub API
                val content = extractContentFromGitHubApiResponse(jsonString)
                val versionText = content?.trim() ?: "0"
                versionText.toIntOrNull() ?: 0
            } else {
                Log.e(TAG, "❌ GitHub API error ${response.code} for version check")
                0
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting remote version: ${e.message}")
            0
        }
    }

    /**
     * Download all scripts from GitHub API (supports private repos)
     */
    suspend fun downloadAllScripts(context: Context): Boolean = withContext(Dispatchers.IO) {
        Log.d(TAG, "🚀 Starting script download from GitHub (private repo)...")

        return@withContext try {
            if (!ensureToken(context)) {
                return@withContext false
            }

            val scriptsDir = getScriptsDir(context)

            // Create directory if it doesn't exist
            if (!scriptsDir.exists()) {
                scriptsDir.mkdirs()
            }

            var successCount = 0

            // First try GitHub API for private repo access
            REQUIRED_FILES.forEach { fileName ->
                try {
                    if (downloadSingleFileViaApi(fileName, scriptsDir)) {
                        successCount++
                        Log.d(TAG, "✅ Downloaded via API: $fileName")
                    } else {
                        // Fallback to raw URL with token
                        Log.w(TAG, "⚠️ API failed for $fileName, trying raw URL...")
                        if (downloadSingleFileViaRawUrl(fileName, scriptsDir)) {
                            successCount++
                            Log.d(TAG, "✅ Downloaded via raw URL: $fileName")
                        } else {
                            Log.e(TAG, "❌ Failed: $fileName")
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "❌ Error downloading $fileName: ${e.message}")
                }

                // Small delay to avoid rate limiting
                delay(100)
            }

            val success = successCount > REQUIRED_FILES.size / 2 // More than 50% success
            Log.d(TAG, "📊 Download complete: $successCount/${REQUIRED_FILES.size} files")

            if (success) {
                saveDownloadTimestamp(context)
                Log.d(TAG, "🎉 Scripts downloaded successfully")
            } else {
                Log.e(TAG, "⚠️ Partial download - ${REQUIRED_FILES.size - successCount} files failed")
            }

            success
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error downloading scripts: ${e.message}", e)
            false
        }
    }

    /**
     * Download via GitHub API (works with private repos)
     */
    private suspend fun downloadSingleFileViaApi(fileName: String, targetDir: File): Boolean = withContext(Dispatchers.IO) {
        // Note: ensureToken already called before this method, so githubToken is non-null
        return@withContext try {
            val url = "$GITHUB_API_BASE/repos/$REPO_OWNER/$REPO_NAME/contents/$SCRIPTS_DIR/$fileName"

            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $githubToken")
                .header("Accept", "application/vnd.github.v3+json")
                .get()
                .build()

            val response = client.newCall(request).execute()

            when {
                response.isSuccessful -> {
                    val jsonString = response.body?.string() ?: "{}"
                    val content = extractContentFromGitHubApiResponse(jsonString)

                    if (content != null && content.isNotEmpty()) {
                        val outputFile = File(targetDir, fileName)
                        outputFile.writeText(content)
                        true
                    } else {
                        Log.e(TAG, "❌ Empty content for $fileName")
                        false
                    }
                }
                response.code == HttpURLConnection.HTTP_NOT_FOUND -> {
                    Log.w(TAG, "⚠️ File not found via API: $fileName")
                    false
                }
                else -> {
                    Log.e(TAG, "❌ API HTTP ${response.code} for $fileName")
                    false
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ API download error for $fileName: ${e.message}")
            false
        }
    }

    /**
     * Download via raw URL with token (alternative method)
     */
    private suspend fun downloadSingleFileViaRawUrl(fileName: String, targetDir: File): Boolean = withContext(Dispatchers.IO) {
        // Note: ensureToken already called before this method, so githubToken is non-null
        return@withContext try {
            val url = "$GITHUB_RAW_BASE/$REPO_OWNER/$REPO_NAME/$BRANCH/$SCRIPTS_DIR/$fileName"

            val request = Request.Builder()
                .url(url)
                .header("Authorization", "token $githubToken")
                .get()
                .build()

            val response = client.newCall(request).execute()

            when {
                response.isSuccessful -> {
                    val content = response.body?.string() ?: ""

                    if (content.isNotEmpty()) {
                        val outputFile = File(targetDir, fileName)
                        outputFile.writeText(content)
                        true
                    } else {
                        Log.e(TAG, "❌ Empty content for $fileName")
                        false
                    }
                }
                response.code == HttpURLConnection.HTTP_NOT_FOUND -> {
                    Log.w(TAG, "⚠️ File not found via raw URL: $fileName")
                    false
                }
                else -> {
                    Log.e(TAG, "❌ Raw URL HTTP ${response.code} for $fileName")
                    false
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Raw URL download error for $fileName: ${e.message}")
            false
        }
    }

    /**
     * Extract content from GitHub API response
     */
    private fun extractContentFromGitHubApiResponse(jsonString: String): String? {
        return try {
            // GitHub API returns Base64 encoded content for files
            val json = JSONObject(jsonString)
            val content = json.optString("content", "")
            val encoding = json.optString("encoding", "")

            if (content.isEmpty()) {
                Log.w(TAG, "⚠️ Empty content in GitHub API response")
                return ""
            }

            if (encoding == "base64" && content.isNotEmpty()) {
                // Decode Base64 - handle potential padding issues
                val decodedBytes = Base64.decode(content, Base64.DEFAULT)
                String(decodedBytes, Charsets.UTF_8)
            } else {
                content
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error parsing GitHub API response: ${e.message}")
            null
        }
    }

    /**
     * Save download timestamp
     */
    private fun saveDownloadTimestamp(context: Context) {
        try {
            val timestampFile = File(getScriptsDir(context), "download_timestamp.txt")
            timestampFile.writeText(System.currentTimeMillis().toString())
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving timestamp: ${e.message}")
        }
    }

    /**
     * Get last download time
     */
    fun getLastDownloadTime(context: Context): Long {
        return try {
            val timestampFile = File(getScriptsDir(context), "download_timestamp.txt")
            if (timestampFile.exists()) {
                timestampFile.readText().toLongOrNull() ?: 0
            } else {
                0
            }
        } catch (e: Exception) {
            0
        }
    }

    /**
     * Force update scripts (manual trigger)
     */
    suspend fun forceUpdate(context: Context): Boolean = withContext(Dispatchers.IO) {
        Log.d(TAG, "🔄 Force updating scripts...")
        if (!ensureToken(context)) {
            return@withContext false
        }
        return@withContext downloadAllScripts(context)
    }

    /**
     * Get scripts directory
     */
    fun getScriptsDir(context: Context): File {
        return File(context.filesDir, "python_scripts")
    }

    /**
     * Clear all scripts
     */
    fun clearScripts(context: Context) {
        try {
            val scriptsDir = getScriptsDir(context)
            if (scriptsDir.exists() && scriptsDir.isDirectory) {
                scriptsDir.listFiles()?.forEach { it.delete() }
                scriptsDir.delete()
                Log.d(TAG, "🧹 Cleared all scripts")
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error clearing scripts: ${e.message}")
        }
    }

    /**
     * Get scripts status info
     */
    suspend fun getStatusInfo(context: Context): String = withContext(Dispatchers.IO) {
        return@withContext try {
            val scriptsDir = getScriptsDir(context)

            if (!scriptsDir.exists()) {
                return@withContext "No scripts downloaded"
            }

            val files = scriptsDir.listFiles() ?: emptyArray()
            val pyFiles = files.count { it.name.endsWith(".py") && it.name != "__init__.py" }
            val jsonFiles = files.count { it.name.endsWith(".json") }
            val totalSize = files.sumOf { it.length() }
            val version = getLocalVersion(context)
            val lastDownload = getLastDownloadTime(context)
            val hasToken = hasGitHubToken()

            val sizeKB = String.format("%.2f", totalSize / 1024.0)
            val lastDownloadStr = if (lastDownload > 0) {
                val hoursAgo = (System.currentTimeMillis() - lastDownload) / (1000 * 60 * 60)
                "$hoursAgo hours ago"
            } else {
                "Never"
            }

            "v$version • $pyFiles scripts • $jsonFiles configs • ${sizeKB}KB • Updated: $lastDownloadStr • Token: ${if (hasToken) "✅" else "❌"}"
        } catch (e: Exception) {
            "Error getting status"
        }
    }
}
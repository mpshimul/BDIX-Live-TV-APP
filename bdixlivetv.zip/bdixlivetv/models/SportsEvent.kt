package com.shimulfp.bdixlivetv.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Live Sports Event Model
 * Represents a live sports event that can be streamed
 */
@Parcelize
data class SportsEvent(
    val id: String,
    val title: String,
    val sport: String = "",           // e.g., "Football", "Cricket", "Basketball"
    val league: String = "",         // e.g., "Premier League", "NBA"
    val teams: String = "",          // e.g., "Man Utd vs Chelsea"
    val startTime: String = "",      // e.g., "15:00", "2024-03-17 15:00"
    val thumbnail: String = "",      // Thumbnail image URL
    val streamUrls: List<String> = emptyList(),  // Multiple stream URLs (BD, IN, etc.)
    val isLive: Boolean = false,    // Whether the event is currently live
    val category: String = "",       // Additional category info
    val language: String = "English", // Stream language
    val quality: String = "HD",      // Stream quality
    val viewers: String = "",        // Number of viewers
    val description: String = ""     // Event description
) : Parcelable {

    /**
     * Get display name for the sport
     */
    fun getDisplaySport(): String {
        return if (sport.isNotEmpty()) sport else "Sports"
    }

    /**
     * Get formatted time display
     */
    fun getFormattedTime(): String {
        return if (startTime.isNotEmpty()) {
            // If contains date, show shorter format
            if (startTime.contains("-") && startTime.contains(":")) {
                val parts = startTime.split(" ")
                if (parts.size >= 2) {
                    parts[1]  // Show only the time part
                } else {
                    startTime
                }
            } else {
                startTime
            }
        } else {
            "Live"
        }
    }

    /**
     * Get status badge text
     */
    fun getStatusText(): String {
        return if (isLive) "🔴 LIVE" else getFormattedTime()
    }

    /**
     * Get the first available stream URL (for backward compatibility)
     */
    fun getFirstStreamUrl(): String {
        return streamUrls.firstOrNull() ?: ""
    }

    /**
     * Check if event has any stream URLs
     */
    fun hasStreams(): Boolean {
        return streamUrls.isNotEmpty()
    }
}

/**
 * Sports Data Container
 * Wrapper for the JSON response from the Python script
 */
@Parcelize
data class SportsData(
    val events: List<SportsEvent> = emptyList(),
    val lastUpdated: Long = System.currentTimeMillis(),
    val version: String = "1.0"
) : Parcelable {

    /**
     * Get live events only
     */
    fun getLiveEvents(): List<SportsEvent> {
        return events.filter { it.isLive }
    }

    /**
     * Get upcoming events
     */
    fun getUpcomingEvents(): List<SportsEvent> {
        return events.filter { !it.isLive }
    }

    /**
     * Get events grouped by sport
     */
    fun getEventsBySport(): Map<String, List<SportsEvent>> {
        return events.groupBy { it.sport.ifEmpty { "Other" } }
    }

    /**
     * Check if there are any events
     */
    fun hasEvents(): Boolean {
        return events.isNotEmpty()
    }
}

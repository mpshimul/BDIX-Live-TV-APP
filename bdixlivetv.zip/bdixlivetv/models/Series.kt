package com.shimulfp.bdixlivetv.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Series model with seasons and episodes
 * Similar structure to Netflix/Prime Video
 */
@Parcelize
data class Series(
    val id: String,
    val title: String,
    val originalTitle: String = "",
    val year: String = "",
    val rating: String = "",
    val quality: String = "HD",
    val poster: String = "",
    val backdrop: String = "",
    val description: String = "",
    val genres: List<String> = emptyList(),
    val cast: List<String> = emptyList(),
    val director: String = "",
    val language: String = "Hindi",
    val seasons: List<Season> = emptyList(),
    val subtitles: List<Subtitle> = emptyList(),
    val source: String = "BDIX",
    val serverName: String = "",
    val category: SeriesCategory = SeriesCategory.KOREAN,
    val folderUrl: String = "",
    val lastModified: String = "",
    val lastModifiedTimestamp: Long = 0,
    val folderModified: String = "",
    val folderModifiedTimestamp: Long = 0,
    val addedDate: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false,
    val totalEpisodes: Int = 0,
    val status: String = "Completed"  // Completed, Ongoing, etc.
) : Parcelable {

    /**
     * Get total number of seasons
     */
    fun getSeasonCount(): Int = seasons.size

    /**
     * Get total episodes across all seasons
     */
    fun getTotalEpisodeCount(): Int = seasons.sumOf { it.episodes.size }

    /**
     * Get the latest season
     */
    fun getLatestSeason(): Season? = seasons.maxByOrNull { it.seasonNumber }

    /**
     * Get a specific season
     */
    fun getSeason(seasonNumber: Int): Season? =
        seasons.find { it.seasonNumber == seasonNumber }

    /**
     * Get quality badge color
     */
    fun getQualityBadgeColor(): Long {
        return when (quality.uppercase()) {
            "4K", "2160P" -> 0xFF9C27B0  // Purple
            "1080P" -> 0xFF4CAF50        // Green
            "720P" -> 0xFF2196F3         // Blue
            "BLURAY" -> 0xFF00BCD4       // Cyan
            else -> 0xFF757575           // Gray
        }
    }

    /**
     * Get formatted added date
     */
    fun getFormattedAddedDate(): String {
        return if (folderModified.isEmpty()) "" else "Added: $folderModified"
    }

    /**
     * Get category display name
     */
    fun getCategoryDisplayName(): String = category.displayName
}

/**
 * Season model containing episodes
 */
@Parcelize
data class Season(
    val seasonNumber: Int,
    val title: String = "",
    val description: String = "",
    val poster: String = "",
    val year: String = "",
    val episodeCount: Int = 0,
    val episodes: List<Episode> = emptyList(),
    val folderUrl: String = ""
) : Parcelable {

    /**
     * Get the first episode
     */
    fun getFirstEpisode(): Episode? = episodes.firstOrNull()

    /**
     * Get the next episode after a given one
     */
    fun getNextEpisode(currentEpisode: Int): Episode? =
        episodes.find { it.episodeNumber == currentEpisode + 1 }

    /**
     * Get a specific episode
     */
    fun getEpisode(episodeNumber: Int): Episode? =
        episodes.find { it.episodeNumber == episodeNumber }
}

/**
 * Episode model with stream URLs
 */
@Parcelize
data class Episode(
    val id: String,
    val episodeNumber: Int,
    val seasonNumber: Int = 0,  // Added seasonNumber to track which season the episode belongs to
    val title: String = "",
    val description: String = "",
    val duration: String = "",
    val quality: String = "HD",
    val poster: String = "",
    val streamUrls: List<StreamUrl> = emptyList(),
    val subtitles: List<Subtitle> = emptyList(),
    val airDate: String = "",
    val folderUrl: String = "",
    val lastModified: String = "",
    val watchProgress: Float = 0f,
    val lastWatched: Long = 0
) : Parcelable {

    /**
     * Get best stream URL
     */
    fun getBestStreamUrl(): String? {
        return streamUrls.firstOrNull { it.isWorking }?.url
            ?: streamUrls.firstOrNull()?.url
    }

    /**
     * Get formatted episode name (e.g., "E01 - Pilot")
     */
    fun getFormattedName(): String {
        val epNum = String.format("%02d", episodeNumber)
        return if (title.isNotEmpty()) {
            "E$epNum - $title"
        } else {
            "E$epNum"
        }
    }
}

/**
 * Series categories
 */
enum class SeriesCategory(val displayName: String, val apiName: String) {
    ALL("All Series", "ALL"),
    KOREAN("Korean Dramas", "KOREAN"),
    HINDI("Hindi Series", "HINDI"),
    ENGLISH("English Series", "ENGLISH"),
    BENGALI("Bengali Series", "BENGALI"),
    ANIME("Anime Series", "ANIME"),
    TURKISH("Turkish Series", "TURKISH"),
    THAI("Thai Series", "THAI"),
    WEB_SERIES("Web Series", "WEB_SERIES"),
    ALL_SERIES("All TV & Web Series", "ALL_SERIES");

    companion object {
        fun fromApiName(name: String): SeriesCategory {
            // Handle ALL_SERIES as a special case - treat as ENGLISH for individual series
            if (name == "ALL_SERIES") {
                return ENGLISH
            }

            // Find matching category
            return values().find { it.apiName == name } ?: ENGLISH
        }
    }
}

/**
 * Series download model for offline viewing
 */
@Parcelize
data class SeriesDownload(
    val id: String,
    val seriesId: String,
    val seriesTitle: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val episodeTitle: String,
    val filePath: String,
    val fileSize: Long = 0,
    val quality: String = "HD",
    val status: DownloadStatus = DownloadStatus.PENDING,
    val progress: Int = 0,
    val downloadedSize: Long = 0,
    val error: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val poster: String = "",
    val downloadUrl: String = ""
) : Parcelable {

    /**
     * Get formatted display name
     */
    fun getDisplayName(): String {
        val season = String.format("S%02d", seasonNumber)
        val episode = String.format("E%02d", episodeNumber)
        return "$seriesTitle - $season$episode"
    }

    /**
     * Check if this download can be resumed
     */
    fun canResume(): Boolean {
        return status == DownloadStatus.PAUSED || status == DownloadStatus.FAILED
    }

    /**
     * Check if this download can be cancelled
     */
    fun canCancel(): Boolean {
        return status == DownloadStatus.DOWNLOADING || status == DownloadStatus.PENDING
    }

    /**
     * Create from episode
     */
    companion object {
        fun fromEpisode(
            series: Series,
            season: Season,
            episode: Episode,
            downloadUrl: String
        ): SeriesDownload {
            return SeriesDownload(
                id = "series_${series.id}_S${season.seasonNumber}_E${episode.episodeNumber}",
                seriesId = series.id,
                seriesTitle = series.title,
                seasonNumber = season.seasonNumber,
                episodeNumber = episode.episodeNumber,
                episodeTitle = episode.title,
                filePath = "",  // Will be set by DownloadManager
                downloadUrl = downloadUrl,
                quality = episode.quality,
                poster = episode.poster.ifEmpty { series.poster }
            )
        }
    }
}

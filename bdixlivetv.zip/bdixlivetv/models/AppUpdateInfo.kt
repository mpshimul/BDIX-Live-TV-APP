package com.shimulfp.bdixlivetv.models

/**
 * Data class representing app update information
 * Now uses currentVersionName for semantic version comparison.
 */
data class AppUpdateInfo(
    val versionName: String,           // remote version name (e.g., "1.2.3")
    val versionCode: Int,              // remote version code (derived from tag, optional)
    val currentVersionName: String,    // current installed version name (BuildConfig.VERSION_NAME)
    val releaseNotes: String,
    val downloadUrl: String,
    val fileSize: Long,
    val releaseUrl: String,
    val publishedAt: String
) {
    // Helper functions to extract version components
    private fun getMajor(version: String): Int =
        version.trimStart('v').split('.').getOrNull(0)?.toIntOrNull() ?: 0

    private fun getMinor(version: String): Int =
        version.trimStart('v').split('.').getOrNull(1)?.toIntOrNull() ?: 0

    private fun getPatch(version: String): Int =
        version.trimStart('v').split('.').getOrNull(2)?.toIntOrNull() ?: 0

    /**
     * Check if this is a major update (major version increased)
     */
    fun isMajorUpdate(): Boolean =
        getMajor(versionName) > getMajor(currentVersionName)

    /**
     * Check if this is a minor update (same major, increased minor)
     */
    fun isMinorUpdate(): Boolean =
        getMajor(versionName) == getMajor(currentVersionName) &&
                getMinor(versionName) > getMinor(currentVersionName)

    /**
     * Get version change description
     */
    fun getUpdateTypeDescription(): String = when {
        isMajorUpdate() -> "Major update"
        isMinorUpdate() -> "Minor update"
        else -> "Patch update"
    }
}
package com.shimulfp.bdixlivetv.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shimulfp.bdixlivetv.SportsService
import com.shimulfp.bdixlivetv.CacheStatus
import com.shimulfp.bdixlivetv.models.SportsData
import com.shimulfp.bdixlivetv.models.SportsEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * SportsViewModel - Manages state for Live Sports Events
 */
class SportsViewModel : ViewModel() {
    private val TAG = "SportsViewModel"

    // UI State
    private val _uiState = MutableStateFlow<SportsUiState>(SportsUiState.Loading)
    val uiState: StateFlow<SportsUiState> = _uiState.asStateFlow()

    // Sports data
    private val _sportsData = MutableStateFlow<SportsData?>(null)
    val sportsData: StateFlow<SportsData?> = _sportsData.asStateFlow()

    // Live events (filtered)
    private val _liveEvents = MutableStateFlow<List<SportsEvent>>(emptyList())
    val liveEvents: StateFlow<List<SportsEvent>> = _liveEvents.asStateFlow()

    // Upcoming events (filtered)
    private val _upcomingEvents = MutableStateFlow<List<SportsEvent>>(emptyList())
    val upcomingEvents: StateFlow<List<SportsEvent>> = _upcomingEvents.asStateFlow()

    // Cache status
    private val _cacheStatus = MutableStateFlow<CacheStatus>(CacheStatus.NotAvailable)
    val cacheStatus: StateFlow<CacheStatus> = _cacheStatus.asStateFlow()

    // Refresh state
    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    /**
     * Load sports data (from cache or network)
     */
    fun loadSportsData(context: Context) {
        viewModelScope.launch {
            try {
                _uiState.value = SportsUiState.Loading

                val data = SportsService.loadSportsData(context)

                if (data != null) {
                    _sportsData.value = data
                    _liveEvents.value = data.getLiveEvents()
                    _upcomingEvents.value = data.getUpcomingEvents()

                    if (data.hasEvents()) {
                        _uiState.value = SportsUiState.Success
                        Log.d(TAG, "✅ Loaded ${data.events.size} sports events")
                    } else {
                        _uiState.value = SportsUiState.Empty
                        Log.d(TAG, "ℹ️ No sports events available")
                    }
                } else {
                    _uiState.value = SportsUiState.Error("Failed to load sports data")
                    Log.e(TAG, "❌ Failed to load sports data")
                }

                // Update cache status
                _cacheStatus.value = SportsService.getCacheStatus(context)
            } catch (e: Exception) {
                _uiState.value = SportsUiState.Error(e.message ?: "Unknown error")
                Log.e(TAG, "❌ Error loading sports data: ${e.message}", e)
            }
        }
    }

    /**
     * Refresh sports data from GitHub and Python script
     */
    fun refreshSportsData(context: Context) {
        viewModelScope.launch {
            try {
                _isRefreshing.value = true

                val data = SportsService.refreshSportsData(context)

                if (data != null) {
                    _sportsData.value = data
                    _liveEvents.value = data.getLiveEvents()
                    _upcomingEvents.value = data.getUpcomingEvents()

                    if (data.hasEvents()) {
                        _uiState.value = SportsUiState.Success
                        Log.d(TAG, "✅ Refreshed ${data.events.size} sports events")
                    } else {
                        _uiState.value = SportsUiState.Empty
                        Log.d(TAG, "ℹ️ No sports events available after refresh")
                    }
                } else {
                    _uiState.value = SportsUiState.Error("Failed to refresh sports data")
                    Log.e(TAG, "❌ Failed to refresh sports data")
                }

                // Update cache status
                _cacheStatus.value = SportsService.getCacheStatus(context)
            } catch (e: Exception) {
                _uiState.value = SportsUiState.Error(e.message ?: "Unknown error")
                Log.e(TAG, "❌ Error refreshing sports data: ${e.message}", e)
            } finally {
                _isRefreshing.value = false
            }
        }
    }

    /**
     * Handle sports event click (open video player)
     */
    fun onEventClick(event: SportsEvent) {
        Log.d(TAG, "🎬 Sports event clicked: ${event.title}")
        // TODO: Navigate to video player with event.streamUrl
    }

    /**
     * Clear cache
     */
    fun clearCache(context: Context) {
        viewModelScope.launch {
            try {
                SportsService.clearCache(context)
                _sportsData.value = null
                _liveEvents.value = emptyList()
                _upcomingEvents.value = emptyList()
                _uiState.value = SportsUiState.Loading
                _cacheStatus.value = CacheStatus.NotAvailable
                Log.d(TAG, "🗑️ Sports cache cleared")

                // Reload data
                loadSportsData(context)
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error clearing cache: ${e.message}")
            }
        }
    }
}

/**
 * UI State for Sports Section
 */
sealed class SportsUiState {
    object Loading : SportsUiState()
    object Success : SportsUiState()
    object Empty : SportsUiState()
    data class Error(val message: String) : SportsUiState()
}

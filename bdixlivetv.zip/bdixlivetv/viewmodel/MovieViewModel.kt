package com.shimulfp.bdixlivetv.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shimulfp.bdixlivetv.data.MovieRepository
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.models.MovieCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MovieViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application

    private lateinit var repository: MovieRepository

    // ============ UI STATES ============

    private val _uiState = MutableStateFlow<MovieUiState>(MovieUiState.Loading)
    val uiState: StateFlow<MovieUiState> = _uiState.asStateFlow()

    private val _allMovies = MutableStateFlow<List<Movie>>(emptyList())
    val allMovies: StateFlow<List<Movie>> = _allMovies.asStateFlow()

    private val _displayedMovies = MutableStateFlow<List<Movie>>(emptyList())
    val displayedMovies: StateFlow<List<Movie>> = _displayedMovies.asStateFlow()

    private val _recentlyAdded = MutableStateFlow<List<Movie>>(emptyList())
    val recentlyAdded: StateFlow<List<Movie>> = _recentlyAdded.asStateFlow()

    private val _continueWatching = MutableStateFlow<List<Movie>>(emptyList())
    val continueWatching: StateFlow<List<Movie>> = _continueWatching.asStateFlow()

    private val _favorites = MutableStateFlow<List<Movie>>(emptyList())
    val favorites: StateFlow<List<Movie>> = _favorites.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Movie>>(emptyList())
    val searchResults: StateFlow<List<Movie>> = _searchResults.asStateFlow()

    private val _selectedCategory = MutableStateFlow(MovieCategory.ALL)
    val selectedCategory: StateFlow<MovieCategory> = _selectedCategory.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _syncStatus = MutableStateFlow("Checking for updates...")
    val syncStatus: StateFlow<String> = _syncStatus.asStateFlow()

    private val _cacheInfo = MutableStateFlow<MovieRepository.CacheInfo?>(null)
    val cacheInfo: StateFlow<MovieRepository.CacheInfo?> = _cacheInfo.asStateFlow()

    private val _syncInfo = MutableStateFlow<MovieRepository.SyncInfo?>(null)
    val syncInfo: StateFlow<MovieRepository.SyncInfo?> = _syncInfo.asStateFlow()

    // ============ INITIALIZATION ============

    init {
        Log.d("MovieViewModel", "🎬 MovieViewModel initialized")

        // Initialize repository in a coroutine since getInstance() is suspend
        viewModelScope.launch {
            try {
                repository = MovieRepository.getInstance(appContext)
                Log.d("MovieViewModel", "✅ Repository initialized successfully")
                loadMoviesSmart()
            } catch (e: Exception) {
                Log.e("MovieViewModel", "❌ Failed to initialize repository: ${e.message}", e)
                _uiState.value = MovieUiState.Error("Failed to initialize: ${e.message}")
            }
        }
    }

    /**
     * Smart loading strategy:
     * 1. Try local GitHub cache first (fastest)
     * 2. Try GitHub download if no local cache
     * 3. Fallback to scraping only if both fail
     */
    fun loadMoviesSmart() {
        viewModelScope.launch {
            _uiState.value = MovieUiState.Loading
            _isRefreshing.value = true
            _syncStatus.value = "Loading movies..."

            try {
                Log.d("MovieViewModel", "🚀 ULTRA-FAST GITHUB-FIRST LOADING...")

                // Check if repository is initialized
                if (!::repository.isInitialized) {
                    repository = MovieRepository.getInstance(appContext)
                }

                // Get movies using ultra-simple strategy
                val movies = repository.getAllMovies()

                if (movies.isNotEmpty()) {
                    // Update movies
                    _allMovies.value = movies
                    _displayedMovies.value = movies

                    // Load sections
                    _recentlyAdded.value = getRecentlyAdded(movies)

                    // These are suspend functions
                    _continueWatching.value = repository.getContinueWatching()
                    _favorites.value = repository.getFavoriteMovies()

                    // Update status info
                    updateStatusInfo()

                    // Update UI state
                    _uiState.value = MovieUiState.Success(movies.size)

                    val syncInfo = repository.getSyncInfo()
                    _syncStatus.value = "✅ Loaded ${movies.size} movies from ${syncInfo.getSource()}"

                    Log.d("MovieViewModel", "✅ ULTRA-FAST loading complete: ${movies.size} movies")

                } else {
                    _uiState.value = MovieUiState.Empty
                    _syncStatus.value = "No movies found - please check connection"
                    Log.d("MovieViewModel", "⚠️ No movies loaded from any source")
                }

            } catch (e: Exception) {
                Log.e("MovieViewModel", "❌ Loading error: ${e.message}", e)
                _uiState.value = MovieUiState.Error(e.message ?: "Unknown error")
                _syncStatus.value = "Error: ${e.message}"

            } finally {
                _isRefreshing.value = false
            }
        }
    }

    /**
     * Fallback to cache if smart loading fails
     */
    private suspend fun loadFromCacheFallback() {
        try {
            Log.d("MovieViewModel", "🔄 Trying cache fallback...")

            if (!::repository.isInitialized) {
                repository = MovieRepository.getInstance(appContext)
            }

            val cachedMovies = repository.getAllMovies() // This will use cache

            if (cachedMovies.isNotEmpty()) {
                _allMovies.value = cachedMovies
                _displayedMovies.value = cachedMovies
                _recentlyAdded.value = getRecentlyAdded(cachedMovies)

                updateStatusInfo()
                _uiState.value = MovieUiState.Success(cachedMovies.size)
                _syncStatus.value = "✅ Loaded ${cachedMovies.size} movies from cache (fallback)"

                Log.d("MovieViewModel", "✅ Cache fallback successful: ${cachedMovies.size} movies")
            }
        } catch (e: Exception) {
            Log.e("MovieViewModel", "❌ Cache fallback also failed: ${e.message}")
        }
    }

    /**
     * Update status information
     */
    private fun updateStatusInfo() {
        if (::repository.isInitialized) {
            _cacheInfo.value = repository.getCacheInfo()
            _syncInfo.value = repository.getSyncInfo()

            val cache = _cacheInfo.value
            val sync = _syncInfo.value

            if (cache != null && sync != null) {
                val status = buildString {
                    append("Movies: ${_allMovies.value.size}")
                    append(" | Cache: ${cache.getStatus()}")
                    append(" | Source: ${sync.getSource()}")
                    append(" | Last sync: ${sync.getStatus()}")
                }
                _syncStatus.value = status
            }
        }
    }

    // ============ PUBLIC ACTIONS ============

    /**
     * Force refresh (scrape fresh and upload to GitHub)
     */
    fun forceRefresh() {
        viewModelScope.launch {
            _isRefreshing.value = true
            _syncStatus.value = "Scraping fresh movies..."

            try {
                Log.d("MovieViewModel", "🔄 Force refresh requested")

                if (!::repository.isInitialized) {
                    repository = MovieRepository.getInstance(appContext)
                }

                val movies = repository.forceRefresh()

                if (movies.isNotEmpty()) {
                    // Update movies
                    _allMovies.value = movies
                    _displayedMovies.value = movies
                    _recentlyAdded.value = getRecentlyAdded(movies)

                    // Update status
                    updateStatusInfo()

                    _syncStatus.value = "✅ Refreshed ${movies.size} movies"
                    Log.d("MovieViewModel", "✅ Force refresh complete: ${movies.size} movies")

                } else {
                    _syncStatus.value = "Refresh failed - no movies found"
                    Log.d("MovieViewModel", "⚠️ Force refresh returned no movies")
                }

            } catch (e: Exception) {
                Log.e("MovieViewModel", "❌ Force refresh error: ${e.message}")
                _syncStatus.value = "Refresh error: ${e.message}"

            } finally {
                _isRefreshing.value = false
            }
        }
    }

    /**
     * Refresh (re-run smart loading)
     */
    fun refresh() {
        loadMoviesSmart()
    }

    /**
     * Clear cache and reload
     */
    fun clearCacheAndReload() {
        viewModelScope.launch {
            _isRefreshing.value = true
            _syncStatus.value = "Clearing cache..."

            try {
                if (!::repository.isInitialized) {
                    repository = MovieRepository.getInstance(appContext)
                }

                repository.clearCache()
                loadMoviesSmart()

                Log.d("MovieViewModel", "✅ Cache cleared and reloaded")

            } catch (e: Exception) {
                Log.e("MovieViewModel", "❌ Clear cache error: ${e.message}")
                _syncStatus.value = "Clear cache error: ${e.message}"

            } finally {
                _isRefreshing.value = false
            }
        }
    }

    // ============ BACKWARD COMPATIBILITY ============
    /**
     * @deprecated Use [loadMoviesSmart] instead for smart loading strategy
     * or [forceRefresh] for force scraping and uploading
     */
    @Deprecated(
        "Use loadMoviesSmart() for smart loading or forceRefresh() for force scraping",
        ReplaceWith("if (forceRefresh) forceRefresh() else loadMoviesSmart()")
    )
    fun loadMoviesWithGitHubSync(forceRefresh: Boolean = false) {
        if (forceRefresh) {
            forceRefresh()
        } else {
            loadMoviesSmart()
        }
    }

    /**
     * Select category
     */
    fun selectCategory(category: MovieCategory) {
        _selectedCategory.value = category
        viewModelScope.launch {
            _displayedMovies.value = if (category == MovieCategory.ALL) {
                _allMovies.value
            } else {
                _allMovies.value.filter { it.category == category }
            }
        }
    }

    /**
     * Search movies
     */
    fun search(query: String) {
        _searchQuery.value = query
        viewModelScope.launch {
            if (query.isBlank()) {
                _searchResults.value = emptyList()
            } else {
                if (!::repository.isInitialized) {
                    repository = MovieRepository.getInstance(appContext)
                }
                _searchResults.value = repository.searchMovies(query)
            }
        }
    }

    /**
     * Clear search
     */
    fun clearSearch() {
        _searchQuery.value = ""
        _searchResults.value = emptyList()
    }

    /**
     * Toggle favorite
     */
    fun toggleFavorite(movie: Movie) {
        viewModelScope.launch {
            if (!::repository.isInitialized) {
                repository = MovieRepository.getInstance(appContext)
            }
            repository.toggleFavorite(movie.id)
            _favorites.value = repository.getFavoriteMovies()
        }
    }

    /**
     * Check if movie is favorite
     */
    fun isFavorite(movieId: String): Boolean {
        return if (::repository.isInitialized) {
            repository.isFavorite(movieId)
        } else {
            false
        }
    }

    /**
     * Save watch progress - FIXED: now calls suspend functions inside coroutine
     */
    fun saveWatchProgress(movieId: String, progress: Float, position: Long) {
        viewModelScope.launch {
            // Ensure repository is initialized
            if (!::repository.isInitialized) {
                repository = MovieRepository.getInstance(appContext)
            }
            // Save progress
            repository.saveWatchProgress(movieId, progress, position)
            // Refresh continue watching list
            _continueWatching.value = repository.getContinueWatching()
        }
    }

    /**
     * Get watch progress
     */
    fun getWatchProgress(movieId: String): MovieRepository.WatchRecord? {
        return if (::repository.isInitialized) {
            repository.getWatchProgress(movieId)
        } else {
            null
        }
    }

    // ============ HELPER METHODS ============

    private fun getRecentlyAdded(movies: List<Movie>, limit: Int = 20): List<Movie> {
        return movies
            .sortedByDescending { it.folderModifiedTimestamp }
            .take(limit)
    }

    fun getMoviesByCategory(category: MovieCategory): List<Movie> {
        return if (category == MovieCategory.ALL) {
            _allMovies.value
        } else {
            _allMovies.value.filter { it.category == category }
        }
    }

    fun getMovieById(id: String): Movie? {
        return _allMovies.value.find { it.id == id }
    }

    fun getRelatedMovies(movie: Movie, limit: Int = 10): List<Movie> {
        return _allMovies.value
            .filter { it.id != movie.id && (it.category == movie.category || it.year == movie.year) }
            .shuffled()
            .take(limit)
    }

    fun getCacheInfo(): MovieRepository.CacheInfo {
        return if (::repository.isInitialized) {
            repository.getCacheInfo()
        } else {
            MovieRepository.CacheInfo(exists = false, ageMinutes = 0, sizeKb = 0, isExpired = true)
        }
    }

    fun getSyncInfo(): MovieRepository.SyncInfo {
        return if (::repository.isInitialized) {
            repository.getSyncInfo()
        } else {
            MovieRepository.SyncInfo()
        }
    }

    /**
     * Get detailed sync status for UI
     */
    fun getDetailedSyncStatus(): String {
        if (!::repository.isInitialized) {
            return "Repository not initialized"
        }

        val cache = repository.getCacheInfo()
        val sync = repository.getSyncInfo()
        val moviesCount = _allMovies.value.size

        return buildString {
            append("📊 Status:\n")
            append("• Movies: $moviesCount\n")
            append("• Cache: ${cache.getStatus()}\n")
            append("• Source: ${sync.getSource()}\n")
            append("• Last sync: ${sync.getStatus()}")
        }
    }

    /**
     * Check if data needs refresh
     */
    fun needsRefresh(): Boolean {
        if (!::repository.isInitialized) return true

        val cache = repository.getCacheInfo()
        return cache.isExpired || cache.ageMinutes > 120 // > 2 hours
    }
}

// ============ UI STATE ============

sealed class MovieUiState {
    object Loading : MovieUiState()
    data class Success(val count: Int) : MovieUiState()
    object Empty : MovieUiState()
    data class Error(val message: String) : MovieUiState()
}
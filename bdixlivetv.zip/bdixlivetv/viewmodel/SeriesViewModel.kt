package com.shimulfp.bdixlivetv.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shimulfp.bdixlivetv.data.SeriesRepository
import com.shimulfp.bdixlivetv.models.Series
import com.shimulfp.bdixlivetv.models.SeriesCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel for managing Series data with GitHub sync support
 */
class SeriesViewModel(application: Application) : AndroidViewModel(application) {

    private val TAG = "SeriesViewModel"

    // Repository - initialized lazily in coroutine context
    private var _repository: SeriesRepository? = null
    private val repository: SeriesRepository
        get() {
            check(_repository != null) { "SeriesRepository not initialized" }
            return _repository!!
        }

    // All series
    private val _allSeries = MutableStateFlow<List<Series>>(emptyList())
    val allSeries: StateFlow<List<Series>> = _allSeries.asStateFlow()

    // Filtered series (by category, search, etc.)
    private val _filteredSeries = MutableStateFlow<List<Series>>(emptyList())
    val filteredSeries: StateFlow<List<Series>> = _filteredSeries.asStateFlow()

    // UI state
    private val _uiState = MutableStateFlow<SeriesUiState>(SeriesUiState.Idle)
    val uiState: StateFlow<SeriesUiState> = _uiState.asStateFlow()

    // Current filters
    private var currentCategory: SeriesCategory = SeriesCategory.ALL
    private var currentSearchQuery: String = ""

    init {
        Log.d(TAG, "SeriesViewModel initialized")
    }

    /**
     * Ensure repository is initialized (must be called from coroutine)
     */
    private suspend fun ensureRepositoryInitialized() {
        if (_repository == null) {
            Log.d(TAG, "Initializing SeriesRepository...")
            _repository = SeriesRepository.getInstance(getApplication())
            Log.d(TAG, "SeriesRepository initialized")
        }
    }

    /**
     * Load all series using smart GitHub-first loading
     */
    fun loadAllSeries() {
        viewModelScope.launch {
            ensureRepositoryInitialized()
            _uiState.value = SeriesUiState.Loading

            try {
                val seriesList = repository.getSeriesSmart()

                _allSeries.value = seriesList
                applyFilters()

                _uiState.value = SeriesUiState.Success(seriesList.size)
                Log.d(TAG, "✅ Loaded ${seriesList.size} series (GitHub-first)")

            } catch (e: Exception) {
                Log.e(TAG, "❌ Error loading series: ${e.message}", e)
                _uiState.value = SeriesUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    /**
     * Search series by query
     */
    fun searchSeries(query: String) {
        viewModelScope.launch {
            currentSearchQuery = query
            _uiState.value = SeriesUiState.Loading

            try {
                // Apply search filter on cached series
                applyFilters()

                val count = _filteredSeries.value.size
                _uiState.value = SeriesUiState.Success(count)

            } catch (e: Exception) {
                Log.e(TAG, "❌ Error searching series: ${e.message}", e)
                _uiState.value = SeriesUiState.Error(e.message ?: "Search failed")
            }
        }
    }

    /**
     * Filter series by category
     */
    fun filterByCategory(category: SeriesCategory) {
        currentCategory = category
        applyFilters()
    }

    /**
     * Apply current filters
     */
    private fun applyFilters() {
        val filtered = when (currentCategory) {
            SeriesCategory.ALL -> _allSeries.value
            else -> _allSeries.value.filter { it.category == currentCategory }
        }

        // Apply search filter
        val withSearch = if (currentSearchQuery.isNotEmpty()) {
            filtered.filter { series ->
                series.title.contains(currentSearchQuery, ignoreCase = true) ||
                series.originalTitle.contains(currentSearchQuery, ignoreCase = true)
            }
        } else {
            filtered
        }

        _filteredSeries.value = withSearch
    }

    /**
     * Toggle favorite status
     */
    fun toggleFavorite(series: Series) {
        viewModelScope.launch {
            ensureRepositoryInitialized()
            try {
                val isNowFavorite = repository.toggleFavorite(series)

                // Update local state
                val updatedList = _allSeries.value.map {
                    if (it.id == series.id) {
                        it.copy(isFavorite = isNowFavorite)
                    } else {
                        it
                    }
                }
                _allSeries.value = updatedList
                applyFilters()

                Log.d(TAG, "Toggled favorite: ${series.title} -> $isNowFavorite")
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error toggling favorite: ${e.message}")
            }
        }
    }

    /**
     * Get a specific series by ID
     */
    fun getSeriesById(id: String): Series? {
        return _allSeries.value.find { it.id == id }
    }

    /**
     * Force refresh series from GitHub or scrape fresh
     */
    fun forceRefresh() {
        viewModelScope.launch {
            ensureRepositoryInitialized()
            _uiState.value = SeriesUiState.Loading

            try {
                val seriesList = repository.forceRefresh()

                _allSeries.value = seriesList
                applyFilters()

                _uiState.value = SeriesUiState.Success(seriesList.size)
                Log.d(TAG, "✅ Force refreshed ${seriesList.size} series")

            } catch (e: Exception) {
                Log.e(TAG, "❌ Error force refreshing: ${e.message}", e)
                _uiState.value = SeriesUiState.Error(e.message ?: "Refresh failed")
            }
        }
    }

    /**
     * Get favorites
     */
    fun getFavorites() {
        viewModelScope.launch {
            ensureRepositoryInitialized()
            try {
                val favorites = repository.getFavorites()
                _filteredSeries.value = favorites
                _uiState.value = SeriesUiState.Success(favorites.size)
                Log.d(TAG, "Loaded ${favorites.size} favorites")
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error loading favorites: ${e.message}")
            }
        }
    }

    /**
     * Clear all data
     */
    fun clearData() {
        viewModelScope.launch {
            ensureRepositoryInitialized()
            repository.clearCache()
            _allSeries.value = emptyList()
            _filteredSeries.value = emptyList()
            _uiState.value = SeriesUiState.Idle
        }
    }

    /**
     * Get loading status
     */
    fun isLoading(): Boolean {
        return _repository?.isLoading() ?: false
    }

    /**
     * Get cached series count
     */
    fun getCachedCount(): Int {
        return _repository?.getCachedCount() ?: 0
    }

    /**
     * Get local cache age in minutes
     */
    fun getCacheAge(): Long {
        return _repository?.getLocalCacheAge() ?: -1L
    }
}

/**
 * UI state for series loading
 */
sealed class SeriesUiState {
    object Idle : SeriesUiState()
    object Loading : SeriesUiState()
    data class Success(val count: Int) : SeriesUiState()
    data class Error(val message: String) : SeriesUiState()
}

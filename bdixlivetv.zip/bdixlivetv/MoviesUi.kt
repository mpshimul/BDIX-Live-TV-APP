package com.shimulfp.bdixlivetv

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.shimulfp.bdixlivetv.manager.DownloadManager
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.models.MovieCategory
import com.shimulfp.bdixlivetv.models.Series
import com.shimulfp.bdixlivetv.models.StreamUrl
import com.shimulfp.bdixlivetv.viewmodel.MovieUiState
import com.shimulfp.bdixlivetv.viewmodel.MovieViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ───────────────────── Movies Screen ─────────────────────

@Composable
fun MoviesScreen(
    viewModel: MovieViewModel,
    onMovieClick: (Movie) -> Unit,
    onMovieDetailClick: (Movie) -> Unit,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val allMovies by viewModel.allMovies.collectAsState()
    val displayedMovies by viewModel.displayedMovies.collectAsState()
    val recentlyAdded by viewModel.recentlyAdded.collectAsState()
    val continueWatching by viewModel.continueWatching.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()

    val favoriteIds = remember(favorites) { favorites.map { it.id }.toSet() }

    val movieCounts = remember(allMovies) {
        val counts = mutableMapOf<MovieCategory, Int>()
        counts[MovieCategory.ALL] = allMovies.size
        MovieCategory.values().filter { it != MovieCategory.ALL }.forEach { category ->
            counts[category] = allMovies.count { it.category == category }
        }
        counts
    }

    // Focus requesters
    val firstChipFocusRequester = remember { FocusRequester() }
    val firstMovieFocusRequester = remember { FocusRequester() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
    ) {
        // Main content
        when (uiState) {
            is MovieUiState.Loading -> LoadingContent()
            is MovieUiState.Error -> ErrorContent(uiState as MovieUiState.Error, viewModel)
            is MovieUiState.Empty -> EmptyContent(viewModel)
            is MovieUiState.Success -> {
                if (selectedCategory == MovieCategory.ALL) {
                    AllMoviesContent(
                        allMovies = allMovies,
                        displayedMovies = displayedMovies,
                        recentlyAdded = recentlyAdded,
                        continueWatching = continueWatching,
                        favorites = favorites,
                        selectedCategory = selectedCategory,
                        onCategorySelect = { viewModel.selectCategory(it) },
                        movieCounts = movieCounts,
                        onMovieClick = onMovieClick,
                        onMovieLongClick = onMovieDetailClick,
                        favoriteIds = favoriteIds,
                        firstChipFocusRequester = firstChipFocusRequester
                    )
                } else {
                    CategoryMoviesContent(
                        category = selectedCategory,
                        movies = displayedMovies,
                        onMovieClick = onMovieClick,
                        onMovieLongClick = onMovieDetailClick,
                        favoriteIds = favoriteIds,
                        firstMovieFocusRequester = firstMovieFocusRequester,
                        onCategorySelect = { viewModel.selectCategory(it) },
                        movieCounts = movieCounts
                    )
                }
            }
        }

        // Back button – non‑focusable
        Box(
            modifier = Modifier
                .padding(16.dp)
                .align(Alignment.TopStart)
                .size(48.dp)
                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                .clickable(
                    onClick = onBack,
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                )
                .focusable(false),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
    }

    // Request focus after loading
    LaunchedEffect(uiState, selectedCategory) {
        when {
            selectedCategory == MovieCategory.ALL && uiState is MovieUiState.Success -> {
                delay(200)
                firstChipFocusRequester.requestFocus()
            }
            selectedCategory != MovieCategory.ALL && displayedMovies.isNotEmpty() -> {
                delay(200)
                firstMovieFocusRequester.requestFocus()
            }
        }
    }
}

// ───────────────────── Loading / Error / Empty states ─────────────────────

@Composable
private fun LoadingContent() {
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = Color.Red)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Loading movies...", color = Color.Gray)
        }
    }
}

@Composable
private fun ErrorContent(error: MovieUiState.Error, viewModel: MovieViewModel) {
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Error, null, tint = Color.Red, modifier = Modifier.size(64.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Text("Error loading movies", color = Color.White, fontSize = 18.sp)
            Text(error.message, color = Color.Gray, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = { viewModel.loadMoviesWithGitHubSync(forceRefresh = true) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
            ) {
                Text("Retry")
            }
        }
    }
}

@Composable
private fun EmptyContent(viewModel: MovieViewModel) {
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Movie, null, tint = Color.Gray, modifier = Modifier.size(64.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Text("No movies found", color = Color.Gray, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = { viewModel.loadMoviesWithGitHubSync(forceRefresh = true) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
            ) {
                Text("Refresh")
            }
        }
    }
}

// ───────────────────── All Movies Content ─────────────────────

@Composable
private fun AllMoviesContent(
    allMovies: List<Movie>,
    displayedMovies: List<Movie>,
    recentlyAdded: List<Movie>,
    continueWatching: List<Movie>,
    favorites: List<Movie>,
    selectedCategory: MovieCategory,
    onCategorySelect: (MovieCategory) -> Unit,
    movieCounts: Map<MovieCategory, Int>,
    onMovieClick: (Movie) -> Unit,
    onMovieLongClick: (Movie) -> Unit,
    favoriteIds: Set<String>,
    firstChipFocusRequester: FocusRequester
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 24.dp)
    ) {
        // Category chips with focus requester on first chip
        item {
            MovieCategoryChips(
                selectedCategory = selectedCategory,
                onCategorySelect = onCategorySelect,
                movieCounts = movieCounts,
                firstChipFocusRequester = firstChipFocusRequester
            )
        }

        // REMOVED: Count + refresh row (saves space)

        // Continue watching
        if (continueWatching.isNotEmpty()) {
            item {
                MovieRow(
                    title = "▶️ Continue Watching",
                    movies = continueWatching,
                    onMovieClick = onMovieClick,
                    onMovieLongClick = onMovieLongClick,
                    showProgress = true,
                    favoriteIds = favoriteIds,
                    accentColor = Color.Yellow
                )
            }
        }

        // Favorites
        if (favorites.isNotEmpty()) {
            item {
                MovieRow(
                    title = "❤️ My Favorites",
                    movies = favorites,
                    onMovieClick = onMovieClick,
                    onMovieLongClick = onMovieLongClick,
                    favoriteIds = favoriteIds,
                    accentColor = Color.Red
                )
            }
        }

        // Recently added
        if (recentlyAdded.isNotEmpty()) {
            item {
                MovieRow(
                    title = "🆕 Recently Added",
                    movies = recentlyAdded,
                    onMovieClick = onMovieClick,
                    onMovieLongClick = onMovieLongClick,
                    favoriteIds = favoriteIds,
                    accentColor = Color.Green
                )
            }
        }

        // Category sections
        MovieCategory.values()
            .filter { it != MovieCategory.ALL }
            .forEach { category ->
                val categoryMovies = allMovies.filter { it.category == category }
                if (categoryMovies.isNotEmpty()) {
                    item {
                        MovieRow(
                            title = category.displayName,
                            movies = categoryMovies.take(20),
                            onMovieClick = onMovieClick,
                            onMovieLongClick = onMovieLongClick,
                            onSeeAllClick = { onCategorySelect(category) },
                            favoriteIds = favoriteIds
                        )
                    }
                }
            }
    }
}

// ───────────────────── Category Movies Content ─────────────────────

@Composable
private fun CategoryMoviesContent(
    category: MovieCategory,
    movies: List<Movie>,
    onMovieClick: (Movie) -> Unit,
    onMovieLongClick: (Movie) -> Unit,
    favoriteIds: Set<String>,
    firstMovieFocusRequester: FocusRequester,
    onCategorySelect: (MovieCategory) -> Unit,
    movieCounts: Map<MovieCategory, Int>
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Category chips at the top
        MovieCategoryChips(
            selectedCategory = category,
            onCategorySelect = onCategorySelect,
            movieCounts = movieCounts,
            firstChipFocusRequester = null // don't steal focus from first movie
        )

        // Category title (optional, can keep or remove)
        Text(
            text = category.displayName,
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 20.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 140.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(movies.size, key = { movies[it].id }) { index ->
                val movie = movies[index]
                val modifier = if (index == 0) {
                    Modifier.focusRequester(firstMovieFocusRequester)
                } else {
                    Modifier
                }
                MovieCard(
                    movie = movie,
                    onClick = { onMovieClick(movie) },
                    onLongClick = { onMovieLongClick(movie) },
                    isFavorite = movie.id in favoriteIds,
                    modifier = modifier
                )
            }
        }
    }
}

// ───────────────────── Hero Banner ─────────────────────

@Composable
fun MovieHeroBanner(
    movie: Movie?,
    onPlayClick: () -> Unit,
    onInfoClick: () -> Unit,
    playButtonFocusRequester: FocusRequester? = null
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(280.dp)
    ) {
        if (movie?.poster?.isNotEmpty() == true) {
            AsyncImage(
                model = movie.poster,
                contentDescription = movie.title ?: "Movie poster",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(Color(0xFF1A1A2E), Color(0xFF16213E))
                        )
                    )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0xFF0A0A0A).copy(alpha = 0.8f),
                            Color(0xFF0A0A0A)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(24.dp)
        ) {
            if (movie != null) {
                Text(
                    text = movie.title ?: "Unknown Movie",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!movie.year.isNullOrEmpty()) {
                        InfoChip(text = movie.year)
                    }
                    InfoChip(text = movie.quality ?: "HD", color = Color.Green)
                    InfoChip(text = movie.language ?: "Unknown", color = Color.Cyan)
                    if (movie.streamUrls.isNotEmpty()) {
                        InfoChip(text = "${movie.streamUrls.size} servers")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    var playButtonFocused by remember { mutableStateOf(false) }
                    var infoButtonFocused by remember { mutableStateOf(false) }

                    val playScale by animateFloatAsState(
                        targetValue = if (playButtonFocused) 1.1f else 1f,
                        animationSpec = tween(durationMillis = 150),
                        label = "playScale"
                    )
                    val infoScale by animateFloatAsState(
                        targetValue = if (infoButtonFocused) 1.1f else 1f,
                        animationSpec = tween(durationMillis = 150),
                        label = "infoScale"
                    )

                    Button(
                        onClick = onPlayClick,
                        modifier = Modifier
                            .then(
                                if (playButtonFocusRequester != null)
                                    Modifier.focusRequester(playButtonFocusRequester)
                                else Modifier
                            )
                            .scale(playScale)
                            .border(
                                width = if (playButtonFocused) 3.dp else 0.dp,
                                color = if (playButtonFocused) Color.White else Color.Transparent,
                                shape = RoundedCornerShape(24.dp)
                            )
                            .onFocusChanged { playButtonFocused = it.isFocused },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (playButtonFocused) Color(0xFFFF2222) else Color.Red
                        ),
                        contentPadding = PaddingValues(horizontal = 28.dp, vertical = 14.dp)
                    ) {
                        Icon(
                            Icons.Filled.PlayArrow,
                            null,
                            modifier = Modifier.size(if (playButtonFocused) 28.dp else 24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Play Now",
                            fontSize = if (playButtonFocused) 17.sp else 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = onInfoClick,
                        modifier = Modifier
                            .scale(infoScale)
                            .border(
                                width = if (infoButtonFocused) 3.dp else 1.dp,
                                color = if (infoButtonFocused) Color.Yellow else Color.White,
                                shape = RoundedCornerShape(24.dp)
                            )
                            .onFocusChanged { infoButtonFocused = it.isFocused },
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
                    ) {
                        Icon(
                            Icons.Filled.Info,
                            null,
                            tint = if (infoButtonFocused) Color.Yellow else Color.White,
                            modifier = Modifier.size(if (infoButtonFocused) 28.dp else 24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "More Info",
                            color = if (infoButtonFocused) Color.Yellow else Color.White,
                            fontSize = if (infoButtonFocused) 17.sp else 16.sp,
                            fontWeight = if (infoButtonFocused) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            } else {
                Text(
                    text = "BDIX Movies",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Watch HD Movies from BDIX Servers",
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }
        }
    }
}

// ───────────────────── Movie Detail Screen ─────────────────────

@Composable
fun MovieDetailScreen(
    movie: Movie,
    isFavorite: Boolean,
    relatedMovies: List<Movie>,
    onPlayClick: (StreamUrl) -> Unit,
    onBackClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    onRelatedMovieClick: (Movie) -> Unit
) {
    var selectedServer by remember(movie) { mutableStateOf(movie.streamUrls.firstOrNull()) }
    var showServerDialog by remember { mutableStateOf(false) }
    var showDownloadConfirm by remember { mutableStateOf(false) }

    var favoriteState by remember(movie) { mutableStateOf(isFavorite) }

    val playButtonFocusRequester = remember(movie.id) { FocusRequester() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val downloadManager = remember { DownloadManager.getInstance(context) }
    val downloads by downloadManager.downloadsState.collectAsState()

    val currentDownload = downloads.find { it.movieId == movie.id }
    val isDownloading =
        currentDownload?.status == com.shimulfp.bdixlivetv.models.DownloadStatus.DOWNLOADING
    val isDownloaded =
        currentDownload?.status == com.shimulfp.bdixlivetv.models.DownloadStatus.COMPLETED
    val downloadProgress = currentDownload?.progress ?: 0

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // Header image & back (non‑focusable)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            ) {
                if (!movie.poster.isNullOrEmpty()) {
                    AsyncImage(
                        model = movie.poster,
                        contentDescription = movie.title ?: "Movie poster",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0xFF0A0A0A).copy(alpha = 0.9f),
                                    Color(0xFF0A0A0A)
                                )
                            )
                        )
                )

                // Back button – non‑focusable
                Box(
                    modifier = Modifier
                        .padding(16.dp)
                        .align(Alignment.TopStart)
                        .size(48.dp)
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        .clickable(
                            onClick = onBackClick,
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() }
                        )
                        .focusable(false),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .offset(y = (-60).dp)
            ) {
                Text(
                    text = movie.title ?: "Unknown Movie",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!movie.year.isNullOrEmpty()) {
                        InfoChip(text = movie.year)
                    }
                    InfoChip(text = movie.quality ?: "HD", color = Color.Green)
                    InfoChip(text = movie.language ?: "Unknown", color = Color.Cyan)
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (!movie.genres.isNullOrEmpty()) {
                    Text(
                        text = movie.genres.joinToString(" • "),
                        color = Color.Gray,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Action row
                var playFocused by remember { mutableStateOf(false) }
                var downloadFocused by remember { mutableStateOf(false) }
                var favoriteFocused by remember { mutableStateOf(false) }

                val playScale by animateFloatAsState(
                    targetValue = if (playFocused) 1.05f else 1f,
                    animationSpec = tween(durationMillis = 150),
                    label = "detailPlayScale"
                )
                val downloadScale by animateFloatAsState(
                    targetValue = if (downloadFocused) 1.05f else 1f,
                    animationSpec = tween(durationMillis = 150),
                    label = "detailDownloadScale"
                )
                val favoriteScale by animateFloatAsState(
                    targetValue = if (favoriteFocused) 1.05f else 1f,
                    animationSpec = tween(durationMillis = 150),
                    label = "detailFavoriteScale"
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { selectedServer?.let(onPlayClick) },
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(playButtonFocusRequester)
                            .scale(playScale)
                            .border(
                                width = if (playFocused) 3.dp else 0.dp,
                                color = if (playFocused) Color.White else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .onFocusChanged { playFocused = it.isFocused },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (playFocused) Color(0xFFFF2222) else Color.Red
                        )
                    ) {
                        Icon(Icons.Filled.PlayArrow, null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Play")
                    }

                    OutlinedButton(
                        onClick = {
                            if (selectedServer != null && !isDownloading && !isDownloaded) {
                                showDownloadConfirm = true
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .scale(downloadScale)
                            .border(
                                width = if (downloadFocused) 3.dp else 1.dp,
                                color = when {
                                    isDownloading -> Color(0xFF00FF00)
                                    isDownloaded -> Color.Green
                                    downloadFocused -> Color.White
                                    else -> Color.White
                                },
                                shape = RoundedCornerShape(8.dp)
                            )
                            .onFocusChanged { downloadFocused = it.isFocused },
                        enabled = selectedServer != null && !isDownloading && !isDownloaded
                    ) {
                        when {
                            isDownloading -> {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = Color(0xFF00FF00),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("$downloadProgress%", color = Color.White, fontSize = 12.sp)
                            }

                            isDownloaded -> {
                                Icon(
                                    Icons.Filled.CheckCircle,
                                    null,
                                    tint = Color.Green,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Downloaded", color = Color.White, fontSize = 12.sp)
                            }

                            else -> {
                                Icon(
                                    Icons.Filled.Download,
                                    null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Download", color = Color.White, fontSize = 12.sp)
                            }
                        }
                    }

                    if (movie.streamUrls.size > 1) {
                        OutlinedButton(
                            onClick = { showServerDialog = true },
                            modifier = Modifier.weight(1f),
                            border = BorderStroke(1.dp, Color.White)
                        ) {
                            Icon(Icons.Filled.Dns, null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(selectedServer?.server ?: "Server", color = Color.White)
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            favoriteState = !favoriteState
                            onFavoriteClick()
                        },
                        modifier = Modifier
                            .scale(favoriteScale)
                            .onFocusChanged { favoriteFocused = it.isFocused },
                        border = BorderStroke(
                            width = if (favoriteFocused) 3.dp else 1.dp,
                            color = when {
                                favoriteState -> Color.Red
                                favoriteFocused -> Color.White
                                else -> Color.White
                            }
                        )
                    ) {
                        Icon(
                            if (favoriteState) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            null,
                            tint = when {
                                favoriteState -> Color.Red
                                favoriteFocused -> Color.White
                                else -> Color.White
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    "Available Servers (${movie.streamUrls.size})",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                movie.streamUrls.forEach { stream ->
                    ServerItem(
                        streamUrl = stream,
                        isSelected = stream == selectedServer,
                        onClick = { selectedServer = stream }
                    )
                }

                if (!movie.audioInfo.isNullOrEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Audio", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(movie.audioInfo, color = Color.Gray, fontSize = 14.sp)
                }

                if (!movie.codec.isNullOrEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Codec: ${movie.codec}", color = Color.Gray, fontSize = 12.sp)
                }

                if (relatedMovies.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(24.dp))
                    Text("Related Movies", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(relatedMovies, key = { it.id }) { related ->
                            MovieCard(
                                movie = related,
                                onClick = { onRelatedMovieClick(related) },
                                modifier = Modifier.width(120.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(48.dp))
            }
        }

        // Server selection dialog
        if (showServerDialog) {
            AlertDialog(
                onDismissRequest = { showServerDialog = false },
                title = { Text("Select Server") },
                text = {
                    Column {
                        movie.streamUrls.forEach { stream ->
                            Card(
                                onClick = {
                                    selectedServer = stream
                                    showServerDialog = false
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (stream == selectedServer)
                                        Color.Red.copy(alpha = 0.3f) else Color(0xFF2A2A2A)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Filled.Dns, null,
                                        tint = if (stream.isWorking) Color.Green else Color.Red
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(stream.server, color = Color.White, fontWeight = FontWeight.Medium)
                                        Text(stream.quality, color = Color.Gray, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showServerDialog = false }) { Text("Close") }
                }
            )
        }

        // Download confirmation dialog
        if (showDownloadConfirm && selectedServer != null && !isDownloading && !isDownloaded) {
            AlertDialog(
                onDismissRequest = { showDownloadConfirm = false },
                title = { Text("Download movie?") },
                text = {
                    Text(
                        "Do you want to download \"${movie.title}\" for offline watching?\n\n" +
                                "This may use your BDIX bandwidth and device storage."
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        showDownloadConfirm = false
                        val streamUrl = selectedServer!!
                        val qualityIndex = movie.streamUrls.indexOf(streamUrl).coerceAtLeast(0)
                        scope.launch {
                            downloadManager.startDownload(movie, streamUrl, qualityIndex)
                        }
                    }) {
                        Text("Download")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDownloadConfirm = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }

    // Request focus on Play button
    LaunchedEffect(movie.id) {
        delay(200)
        try {
            playButtonFocusRequester.requestFocus()
        } catch (_: Exception) { }
    }
}

// ───────────────────── Shared Movie UI: Chips, Rows, Cards ─────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovieCategoryChips(
    selectedCategory: MovieCategory,
    onCategorySelect: (MovieCategory) -> Unit,
    movieCounts: Map<MovieCategory, Int>,
    firstChipFocusRequester: FocusRequester? = null
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(MovieCategory.values().toList(), key = { it.name }) { category ->
            val isSelected = category == selectedCategory
            val count = movieCounts[category] ?: 0
            var isFocused by remember { mutableStateOf(false) }

            val scale by animateFloatAsState(
                targetValue = if (isFocused) 1.05f else 1f,
                animationSpec = tween(durationMillis = 150),
                label = "chipScale"
            )

            val modifier = if (firstChipFocusRequester != null && category == MovieCategory.values().first()) {
                Modifier.focusRequester(firstChipFocusRequester)
            } else {
                Modifier
            }

            FilterChip(
                selected = isSelected,
                onClick = { onCategorySelect(category) },
                modifier = modifier
                    .scale(scale)
                    .border(
                        width = if (isFocused) 2.dp else 0.dp,
                        color = if (isSelected) Color.Red else if (isFocused) Color.Gray else Color.Transparent,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .onFocusChanged { isFocused = it.isFocused },
                label = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(category.displayName)
                        if (count > 0) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                "($count)",
                                fontSize = 10.sp,
                                color = if (isSelected) Color.White.copy(alpha = 0.7f) else Color.Gray
                            )
                        }
                    }
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color.Red,
                    selectedLabelColor = Color.White,
                    containerColor = if (isFocused) Color(0xFF3A3A3A) else Color(0xFF2A2A2A),
                    labelColor = if (isFocused) Color.White else Color.Gray
                )
            )
        }
    }
}

@Composable
fun MovieRow(
    title: String,
    movies: List<Movie>,
    onMovieClick: (Movie) -> Unit,
    onMovieLongClick: ((Movie) -> Unit)? = null,
    onSeeAllClick: (() -> Unit)? = null,
    showProgress: Boolean = false,
    favoriteIds: Set<String> = emptySet(),
    accentColor: Color = Color.White
) {
    if (movies.isEmpty()) return

    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = accentColor,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${movies.size} movies",
                    color = Color.Gray,
                    fontSize = 12.sp
                )

                if (onSeeAllClick != null) {
                    var seeAllFocused by remember { mutableStateOf(false) }
                    val seeAllScale by animateFloatAsState(
                        targetValue = if (seeAllFocused) 1.05f else 1f,
                        animationSpec = tween(durationMillis = 150),
                        label = "seeAllScale"
                    )

                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(
                        onClick = onSeeAllClick,
                        modifier = Modifier
                            .scale(seeAllScale)
                            .border(
                                width = if (seeAllFocused) 1.dp else 0.dp,
                                color = if (seeAllFocused) accentColor else Color.Transparent,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .onFocusChanged { seeAllFocused = it.isFocused }
                    ) {
                        Text("See All", color = accentColor, fontSize = 12.sp)
                        Icon(
                            Icons.Filled.ChevronRight,
                            null,
                            tint = accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(movies, key = { it.id }) { movie ->
                MovieCard(
                    movie = movie,
                    onClick = { onMovieClick(movie) },
                    onLongClick = { onMovieLongClick?.invoke(movie) },
                    showProgress = showProgress,
                    isFavorite = movie.id in favoriteIds
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MovieCard(
    movie: Movie,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    showProgress: Boolean = false,
    isFavorite: Boolean = false,
    modifier: Modifier = Modifier
) {
    var isFocused by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.12f else 1f,
        animationSpec = tween(durationMillis = 150),
        label = "cardScale"
    )

    val borderColor by animateColorAsState(
        targetValue = if (isFocused) Color.Red else Color(0xFF333333),
        animationSpec = tween(durationMillis = 150),
        label = "borderColor"
    )

    val borderWidth = if (isFocused) 4.dp else 1.dp

    Column(
        modifier = modifier
            .width(140.dp)
            .scale(scale)
            .onFocusChanged { focusState -> isFocused = focusState.isFocused }
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1E1E1E))
                .border(
                    width = borderWidth,
                    color = borderColor,
                    shape = RoundedCornerShape(12.dp)
                )
        ) {
            if (!movie.poster.isNullOrEmpty()) {
                AsyncImage(
                    model = movie.poster,
                    contentDescription = movie.title ?: "Movie poster",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.Movie, null, tint = Color.Gray, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = (movie.title ?: "Unknown").take(15),
                            color = Color.Gray,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 2
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .background(
                        Color(movie.getQualityBadgeColor()),
                        RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = movie.quality ?: "HD",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (isFavorite) {
                Icon(
                    Icons.Filled.Favorite,
                    "Favorite",
                    tint = Color.Red,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .size(16.dp)
                )
            }

            if (!movie.year.isNullOrEmpty()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(movie.year, color = Color.White, fontSize = 10.sp)
                }
            }

            if (isFocused) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.2f),
                                    Color.Red.copy(alpha = 0.7f)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .background(Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.PlayArrow, "Play", tint = Color.Red, modifier = Modifier.size(36.dp))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Press OK",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (showProgress && movie.watchProgress > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(4.dp)
                        .background(Color.Gray.copy(alpha = 0.5f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(movie.watchProgress)
                            .background(Color.Red)
                    )
                }
            }
        }

        Text(
            text = movie.title,
            color = if (isFocused) Color.White else Color.Gray,
            fontSize = if (isFocused) 13.sp else 12.sp,
            fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Medium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp)
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(top = 2.dp)
        ) {
            Text(
                movie.language,
                color = if (isFocused) Color.Cyan else Color.Cyan.copy(alpha = 0.7f),
                fontSize = 10.sp
            )
            if (movie.serverName.isNotEmpty()) {
                Text("•", color = Color.Gray, fontSize = 10.sp)
                Text(movie.serverName, color = Color.Gray, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun HomeMovieCard(
    movie: Movie,
    onClick: () -> Unit,
    onPlayClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.12f else 1f,
        animationSpec = tween(durationMillis = 150),
        label = "homeMovieScale"
    )

    val borderColor by animateColorAsState(
        targetValue = if (isFocused) Color.Red else Color(0xFF333333),
        animationSpec = tween(durationMillis = 150),
        label = "homeMovieBorder"
    )

    Column(
        modifier = Modifier
            .width(140.dp)
            .scale(scale)
            .onFocusChanged { focusState -> isFocused = focusState.isFocused }
            .combinedClickable(
                onClick = onClick,
                onLongClick = { onPlayClick() },
                onDoubleClick = null
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1E1E1E))
                .border(
                    width = if (isFocused) 4.dp else 1.dp,
                    color = borderColor,
                    shape = RoundedCornerShape(12.dp)
                )
        ) {
            if (!movie.poster.isNullOrEmpty()) {
                AsyncImage(
                    model = movie.poster,
                    contentDescription = movie.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Movie,
                        null,
                        tint = Color.Gray,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .background(
                        Color(movie.getQualityBadgeColor()),
                        RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = movie.quality,
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (isFocused) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.3f),
                                    Color.Red.copy(alpha = 0.7f)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .background(Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Filled.PlayArrow,
                                "Play",
                                tint = Color.Red,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "View Details",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Text(
            text = movie.title,
            color = if (isFocused) Color.White else Color.Gray,
            fontSize = if (isFocused) 12.sp else 11.sp,
            fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Medium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
fun HomeSeriesCard(
    series: Series,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.12f else 1f,
        animationSpec = tween(durationMillis = 150),
        label = "homeSeriesScale"
    )

    val borderColor by animateColorAsState(
        targetValue = if (isFocused) Color(0xFF9C27B0) else Color(0xFF333333),
        animationSpec = tween(durationMillis = 150),
        label = "homeSeriesBorder"
    )

    Column(
        modifier = Modifier
            .width(140.dp)
            .scale(scale)
            .onFocusChanged { focusState -> isFocused = focusState.isFocused }
            .combinedClickable(
                onClick = onClick,
                onLongClick = null,
                onDoubleClick = null
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1E1E1E))
                .border(
                    width = if (isFocused) 4.dp else 1.dp,
                    color = borderColor,
                    shape = RoundedCornerShape(12.dp)
                )
        ) {
            if (!series.poster.isNullOrEmpty()) {
                AsyncImage(
                    model = series.poster,
                    contentDescription = series.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.LiveTv,
                        null,
                        tint = Color.Gray,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .background(
                        Color(0xFF9C27B0),
                        RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = series.quality,
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .background(
                        Color(0xFFE91E63),
                        RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "${series.getSeasonCount()} Seasons",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Text(
            text = series.title,
            color = if (isFocused) Color.White else Color.Gray,
            fontSize = if (isFocused) 12.sp else 11.sp,
            fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Medium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
fun ServerItem(
    streamUrl: StreamUrl,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .onFocusChanged { isFocused = it.isFocused },
        colors = CardDefaults.cardColors(
            containerColor = when {
                isSelected -> Color.Red.copy(alpha = 0.2f)
                isFocused -> Color(0xFF252525)
                else -> Color(0xFF1A1A1A)
            }
        ),
        border = when {
            isSelected -> BorderStroke(1.dp, Color.Red)
            isFocused -> BorderStroke(1.dp, Color.White)
            else -> null
        }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                null,
                tint = when {
                    isSelected -> Color.Red
                    isFocused -> Color.White
                    else -> Color.Gray
                }
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(streamUrl.server, color = Color.White, fontWeight = FontWeight.Medium)
                Text(streamUrl.quality, color = Color.Gray, fontSize = 12.sp)
                if (streamUrl.fileName.isNotEmpty()) {
                    Text(
                        streamUrl.fileName.take(50) + if (streamUrl.fileName.length > 50) "..." else "",
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                }
            }
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(if (streamUrl.isWorking) Color.Green else Color.Red, CircleShape)
            )
        }
    }
}

@Composable
fun InfoChip(text: String, color: Color = Color.Gray) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text = text, color = color, fontSize = 12.sp)
    }
}
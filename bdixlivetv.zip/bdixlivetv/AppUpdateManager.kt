package com.shimulfp.bdixlivetv

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.shimulfp.bdixlivetv.models.AppUpdateInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object AppUpdateManager {
    private const val TAG = "AppUpdateManager"
    private const val GITHUB_API_URL = "https://api.github.com"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    private var currentDownloadId: Long = -1L
    private var onDownloadCompleted: ((Boolean) -> Unit)? = null

    // ========== Device ABI detection ==========
    fun getDeviceAbi(): String {
        val supportedAbis = Build.SUPPORTED_ABIS
        return when {
            supportedAbis.contains("arm64-v8a") -> "arm64-v8a"
            supportedAbis.contains("armeabi-v7a") -> "armeabi-v7a"
            else -> "armeabi-v7a"
        }
    }

    // ========== GitHub API data classes ==========
    data class Asset(val name: String, val size: Long, val browserDownloadUrl: String)
    data class GitHubRelease(
        val tagName: String,
        val name: String,
        val body: String,
        val htmlUrl: String,
        val publishedAt: String,
        val assets: List<Asset>
    )

    // ========== Version parsing helper ==========
    private data class Version(val major: Int, val minor: Int, val patch: Int) : Comparable<Version> {
        override fun compareTo(other: Version): Int = when {
            major != other.major -> major.compareTo(other.major)
            minor != other.minor -> minor.compareTo(other.minor)
            else -> patch.compareTo(other.patch)
        }

        companion object {
            fun parse(version: String): Version? {
                val clean = version.trimStart('v').trim()
                val parts = clean.split('.')
                if (parts.size < 2) return null
                val major = parts[0].toIntOrNull() ?: return null
                val minor = parts[1].toIntOrNull() ?: return null
                val patch = if (parts.size >= 3) parts[2].toIntOrNull() ?: 0 else 0
                return Version(major, minor, patch)
            }
        }
    }

    // ========== Check for updates ==========
    suspend fun checkForUpdates(context: Context): AppUpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val repoOwner = BuildConfig.GITHUB_REPO_OWNER
            val repoName = BuildConfig.GITHUB_REPO_NAME
            val currentVersionName = BuildConfig.VERSION_NAME
            val deviceAbi = getDeviceAbi()

            val url = "$GITHUB_API_URL/repos/$repoOwner/$repoName/releases/latest"
            val request = Request.Builder().url(url)
                .header("Accept", "application/vnd.github.v3+json").build()
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) return@withContext null

            val json = JSONObject(response.body?.string() ?: return@withContext null)
            val tagName = json.optString("tag_name")
            val remoteVersionName = json.optString("name").ifEmpty { tagName }

            // Parse versions
            val remoteVersion = Version.parse(remoteVersionName) ?: return@withContext null
            val currentVersion = Version.parse(currentVersionName) ?: return@withContext null

            // Only proceed if remote version is strictly greater
            if (remoteVersion <= currentVersion) {
                Log.d(TAG, "No update: remote $remoteVersionName <= current $currentVersionName")
                return@withContext null
            }

            // Extract assets
            val assets = mutableListOf<Asset>()
            json.optJSONArray("assets")?.let { array ->
                for (i in 0 until array.length()) {
                    val a = array.getJSONObject(i)
                    assets.add(Asset(
                        name = a.optString("name"),
                        size = a.optLong("size"),
                        browserDownloadUrl = a.optString("browser_download_url")
                    ))
                }
            }

            val apkAsset = selectApkForDevice(assets, deviceAbi) ?: return@withContext null

            // Compute version code from tag (optional, for display)
            val remoteVersionCode = extractVersionCodeFromTag(tagName) ?: 0

            return@withContext AppUpdateInfo(
                versionName = remoteVersionName,
                versionCode = remoteVersionCode,
                currentVersionName = currentVersionName,
                releaseNotes = json.optString("body"),
                downloadUrl = apkAsset.browserDownloadUrl,
                fileSize = apkAsset.size,
                releaseUrl = json.optString("html_url"),
                publishedAt = json.optString("published_at")
            )
        } catch (e: Exception) {
            Log.e(TAG, "checkForUpdates error", e)
            null
        }
    }

    private fun selectApkForDevice(assets: List<Asset>, deviceAbi: String): Asset? {
        return assets.find { it.name.endsWith(".apk") && it.name.contains(deviceAbi) }
            ?: assets.find { it.name.endsWith(".apk") && it.name.contains("universal") }
            ?: assets.find { it.name.endsWith(".apk") }
    }

    private fun extractVersionCodeFromTag(tag: String): Int? {
        val clean = tag.removePrefix("v")
        val parts = clean.split(".")
        if (parts.size < 2) return null
        val major = parts[0].toIntOrNull() ?: 0
        val minor = parts[1].toIntOrNull() ?: 0
        val patch = if (parts.size >= 3) parts[2].toIntOrNull() ?: 0 else 0
        return major * 10000 + minor * 100 + patch
    }

    // ========== Download management ==========
    fun startDownload(context: Context, downloadUrl: String, versionName: String): Long {
        val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
        val fileName = "BDIXLiveTV-$versionName.apk"
        val destinationFile = File(downloadsDir, fileName)
        if (destinationFile.exists()) destinationFile.delete()

        val request = DownloadManager.Request(Uri.parse(downloadUrl))
            .setTitle("BDIXLiveTV Update")
            .setDescription("Downloading version $versionName")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
            .setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE)
            .setAllowedOverRoaming(true)

        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        currentDownloadId = dm.enqueue(request)
        return currentDownloadId
    }

    fun getDownloadProgress(downloadId: Long, context: Context): Float? {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val query = DownloadManager.Query().setFilterById(downloadId)
        dm.query(query).use { cursor ->
            if (cursor.moveToFirst()) {
                val bytesDownloaded = cursor.getLong(cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val totalBytes = cursor.getLong(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                if (totalBytes > 0) return bytesDownloaded.toFloat() / totalBytes
            }
        }
        return null
    }

    fun getDownloadBytes(downloadId: Long, context: Context): Pair<Long, Long>? {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val query = DownloadManager.Query().setFilterById(downloadId)
        dm.query(query).use { cursor ->
            if (cursor.moveToFirst()) {
                val downloaded = cursor.getLong(cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = cursor.getLong(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                return downloaded to total
            }
        }
        return null
    }

    fun registerDownloadReceiver(context: Context, onComplete: (Boolean) -> Unit) {
        onDownloadCompleted = onComplete
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action == DownloadManager.ACTION_DOWNLOAD_COMPLETE) {
                    val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                    if (id == currentDownloadId) {
                        val success = checkDownloadSuccess(id, context)
                        onDownloadCompleted?.invoke(success)
                        context?.unregisterReceiver(this)
                    }
                }
            }
        }
        context.registerReceiver(receiver,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            Context.RECEIVER_EXPORTED
        )
    }

    private fun checkDownloadSuccess(downloadId: Long, context: Context): Boolean {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val query = DownloadManager.Query().setFilterById(downloadId)
        dm.query(query).use { cursor ->
            if (cursor.moveToFirst()) {
                val status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS))
                return status == DownloadManager.STATUS_SUCCESSFUL
            }
        }
        return false
    }

    fun getDownloadedFileUri(downloadId: Long, context: Context): Uri? {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val query = DownloadManager.Query().setFilterById(downloadId)
        dm.query(query).use { cursor ->
            if (cursor.moveToFirst()) {
                val status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS))
                if (status == DownloadManager.STATUS_SUCCESSFUL) {
                    val uriString = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI))
                    return Uri.parse(uriString)
                }
            }
        }
        return null
    }

    // ========== Installation with FileProvider ==========
    fun installApk(context: Context, uri: Uri) {
        if (!canInstallPackages(context)) {
            Toast.makeText(
                context,
                "Please allow installation from this app in settings",
                Toast.LENGTH_LONG
            ).show()
            requestInstallPermission(context)
            return
        }

        try {
            // Convert file:// URI to content:// URI using FileProvider
            val contentUri = if (uri.scheme == "file") {
                val file = File(uri.path ?: throw IllegalArgumentException("Invalid file path"))
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",  // matches authority in manifest
                    file
                )
            } else {
                uri  // already a content URI
            }

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            context.startActivity(intent)
            Log.d(TAG, "✅ Installation started")
        } catch (e: Exception) {
            Log.e(TAG, "installApk error", e)
            Toast.makeText(context, "Install failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun canInstallPackages(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.packageManager.canRequestPackageInstalls()
        } else true
    }

    private fun requestInstallPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                .setData(Uri.parse("package:${context.packageName}"))
            context.startActivity(intent)
        }
    }

    // ========== Composable Dialog ==========
    @Composable
    fun UpdateDialog(
        updateInfo: AppUpdateInfo,
        downloadState: DownloadState,
        onDismiss: () -> Unit,
        onConfirmDownload: () -> Unit,
        onInstall: () -> Unit,
        modifier: Modifier = Modifier
    ) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = onDismiss
        ) {
            Card(
                modifier = modifier
                    .fillMaxWidth(1f)
                    .heightIn(min = 200.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text("Update Available", style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("New version: ${updateInfo.versionName}")
                    Text("Current: ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodySmall)

                    if (updateInfo.releaseNotes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Release Notes:", style = MaterialTheme.typography.titleSmall)
                        Text(updateInfo.releaseNotes, style = MaterialTheme.typography.bodySmall, maxLines = 8)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Size: ${formatFileSize(updateInfo.fileSize)}", style = MaterialTheme.typography.bodySmall)

                    when (downloadState) {
                        is DownloadState.Idle -> {
                            Spacer(modifier = Modifier.height(16.dp))
                            TextButton(onClick = onConfirmDownload, modifier = Modifier.fillMaxWidth()) {
                                Text("Download")
                            }
                        }
                        is DownloadState.Downloading -> {
                            Spacer(modifier = Modifier.height(16.dp))
                            LinearProgressIndicator(progress = downloadState.progress, modifier = Modifier.fillMaxWidth())
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Downloading... ${(downloadState.progress * 100).toInt()}%")
                        }
                        is DownloadState.Downloaded -> {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Download complete. Ready to install.")
                            Spacer(modifier = Modifier.height(8.dp))
                            TextButton(onClick = onInstall, modifier = Modifier.fillMaxWidth()) {
                                Text("Install Now")
                            }
                        }
                        is DownloadState.Error -> {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Error: ${downloadState.message}", color = MaterialTheme.colorScheme.error)
                            TextButton(onClick = onConfirmDownload, modifier = Modifier.fillMaxWidth()) {
                                Text("Retry")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                        Text("Later")
                    }
                }
            }
        }
    }

    private fun formatFileSize(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        bytes < 1024 * 1024 * 1024 -> "${bytes / (1024 * 1024)} MB"
        else -> "${bytes / (1024 * 1024 * 1024)} GB"
    }
}

// State sealed class for download progress
sealed class DownloadState {
    object Idle : DownloadState()
    data class Downloading(val progress: Float) : DownloadState()
    object Downloaded : DownloadState()
    data class Error(val message: String) : DownloadState()
}
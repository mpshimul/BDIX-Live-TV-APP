package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.text.Collator
import java.util.*

/**
 * ChannelCacheManager - FIXED VERSION
 * Improvements:
 * - Thread-safe operations with Mutex
 * - Cache versioning and migration
 * - Proper file size thresholds
 * - Retry logic with exponential backoff
 * - Consistent thresholds via SyncConfig
 * - Improved Unicode sorting
 */
object ChannelCacheManager {
    private const val TAG = "ChannelCacheManager"

    // Cache file names
    private const val AYNA_CACHE_FILE = "ayna_channels_cache.json"
    private const val BDIX_CACHE_FILE = "bdix_channels_cache.json"
    private const val COMBINED_CACHE_FILE = "all_channels_cache.json"

    // ✅ Thread-safe refresh state using Mutex
    private val refreshMutex = Mutex()

    // ✅ Volatile variables for visibility across threads
    @Volatile
    private var lastRefreshTime = 0L

    // ✅ Make refreshAllChannels public for RefreshCoordinator
    /**
     * Refresh all channels from sources
     * This is now used by RefreshCoordinator
     */
    suspend fun refreshAllChannels(
        context: Context,
        username: String?,
        password: String?
    ): RefreshResult = withContext(Dispatchers.IO) {
        Log.d(TAG, "🔄 === REFRESH ALL CHANNELS ===")

        val allChannels = mutableListOf<Channel>()

        // ========== AYNA OTT ==========
        val aynaChannels = try {
            if (username != null && password != null && password.isNotEmpty()) {
                Log.d(TAG, "🔄 Starting AynaOTT refresh...")
                // ✅ Use retry logic
                val channels = retryOnFailure {
                    PythonHelper.getAynaChannels(context, username, password, true)
                }
                Log.d(TAG, "✅ AynaOTT: ${channels.size} channels")

                if (channels.isNotEmpty()) {
                    val first = channels.first()
                    Log.d(TAG, "   First channel: name=${first.name}, source=${first.source}")
                }

                saveToCache(
                    context,
                    AYNA_CACHE_FILE,
                    ChannelCache(channels, System.currentTimeMillis(), "aynaott", SyncConfig.CURRENT_CACHE_VERSION)
                )
                channels
            } else {
                Log.d(TAG, "⚠️ AynaOTT skipped - no credentials")
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ AynaOTT refresh failed: ${e.message}")
            emptyList()
        }

        // ========== BDIX ==========
        val bdixChannels = try {
            Log.d(TAG, "🔄 Starting BDIX refresh...")
            // ✅ Use retry logic
            val channels = retryOnFailure {
                PythonHelper.getOtherSourcesChannels(context)
            }
            Log.d(TAG, "✅ BDIX: ${channels.size} channels")

            if (channels.isNotEmpty()) {
                val first = channels.first()
                Log.d(TAG, "   First channel: name=${first.name}, source=${first.source}")
            }

            saveToCache(
                context,
                BDIX_CACHE_FILE,
                ChannelCache(channels, System.currentTimeMillis(), "bdix", SyncConfig.CURRENT_CACHE_VERSION)
            )
            channels
        } catch (e: Exception) {
            Log.e(TAG, "❌ BDIX refresh failed: ${e.message}")
            emptyList()
        }

        // ========== COMBINE ALL (BDIX + AYNA + BACKUP) ==========
        // Merge by channel name - keep only one entry per unique name,
        // but combine all URLs from all sources
        val mergedChannelsMap = mutableMapOf<String, Channel>()

        // Helper function to add or merge channel
        fun addOrMergeChannel(channel: Channel) {
            val normalizedName = channel.name.lowercase().trim()
            val existing = mergedChannelsMap[normalizedName]

            if (existing == null) {
                // First time seeing this channel name
                mergedChannelsMap[normalizedName] = channel
                Log.d(TAG, "   ➕ Added: ${channel.name} (${channel.urls.size} URLs from ${channel.source})")
            } else {
                // Channel name already exists - merge URLs
                val mergedUrls = (existing.urls + channel.urls).distinct()
                val updatedChannel = existing.copy(
                    urls = mergedUrls,
                    source = if (existing.source != channel.source) {
                        "${existing.source}+${channel.source}"
                    } else {
                        existing.source
                    }
                )
                mergedChannelsMap[normalizedName] = updatedChannel
                Log.d(TAG, "   🔀 Merged: ${channel.name} (${existing.urls.size} + ${channel.urls.size} = ${mergedUrls.size} URLs)")
            }
        }

        // Process Ayna channels
        Log.d(TAG, "🔄 Processing Ayna channels...")
        aynaChannels.forEach { addOrMergeChannel(it) }

        // Process BDIX channels
        Log.d(TAG, "🔄 Processing BDIX channels...")
        bdixChannels.forEach { addOrMergeChannel(it) }

        // ========== LOAD AND MERGE BACKUP CHANNELS ==========
        val backupChannels = try {
            val firebaseManager = FirebaseManager(context)
            val githubToken = firebaseManager.getGitHubToken()

            if (githubToken.isNotEmpty()) {
                Log.d(TAG, "🔄 Loading backup channels from GitHub to merge...")
                GitHubDataManager.initialize(githubToken)
                val backup = GitHubDataManager.downloadBackupChannels(context)
                Log.d(TAG, "✅ Backup channels: ${backup.size} channels")
                backup
            } else {
                Log.d(TAG, "⚠️ No GitHub token, skipping backup channels")
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to load backup channels: ${e.message}")
            emptyList()
        }

        // Process and merge backup channels
        Log.d(TAG, "🔄 Processing Backup channels...")
        backupChannels.forEach { addOrMergeChannel(it) }

        // Convert map to list
        allChannels.addAll(mergedChannelsMap.values)

        Log.d(TAG, "📊 Channel counts:")
        Log.d(TAG, "   - Ayna: ${aynaChannels.size}")
        Log.d(TAG, "   - BDIX: ${bdixChannels.size}")
        Log.d(TAG, "   - Backup: ${backupChannels.size}")
        Log.d(TAG, "   - Unique channels after merging: ${allChannels.size}")

        // ✅ Improved Unicode sorting
        val finalChannels = allChannels.sortedWith(
            Comparator { a, b ->
                compareValuesByLocale(a.name, b.name)
            }
        )

        // Save combined cache
        if (finalChannels.isNotEmpty()) {
            saveToCache(
                context,
                COMBINED_CACHE_FILE,
                ChannelCache(finalChannels, System.currentTimeMillis(), "combined", SyncConfig.CURRENT_CACHE_VERSION)
            )
            Log.d(TAG, "💾 Saved ${finalChannels.size} channels to combined cache")
        }

        Log.d(TAG, "🎉 Total: ${finalChannels.size} channels")

        // ========== GITHUB UPLOAD ==========
        if (finalChannels.isNotEmpty()) {
            try {
                val firebaseManager = FirebaseManager(context)
                val githubToken = firebaseManager.getGitHubToken()

                if (githubToken.isNotEmpty()) {
                    GitHubDataManager.initialize(githubToken)
                    val uploaded = GitHubDataManager.uploadAllFiles(context)
                    Log.d(TAG, if (uploaded) "🎉 GitHub upload success" else "⚠️ GitHub upload failed")
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Upload error: ${e.message}")
            }
        }

        return@withContext RefreshResult(
            allChannels = finalChannels,
            success = finalChannels.isNotEmpty()
        )
    }

    /**
     * ✅ Manual refresh - public method for use by RefreshCoordinator
     */
    suspend fun manualRefresh(
        context: Context,
        username: String?,
        password: String?
    ): RefreshResult {
        return refreshAllChannels(context, username, password)
    }

    /**
     * ✅ Start background refresh without blocking UI
     * Called by UnifiedSyncManager when cache is old
     */
    fun startBackgroundRefresh(
        context: Context,
        username: String?,
        password: String?
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                Log.d(TAG, "🔄 Starting background refresh...")
                refreshAllChannels(context, username, password)
                Log.d(TAG, "✅ Background refresh completed")
            } catch (e: Exception) {
                Log.e(TAG, "❌ Background refresh error: ${e.message}", e)
            }
        }
    }

    /**
     * ✅ Retry logic with exponential backoff
     */
    private suspend fun <T> retryOnFailure(
        maxAttempts: Int = SyncConfig.MAX_RETRY_ATTEMPTS,
        block: suspend () -> T
    ): T = withContext(Dispatchers.IO) {
        var lastException: Exception? = null

        repeat(maxAttempts) { attempt ->
            try {
                return@withContext block()
            } catch (e: Exception) {
                lastException = e
                Log.w(TAG, "⚠️ Attempt ${attempt + 1}/$maxAttempts failed: ${e.message}")

                if (attempt < maxAttempts - 1) {
                    val delayTime = SyncConfig.getExponentialBackoffDelay(attempt)
                    Log.d(TAG, "   Retrying in ${delayTime}ms...")
                    delay(delayTime)
                }
            }
        }

        throw lastException!!
    }

    fun isCacheOlderThan(context: Context, minutes: Long): Boolean {
        return try {
            val file = File(context.filesDir, COMBINED_CACHE_FILE)
            if (file.exists()) {
                val minutesOld = (System.currentTimeMillis() - file.lastModified()) / (60 * 1000)
                Log.d(TAG, "Cache age: ${minutesOld}m (threshold: ${minutes}m)")
                minutesOld > minutes
            } else {
                true
            }
        } catch (e: Exception) {
            true
        }
    }

    fun clearAllCache(context: Context) {
        listOf(AYNA_CACHE_FILE, BDIX_CACHE_FILE, COMBINED_CACHE_FILE).forEach { filename ->
            try {
                val file = File(context.filesDir, filename)
                if (file.exists()) {
                    file.delete()
                    Log.d(TAG, "✅ Cleared cache: $filename")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error clearing cache $filename: ${e.message}")
            }
        }
    }

    fun getCacheStatus(context: Context): CacheStatus {
        val aynaCache = loadChannelCacheFromFile(context, AYNA_CACHE_FILE)
        val bdixCache = loadChannelCacheFromFile(context, BDIX_CACHE_FILE)
        val combinedCache = loadChannelCacheFromFile(context, COMBINED_CACHE_FILE)

        val now = System.currentTimeMillis()
        val expiryMs = SyncConfig.getChannelCacheExpiryMinutes() * 60 * 1000L

        return CacheStatus(
            aynaCache = aynaCache?.let {
                CacheInfo(
                    channelCount = it.channels.size,
                    lastUpdated = it.timestamp,
                    isExpired = now - it.timestamp > expiryMs,
                    source = it.source,
                    version = it.version
                )
            },
            bdixCache = bdixCache?.let {
                CacheInfo(
                    channelCount = it.channels.size,
                    lastUpdated = it.timestamp,
                    isExpired = now - it.timestamp > expiryMs,
                    source = it.source,
                    version = it.version
                )
            },
            combinedCache = combinedCache?.let {
                CacheInfo(
                    channelCount = it.channels.size,
                    lastUpdated = it.timestamp,
                    isExpired = now - it.timestamp > expiryMs,
                    source = it.source,
                    version = it.version
                )
            },
            cacheExpiryMinutes = SyncConfig.getChannelCacheExpiryMinutes()
        )
    }

    /**
     * Load backup channels from local cache
     * Returns empty list if not available or expired (> 8 hours old)
     */
    private suspend fun loadBackupChannels(context: Context): List<Channel> = withContext(Dispatchers.IO) {
        try {
            val cacheFile = File(context.filesDir, "backup_channels_cache.json")
            val metadataFile = File(context.filesDir, "backup_channels_metadata.json")

            if (!cacheFile.exists() || !metadataFile.exists()) {
                Log.d(TAG, "⚠️ No backup channels cache found")
                return@withContext emptyList()
            }

            // Check age of backup cache (8 hours = 480 minutes)
            val cacheAgeMinutes = (System.currentTimeMillis() - cacheFile.lastModified()) / (60 * 1000)
            val maxAgeMinutes = 480L // 8 hours

            if (cacheAgeMinutes > maxAgeMinutes) {
                Log.d(TAG, "⚠️ Backup channels cache is old (${cacheAgeMinutes}m > ${maxAgeMinutes}m)")
                return@withContext emptyList()
            }

            // Load and parse backup channels with type-safe conversion
            val content = cacheFile.readText()
            val type = object : TypeToken<List<*>>() {}.type
            val rawChannels = Gson().fromJson<Any>(content, type)

            // Convert any LinkedTreeMap to Channel objects
            val channels = if (rawChannels is List<*>) {
                @Suppress("UNCHECKED_CAST")
                val channelList = rawChannels as List<Any>
                validateAndConvertChannels(channelList)
            } else {
                Log.e(TAG, "❌ Unexpected type in backup cache: ${rawChannels?.javaClass?.simpleName}")
                emptyList()
            }

            Log.d(TAG, "✅ Loaded ${channels.size} channels from backup cache (${cacheAgeMinutes}m old)")
            channels
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error loading backup channels: ${e.message}")
            // Delete corrupted cache file
            try {
                val cacheFile = File(context.filesDir, "backup_channels_cache.json")
                if (cacheFile.exists()) {
                    cacheFile.delete()
                    Log.d(TAG, "🗑️ Deleted corrupted backup cache file")
                }
            } catch (deleteException: Exception) {
                Log.e(TAG, "❌ Error deleting corrupted backup cache: ${deleteException.message}")
            }
            emptyList()
        }
    }

    suspend fun loadChannelsWithSmartCache(
        context: Context,
        username: String? = null,
        password: String? = null
    ): LoadResult = withContext(Dispatchers.IO) {
        Log.d(TAG, "🚀 SMART CACHE LOAD STARTED")

        val firebaseManager = FirebaseManager(context)
        val githubToken = firebaseManager.getGitHubToken()

        // 🚀 STEP 1: Try to load COMBINED cache first (has all merged channels)
        val combinedCache = loadChannelCacheFromFile(context, COMBINED_CACHE_FILE)

        if (combinedCache != null && combinedCache.channels.isNotEmpty()) {
            val now = System.currentTimeMillis()
            val expiryMs = SyncConfig.getChannelCacheExpiryMinutes() * 60 * 1000L
            val isExpired = now - combinedCache.timestamp > expiryMs

            if (!isExpired) {
                // Combined cache is fresh and valid - use it!
                val cachedChannels = combinedCache.channels
                val (bdixChannels, aynaChannels) = separateChannelsBySource(cachedChannels)

                Log.d(TAG, "✅ Loaded ${cachedChannels.size} channels from combined cache")
                Log.d(TAG, "   Ayna: ${aynaChannels.size}, BDIX: ${bdixChannels.size}")

                return@withContext LoadResult(
                    allChannels = cachedChannels,
                    bdixChannels = bdixChannels,
                    aynaChannels = aynaChannels,
                    isFromCache = true,
                    needsBackgroundRefresh = false,
                    source = "combined_cache"
                )
            } else {
                Log.d(TAG, "⚠️ Combined cache expired, downloading backup channels first...")
                // Download backup channels from GitHub first
                if (githubToken.isNotEmpty()) {
                    try {
                        GitHubDataManager.initialize(githubToken)
                        val downloadedBackup = GitHubDataManager.downloadBackupChannels(context)
                        if (downloadedBackup.isNotEmpty()) {
                            Log.d(TAG, "✅ Downloaded ${downloadedBackup.size} backup channels from GitHub")
                            val (bdixBackup, aynaBackup) = separateChannelsBySource(downloadedBackup)

                            // Show backup channels immediately to user
                            // Then trigger background refresh to get fresh data
                            CoroutineScope(Dispatchers.IO).launch {
                                try {
                                    Log.d(TAG, "🔄 Background refresh started after backup download...")
                                    refreshAllChannels(context, username, password)
                                    Log.d(TAG, "✅ Background refresh completed")
                                } catch (e: Exception) {
                                    Log.e(TAG, "❌ Background refresh error: ${e.message}", e)
                                }
                            }

                            return@withContext LoadResult(
                                allChannels = downloadedBackup,
                                bdixChannels = bdixBackup,
                                aynaChannels = aynaBackup,
                                isFromCache = true,
                                needsBackgroundRefresh = false, // Already triggered background refresh
                                source = "github_backup"
                            )
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "❌ Failed to download backup channels: ${e.message}")
                    }
                }

                // No backup available, proceed with immediate refresh
                return@withContext performImmediateRefresh(context, username, password)
            }
        }

        // 🚀 STEP 2: No combined cache available, try backup channels as fallback
        Log.d(TAG, "⚠️ No combined cache, trying backup channels...")
        val backupChannels = loadBackupChannels(context)
        if (backupChannels.isNotEmpty()) {
            Log.d(TAG, "📥 Loaded ${backupChannels.size} backup channels from cache")
            val (bdixBackup, aynaBackup) = separateChannelsBySource(backupChannels)

            // Return backup channels but flag for immediate refresh to get merged channels
            return@withContext LoadResult(
                allChannels = backupChannels,
                bdixChannels = bdixBackup,
                aynaChannels = aynaBackup,
                isFromCache = true,
                needsBackgroundRefresh = true,
                source = "backup_cache"
            )
        }

        // 🚀 STEP 3: Try to download backup channels from GitHub
        if (githubToken.isNotEmpty()) {
            try {
                GitHubDataManager.initialize(githubToken)
                Log.d(TAG, "📥 No local cache, trying GitHub backup...")

                val downloadedBackup = GitHubDataManager.downloadBackupChannels(context)
                if (downloadedBackup.isNotEmpty()) {
                    Log.d(TAG, "✅ Downloaded ${downloadedBackup.size} backup channels from GitHub")
                    val (bdixBackup, aynaBackup) = separateChannelsBySource(downloadedBackup)

                    return@withContext LoadResult(
                        allChannels = downloadedBackup,
                        bdixChannels = bdixBackup,
                        aynaChannels = aynaBackup,
                        isFromCache = true,
                        needsBackgroundRefresh = true,
                        source = "github_backup"
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ GitHub backup download failed: ${e.message}")
            }
        }

        // 🚀 STEP 4: No backup available, try normal GitHub channels
        if (githubToken.isNotEmpty()) {
            try {
                GitHubDataManager.initialize(githubToken)

                Log.d(TAG, "📊 Checking GitHub data freshness...")

                val githubDataAge = GitHubDataManager.getGitHubDataAge()

                when {
                    // ✅ Case 1: GitHub data is fresh (<= 50 min) - use it
                    githubDataAge > 0L && githubDataAge <= SyncConfig.MAX_CHANNEL_CACHE_AGE_MINUTES -> {
                        Log.d(TAG, "📥 GitHub data is fresh (${githubDataAge}m), downloading...")

                        val downloaded = GitHubDataManager.downloadAllFiles(context)

                        if (downloaded) {
                            val combinedCache = loadChannelCacheFromFile(context, COMBINED_CACHE_FILE)
                            if (combinedCache != null && combinedCache.channels.isNotEmpty()) {
                                val cachedChannels = combinedCache.channels
                                val (bdixChannels, aynaChannels) = separateChannelsBySource(cachedChannels)

                                Log.d(TAG, "📊 Loaded ${cachedChannels.size} channels from GitHub")
                                Log.d(TAG, "   Ayna: ${aynaChannels.size}, BDIX: ${bdixChannels.size}")

                                return@withContext LoadResult(
                                    allChannels = cachedChannels,
                                    bdixChannels = bdixChannels,
                                    aynaChannels = aynaChannels,
                                    isFromCache = true,
                                    needsBackgroundRefresh = false,
                                    source = "github_fresh"
                                )
                            }
                        }
                    }

                    // ✅ Case 2: GitHub data is old (> 50 min) - scrape fresh and upload immediately
                    githubDataAge > SyncConfig.MAX_CHANNEL_CACHE_AGE_MINUTES -> {
                        Log.d(TAG, "⚠️ GitHub channel data is old (${githubDataAge}m > ${SyncConfig.MAX_CHANNEL_CACHE_AGE_MINUTES}m), forcing fresh scrape & upload...")
                        // ✅ IMPORTANT: Bypass RefreshCoordinator and scrape directly
                        // This ensures we always get fresh data when GitHub is old
                        val result = refreshAllChannels(context, username, password)
                        if (result.success && result.allChannels.isNotEmpty()) {
                            Log.d(TAG, "✅ Fresh scrape & upload completed: ${result.allChannels.size} channels")
                            val (bdixChannels, aynaChannels) = separateChannelsBySource(result.allChannels)
                            return@withContext LoadResult(
                                allChannels = result.allChannels,
                                bdixChannels = bdixChannels,
                                aynaChannels = aynaChannels,
                                isFromCache = false,  // Fresh data
                                needsBackgroundRefresh = false,
                                source = "fresh_scrape"
                            )
                        }
                    }

                    // ✅ Case 3: No data on GitHub - scrape fresh immediately
                    githubDataAge == -1L -> {
                        Log.d(TAG, "⚠️ No channel data on GitHub, forcing fresh scrape...")
                        return@withContext performImmediateRefresh(context, username, password)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ GitHub check failed: ${e.message}")
                // Fall through to local cache check
            }
        }

        // 🚀 STEP 4: No GitHub token or download failed, perform immediate refresh
        Log.d(TAG, "❌ No cache found, will trigger immediate refresh")
        return@withContext performImmediateRefresh(context, username, password)
    }

    private suspend fun performImmediateRefresh(
        context: Context,
        username: String?,
        password: String?
    ): LoadResult = withContext(Dispatchers.IO) {
        Log.d(TAG, "🔄 Performing immediate refresh...")

        // ✅ Use RefreshCoordinator for thread-safe refresh
        val success = RefreshCoordinator.requestManualRefresh(context, username, password)

        if (!success) {
            Log.w(TAG, "⚠️ Refresh was skipped or failed")
            return@withContext LoadResult(
                allChannels = emptyList(),
                bdixChannels = emptyList(),
                aynaChannels = emptyList(),
                isFromCache = false,
                needsBackgroundRefresh = false
            )
        }

        // Load refreshed cache
        val combinedCache = loadChannelCacheFromFile(context, COMBINED_CACHE_FILE)
        if (combinedCache != null) {
            val (bdixChannels, aynaChannels) = separateChannelsBySource(combinedCache.channels)

            return@withContext LoadResult(
                allChannels = combinedCache.channels,
                bdixChannels = bdixChannels,
                aynaChannels = aynaChannels,
                isFromCache = false,
                needsBackgroundRefresh = false,
                source = "immediate_refresh"
            )
        }

        return@withContext LoadResult(
            allChannels = emptyList(),
            bdixChannels = emptyList(),
            aynaChannels = emptyList(),
            isFromCache = false,
            needsBackgroundRefresh = true,
            source = "no_data"
        )
    }

    /**
     * ✅ Improved Unicode sorting with locale support
     */
    private fun compareValuesByLocale(a: String, b: String): Int {
        return try {
            // Use locale-aware comparison for proper sorting
            val collator = Collator.getInstance()
            collator.strength = Collator.PRIMARY
            collator.compare(a.trim().lowercase(Locale.getDefault()), b.trim().lowercase(Locale.getDefault()))
        } catch (e: Exception) {
            Log.w(TAG, "Locale comparison failed, using fallback: ${e.message}")
            a.trim().compareTo(b.trim(), ignoreCase = true)
        }
    }

    private fun <T> saveToCache(context: Context, filename: String, data: T) {
        try {
            val file = File(context.filesDir, filename)

            // ✅ Use Gson with proper serialization for nested generic types
            val gson = Gson()
            val json = gson.toJson(data)

            if (data is ChannelCache) {
                Log.d(TAG, "💾 Saving $filename (${data.channels.size} channels, v${data.version})")
            }

            file.writeText(json)
            file.setLastModified(System.currentTimeMillis())

            // Verify save
            if (file.exists() && file.length() > 0) {
                Log.d(TAG, "✅ Saved $filename (${file.length()} bytes)")
            } else {
                Log.e(TAG, "❌ Failed to save $filename")
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving cache $filename: ${e.message}")
        }
    }

    /**
     * ✅ Load cache with versioning support and type-safe deserialization
     */
    private fun loadChannelCacheFromFile(context: Context, filename: String): ChannelCache? {
        return try {
            val file = File(context.filesDir, filename)
            // ✅ Increased threshold from 10 to 500 bytes
            if (file.exists() && file.length() > SyncConfig.MIN_CHANNEL_CACHE_FILE_SIZE) {
                val json = file.readText()
                val type = object : TypeToken<ChannelCache>() {}.type

                // ✅ Use Gson for deserialization
                val cache: ChannelCache = Gson().fromJson(json, type)

                // ✅ Validate and fix channel types (handle LinkedTreeMap conversion)
                // Always validate to handle both Channel and LinkedTreeMap cases
                @Suppress("UNCHECKED_CAST")
                val validatedChannels = validateAndConvertChannels(cache.channels as List<Any>)
                val validatedCache = cache.copy(channels = validatedChannels)

                // ✅ Check cache version
                if (validatedCache.version < SyncConfig.CURRENT_CACHE_VERSION) {
                    Log.d(TAG, "📦 Cache v${validatedCache.version} needs migration to v${SyncConfig.CURRENT_CACHE_VERSION}")
                    val migratedCache = migrateCache(validatedCache)
                    // ✅ IMPORTANT: Save migrated cache back to file
                    Log.d(TAG, "💾 Saving migrated cache to $filename")
                    saveToCache(context, filename, migratedCache)
                    return migratedCache
                } else if (validatedCache.version > SyncConfig.CURRENT_CACHE_VERSION) {
                    Log.w(TAG, "⚠️ Cache v${validatedCache.version} is newer than app v${SyncConfig.CURRENT_CACHE_VERSION}, may have issues")
                }

                Log.d(TAG, "📂 Loaded $filename: ${validatedCache.channels.size} channels (v${validatedCache.version})")

                // If we had to convert any channels, save the fixed cache
                if (validatedChannels.size != cache.channels.size) {
                    Log.d(TAG, "🔧 Fixed channel types, saving corrected cache...")
                    saveToCache(context, filename, validatedCache)
                }

                validatedCache
            } else {
                Log.d(TAG, "📂 $filename not found or too small (${if (File(context.filesDir, filename).exists()) File(context.filesDir, filename).length() else 0} bytes)")
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error loading $filename: ${e.message}", e)
            // If there's an error loading the cache, delete the corrupted file
            try {
                val file = File(context.filesDir, filename)
                if (file.exists()) {
                    file.delete()
                    Log.d(TAG, "🗑️ Deleted corrupted cache file: $filename")
                }
            } catch (deleteException: Exception) {
                Log.e(TAG, "❌ Error deleting corrupted cache: ${deleteException.message}")
            }
            null
        }
    }

    /**
     * ✅ Validate and convert channels from LinkedTreeMap to Channel objects
     * This handles cases where old cache files have incorrect types
     * PUBLIC function for use by GitHubDataManager
     */
    fun validateAndConvertChannels(channels: List<Any>): List<Channel> {
        val validChannels = mutableListOf<Channel>()

        channels.forEach { channel ->
            try {
                when (channel) {
                    is Channel -> {
                        // Already a valid Channel object
                        validChannels.add(channel)
                    }
                    is Map<*, *> -> {
                        // LinkedTreeMap - convert to Channel
                        val name = channel["name"] as? String ?: ""
                        val urls = (channel["urls"] as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                        val logo = channel["logo"] as? String ?: ""
                        val category = channel["category"] as? String ?: "General"
                        val source = channel["source"] as? String ?: "unknown"

                        val convertedChannel = Channel(
                            name = name,
                            urls = urls,
                            logo = logo,
                            category = category,
                            source = source
                        )
                        validChannels.add(convertedChannel)
                        Log.w(TAG, "   🔧 Converted LinkedTreeMap to Channel: $name")
                    }
                    else -> {
                        Log.w(TAG, "   ⚠️ Unknown channel type: ${channel.javaClass.simpleName}, skipping")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "   ❌ Error converting channel: ${e.message}")
            }
        }

        return validChannels
    }

    /**
     * ✅ Cache migration logic - Fixed to handle all old versions
     */
    private fun migrateCache(oldCache: ChannelCache): ChannelCache {
        Log.d(TAG, "🔄 Migrating cache from v${oldCache.version} to v${SyncConfig.CURRENT_CACHE_VERSION}")

        val migratedChannels = when (oldCache.version) {
            1, 0 -> {
                // Migration from v0/v1 to v2: Just use channels as-is
                Log.d(TAG, "   Migrating v${oldCache.version} -> v2: Using existing data")
                oldCache.channels
            }
            else -> {
                Log.w(TAG, "   No migration defined for v${oldCache.version}, using as-is")
                oldCache.channels
            }
        }

        return ChannelCache(
            channels = migratedChannels,
            timestamp = System.currentTimeMillis(),  // Update timestamp
            source = oldCache.source,
            version = SyncConfig.CURRENT_CACHE_VERSION
        )
    }

    /**
     * FIXED: Properly separate channels by source
     * Now handles cases where source field might be different
     */
    fun separateChannelsBySource(channels: List<Channel>): Pair<List<Channel>, List<Channel>> {
        val bdixList = mutableListOf<Channel>()
        val aynaList = mutableListOf<Channel>()
        var unknownCount = 0

        Log.d(TAG, "🔀 Separating ${channels.size} channels by source...")

        channels.forEach { channel ->
            val source = channel.source.lowercase().trim()

            when {
                // Check for Ayna source
                source.contains("ayna") ||
                        channel.isAynaChannel() -> {
                    aynaList.add(channel)
                }
                // Check for BDIX source
                source.contains("bdix") ||
                        source.contains("other") ||
                        source.contains("basnet") ||
                        source.contains("ksb") ||
                        source.contains("redforce") ||
                        channel.isBdixChannel() -> {
                    bdixList.add(channel)
                }
                // Unknown source - add to BDIX by default
                else -> {
                    unknownCount++
                    bdixList.add(channel)

                    // Log unknown sources for debugging
                    if (unknownCount <= 5) {
                        Log.w(TAG, "   Unknown source: '${channel.source}' for channel: ${channel.name}")
                    }
                }
            }
        }

        Log.d(TAG, "📊 Separation result:")
        Log.d(TAG, "   - Ayna: ${aynaList.size}")
        Log.d(TAG, "   - BDIX: ${bdixList.size}")
        Log.d(TAG, "   - Unknown (added to BDIX): $unknownCount")

        return Pair(bdixList, aynaList)
    }

    // Data classes
    data class LoadResult(
        val allChannels: List<Channel>,
        val bdixChannels: List<Channel>,
        val aynaChannels: List<Channel>,
        val isFromCache: Boolean,
        val needsBackgroundRefresh: Boolean,
        val source: String = "unknown"  // Indicates where channels came from
    )

    data class RefreshResult(
        val allChannels: List<Channel>,
        val success: Boolean
    )

    data class CacheInfo(
        val channelCount: Int,
        val lastUpdated: Long,
        val isExpired: Boolean,
        val source: String,
        val version: Int = 1
    )

    data class CacheStatus(
        val aynaCache: CacheInfo?,
        val bdixCache: CacheInfo?,
        val combinedCache: CacheInfo?,
        val cacheExpiryMinutes: Long
    )
}

// ✅ Updated ChannelCache with version support
data class ChannelCache(
    val channels: List<Channel>,
    val timestamp: Long,
    val source: String,
    val version: Int = 1
)

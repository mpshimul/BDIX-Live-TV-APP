package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Log
import com.shimulfp.bdixlivetv.FirebaseManager
import com.shimulfp.bdixlivetv.data.SeriesRepository
import com.shimulfp.bdixlivetv.data.SeriesScraper
import com.shimulfp.bdixlivetv.models.Series
import kotlinx.coroutines.*
import kotlinx.coroutines.Dispatchers.IO

/**
 * Service for syncing series data with GitHub
 * Similar to MovieSyncService but for series
 */
object SeriesSyncService {
    private const val TAG = "SeriesSyncService"

    /**
     * Start periodic sync for series
     */
    fun startPeriodicSync(context: Context) {
        CoroutineScope(IO).launch {
            try {
                Log.d(TAG, "🔄 Starting periodic series sync...")
                syncSeries(context)
            } catch (e: Exception) {
                Log.e(TAG, "Periodic sync error: ${e.message}")
            }
        }
    }

    /**
     * Main sync function for series
     */
    suspend fun syncSeries(context: Context): SyncResult = withContext(IO) {
        Log.d(TAG, "🚀 === SERIES SYNC START ===")

        return@withContext try {
            val firebaseManager = FirebaseManager(context)
            val githubToken = firebaseManager.getGitHubToken()

            if (githubToken.isEmpty()) {
                Log.w(TAG, "⚠️ No GitHub token available")
                return@withContext SyncResult.NoToken
            }

            // Initialize GitHubDataManager
            GitHubDataManager.initialize(githubToken)

            // Strategy: Try GitHub first, fallback to scraping
            val result = tryGitHubFirst(context, githubToken)

            Log.d(TAG, "✅ Series sync completed: ${result.getMessage()}")
            result

        } catch (e: Exception) {
            Log.e(TAG, "❌ Series sync error: ${e.message}", e)
            SyncResult.Error(e.message ?: "Unknown error")
        }
    }

    /**
     * Try GitHub first, fallback to scraping
     *
     * LOGIC:
     * - If GitHub data is FRESH (<2 hours) → Download only (NO scraping needed)
     * - If GitHub data is OLD or missing → Scrape & Upload immediately
     */
    private suspend fun tryGitHubFirst(
        context: Context,
        githubToken: String
    ): SyncResult = withContext(IO) {
        return@withContext try {
            // Check if GitHub data is fresh (<2 hours)
            val isGitHubFresh = GitHubDataManager.isSeriesDataFresh()
            Log.d(TAG, "🔍 GitHub series data fresh check: $isGitHubFresh")

            if (isGitHubFresh) {
                Log.d(TAG, "✅ GitHub series data is fresh, downloading only...")
                val series = GitHubDataManager.downloadSeries(context)

                if (series.isNotEmpty()) {
                    // Save to repository cache
                    val repo = SeriesRepository.getInstance(context)
                    repo.clearCache()
                    saveSeriesToCache(context, series)

                    Log.d(TAG, "✅ Downloaded ${series.size} series from GitHub (no scraping needed)")
                    return@withContext SyncResult.GitHubDownload(series.size)
                } else {
                    Log.w(TAG, "⚠️ GitHub said data was fresh but download returned empty, falling back to scrape...")
                }
            } else {
                Log.d(TAG, "📅 GitHub data is old/missing, will scrape & upload")
            }

            // If GitHub failed, returned empty, or not fresh, scrape fresh and upload
            Log.d(TAG, "🔄 Starting scrape & upload process...")
            scrapeAndUpload(context, githubToken)

        } catch (e: Exception) {
            Log.e(TAG, "GitHub first strategy failed: ${e.message}", e)
            // Fallback to scraping
            scrapeAndUpload(context, githubToken)
        }
    }

    /**
     * Scrape fresh series and upload to GitHub
     * CRITICAL: When scraping happens, we MUST upload to GitHub immediately
     */
    private suspend fun scrapeAndUpload(
        context: Context,
        githubToken: String
    ): SyncResult = withContext(IO) {
        return@withContext try {
            Log.d(TAG, "🔄 Scraping fresh series data...")

            // ✅ No limit passed – Python uses its own default (now 250)
            val series = SeriesScraper.scrapeAllSeries(context)

            if (series.isEmpty()) {
                Log.e(TAG, "❌ Scraping failed, no series found")
                return@withContext SyncResult.ScrapingFailed
            }

            Log.d(TAG, "✅ Scraped ${series.size} series successfully")

            // Save locally FIRST
            val repo = SeriesRepository.getInstance(context)
            repo.clearCache()
            saveSeriesToCache(context, series)

            // CRITICAL: Upload to GitHub IMMEDIATELY after scraping
            // This ensures scraped data is preserved for future users
            Log.d(TAG, "🚀 CRITICAL: Uploading ${series.size} scraped series to GitHub...")

            if (!GitHubDataManager.isInitialized()) {
                Log.w(TAG, "⚠️ GitHubDataManager not initialized, re-initializing...")
                GitHubDataManager.initialize(githubToken)
            }

            if (githubToken.isEmpty()) {
                Log.e(TAG, "❌ Cannot upload: GitHub token is empty")
                return@withContext SyncResult.ScrapedOnly(series.size)
            }

            return@withContext try {
                Log.d(TAG, "📊 Pre-upload check:")
                Log.d(TAG, "   - GitHubDataManager.isInitialized: ${GitHubDataManager.isInitialized()}")
                Log.d(TAG, "   - githubToken.isEmpty: ${githubToken.isEmpty()}")
                Log.d(TAG, "   - Series size: ${series.size}")
                Log.d(TAG, "   - Token length: ${githubToken.length}")
                Log.d(TAG, "📊 Calling GitHubDataManager.uploadSeries()...")

                val uploaded = GitHubDataManager.uploadSeries(context, series)

                Log.d(TAG, "📊 uploadSeries() returned: $uploaded")

                if (uploaded) {
                    Log.d(TAG, "✅ SUCCESS: Uploaded ${series.size} series to GitHub!")
                    Log.d(TAG, "   Future users will download this data instead of re-scraping")
                    SyncResult.ScrapedAndUploaded(series.size)
                } else {
                    Log.e(TAG, "❌ FAILED: Upload returned false")
                    Log.e(TAG, "   Scraped data is saved locally but NOT uploaded to GitHub")
                    Log.e(TAG, "   This data will be lost if the app is cleared!")
                    SyncResult.ScrapedOnly(series.size)
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ EXCEPTION during upload: ${e.message}", e)
                Log.e(TAG, "   Scraped data is saved locally but NOT uploaded to GitHub")
                SyncResult.ScrapedOnly(series.size)
            }

        } catch (e: Exception) {
            Log.e(TAG, "❌ Scrape and upload error: ${e.message}", e)
            SyncResult.Error(e.message ?: "Unknown error")
        }
    }

    /**
     * Save series to cache
     */
    private fun saveSeriesToCache(context: Context, series: List<Series>) {
        try {
            val file = java.io.File(context.filesDir, "series_cache.json")
            file.writeText(com.google.gson.Gson().toJson(series))
            file.setLastModified(System.currentTimeMillis())
            Log.d(TAG, "💾 Saved ${series.size} series to cache")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving series to cache: ${e.message}")
        }
    }

    /**
     * Force refresh series from GitHub or scrape fresh
     */
    suspend fun forceRefresh(context: Context): SyncResult = withContext(IO) {
        Log.d(TAG, "🔄 Force refreshing series...")

        return@withContext try {
            val firebaseManager = FirebaseManager(context)
            val githubToken = firebaseManager.getGitHubToken()

            if (githubToken.isEmpty()) {
                Log.w(TAG, "⚠️ No GitHub token available")
                return@withContext SyncResult.NoToken
            }

            GitHubDataManager.initialize(githubToken)

            // Always scrape fresh data on force refresh
            val series = SeriesScraper.scrapeAllSeries(context)

            if (series.isEmpty()) {
                Log.e(TAG, "❌ Force refresh: No series found")
                return@withContext SyncResult.ScrapingFailed
            }

            Log.d(TAG, "✅ Force refresh: Scraped ${series.size} series")

            // Save locally
            saveSeriesToCache(context, series)

            // Try to upload to GitHub
            return@withContext try {
                Log.d(TAG, "🚀 Uploading to GitHub...")
                val uploaded = GitHubDataManager.uploadSeries(context, series)

                if (uploaded) {
                    Log.d(TAG, "🎉 Force refresh: Uploaded ${series.size} series")
                    SyncResult.ScrapedAndUploaded(series.size)
                } else {
                    SyncResult.ScrapedOnly(series.size)
                }
            } catch (e: Exception) {
                Log.w(TAG, "⚠️ Upload failed: ${e.message}")
                SyncResult.ScrapedOnly(series.size)
            }

        } catch (e: Exception) {
            Log.e(TAG, "❌ Force refresh error: ${e.message}")
            SyncResult.Error(e.message ?: "Unknown error")
        }
    }

    // ============ DATA CLASSES ============

    sealed class SyncResult {
        object NoToken : SyncResult()
        data class GitHubDownload(val count: Int) : SyncResult()
        data class ScrapedAndUploaded(val count: Int) : SyncResult()
        data class ScrapedOnly(val count: Int) : SyncResult()
        object ScrapingFailed : SyncResult()

        // Alternative fix: Use @JvmField to avoid generating getter
        data class Error(@JvmField val message: String) : SyncResult()

        fun getMessage(): String {
            return when (this) {
                is GitHubDownload -> "Downloaded $count series from GitHub"
                is ScrapedAndUploaded -> "Scraped and uploaded $count series"
                is ScrapedOnly -> "Scraped $count series"
                is ScrapingFailed -> "Scraping failed"
                is Error -> "Error: ${this.message}"
                NoToken -> "No GitHub token"
            }
        }
    }
}
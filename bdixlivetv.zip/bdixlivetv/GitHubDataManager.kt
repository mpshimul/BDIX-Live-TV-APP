package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Base64
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

object GitHubDataManager {
    private const val TAG = "GitHubDataManager"

    fun getToken(): String {
        return if (::githubToken.isInitialized) githubToken else ""
    }

    private const val GITHUB_API_URL = "https://api.github.com"
    private const val MAX_CACHE_AGE_MINUTES = 120L // 2 hours for movies
    //private const val MAX_CACHE_AGE_MINUTES = 5L // 5 Minutes for movies test
    private const val MAX_CHANNEL_CACHE_AGE_MINUTES = 40L // 40 minutes for channels
    //private const val MAX_CHANNEL_CACHE_AGE_MINUTES = 5L // 5 minutes for channels test

    // Repo configuration
    private const val REPO_OWNER = "mpshimul"
    private const val REPO_NAME = "BDIX-TV"
    private const val BRANCH = "main"
    private const val CHANNELS_DIR = "scripts/channels_v1"

    // ALL files to upload/download
    private val ALL_FILES = listOf(
        "ayna_channels_cache.json",
        "bdix_channels_cache.json",
        "all_channels_cache.json",
        "tokens.json",
        "movies_cache.json",
        "series_cache.json",
    )

    private lateinit var githubToken: String
    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Initialize with GitHub token
     */
    fun initialize(token: String) {
        githubToken = token.trim()
        Log.d(TAG, "✅ GitHubDataManager initialized")
        Log.d(TAG, "🔑 Token present: ${token.isNotEmpty()}")
    }

    /**
     * Check if token is initialized
     */
    fun isInitialized(): Boolean {
        return ::githubToken.isInitialized && githubToken.isNotEmpty()
    }

    // ============ CHANNEL METHODS ============

    /**
     * Main sync function for channels
     */
    suspend fun checkAndSyncData(context: Context): SyncResult = withContext(Dispatchers.IO) {
        Log.d(TAG, "🚀 === STARTING GITHUB SYNC ===")

        if (!::githubToken.isInitialized || githubToken.isEmpty()) {
            Log.e(TAG, "❌ GitHub token not initialized")
            return@withContext SyncResult.NoToken
        }

        try {
            // Check token validity
            val tokenValid = isTokenValid()
            if (!tokenValid) {
                Log.e(TAG, "❌ GitHub token is invalid")
                return@withContext SyncResult.Error("Invalid GitHub token")
            }

            // Check GitHub data age
            Log.d(TAG, "📊 Checking GitHub data age...")
            val githubDataAge = getGitHubDataAge()
            Log.d(TAG, "📅 GitHub data age: ${githubDataAge}m (max: ${MAX_CHANNEL_CACHE_AGE_MINUTES}m)")

            // If GitHub data is FRESH (≤ 50 minutes) OR doesn't exist (-1), download it
            if (githubDataAge == -1L) {
                // No data on GitHub at all
                Log.d(TAG, "⚠️ No data on GitHub, will scrape fresh")
            } else if (githubDataAge <= MAX_CHANNEL_CACHE_AGE_MINUTES) {
                // GitHub data is FRESH (≤ 50 minutes)
                Log.d(TAG, "🔄 GitHub data is fresh (${githubDataAge}m), downloading...")
                val downloaded = downloadAllFiles(context)

                if (downloaded) {
                    val valid = isDownloadedDataValid(context)
                    if (valid) {
                        Log.d(TAG, "✅ Successfully downloaded fresh data from GitHub")
                        return@withContext SyncResult.Downloaded(githubDataAge)
                    } else {
                        Log.w(TAG, "⚠️ Downloaded data invalid, will scrape fresh")
                    }
                } else {
                    Log.w(TAG, "⚠️ Download failed, will scrape fresh")
                }
            } else {
                // GitHub data is OLD (> 50 minutes) - DON'T download, scrape fresh
                Log.d(TAG, "⚠️ GitHub data is old (${githubDataAge}m > ${MAX_CHANNEL_CACHE_AGE_MINUTES}m), scraping fresh...")
            }

            // If we get here, either GitHub data is old or download failed
            Log.d(TAG, "🔄 Scraping fresh data...")

            val firebaseManager = FirebaseManager(context)
            val username = firebaseManager.getAynaUsername() ?: "username@email.com"
            val password = firebaseManager.getAynaPassword() ?: ""

            Log.d(TAG, "👤 Username: ${username.take(5)}...")

            // Scrape BDIX channels
            val bdixChannels = try {
                Log.d(TAG, "🔄 Scraping BDIX channels...")
                PythonHelper.getOtherSourcesChannels(context).also {
                    Log.d(TAG, "✅ BDIX scraped: ${it.size} channels")
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ BDIX scraping failed: ${e.message}")
                emptyList()
            }

            // Scrape AynaOTT channels
            val aynaChannels = try {
                Log.d(TAG, "🔄 Scraping AynaOTT channels...")
                PythonHelper.getAynaChannels(context, username, password, true).also {
                    Log.d(TAG, "✅ AynaOTT scraped: ${it.size} channels")
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ AynaOTT scraping failed: ${e.message}")
                emptyList()
            }

            if (bdixChannels.isEmpty() && aynaChannels.isEmpty()) {
                Log.e(TAG, "❌ No channels scraped from any source")
                return@withContext SyncResult.ScrapingFailed
            }

            // Combine and deduplicate
            val allChannels = (bdixChannels + aynaChannels)
                .distinctBy { it.name.uppercase().trim() }
                .sortedBy { it.name }

            Log.d(TAG, "✅ Total unique channels: ${allChannels.size}")

            // Save locally
            saveChannelsToFile(context, "bdix_channels_cache.json", bdixChannels)
            saveChannelsToFile(context, "ayna_channels_cache.json", aynaChannels)
            saveChannelsToFile(context, "all_channels_cache.json", allChannels)

            // Upload ALL files to GitHub (including tokens.json)
            Log.d(TAG, "🚀 Uploading fresh data to GitHub...")
            val uploaded = uploadAllFiles(context)

            if (uploaded) {
                Log.d(TAG, "🎉 SUCCESS: Uploaded ${allChannels.size} channels + tokens to GitHub")
                return@withContext SyncResult.ScrapedAndUploaded(allChannels.size)
            } else {
                Log.w(TAG, "⚠️ Scraped but failed to upload")
                return@withContext SyncResult.ScrapedOnly(allChannels.size)
            }

        } catch (e: Exception) {
            Log.e(TAG, "❌ Sync error: ${e.message}", e)
            return@withContext SyncResult.Error(e.message ?: "Unknown error")
        }
    }

    private suspend fun isTokenValid(): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            val request = Request.Builder()
                .url("$GITHUB_API_URL/user")
                .header("Authorization", "Bearer $githubToken")
                .get()
                .build()

            val response = client.newCall(request).execute()
            val isValid = response.isSuccessful
            response.close()
            isValid
        } catch (e: Exception) {
            false
        }
    }

    /**
     * PUBLIC function to get GitHub data age (used by ChannelCacheManager)
     */
    suspend fun getGitHubDataAge(): Long = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "📅 Calculating GitHub data age...")
            var totalAge = 0L
            var count = 0

            // Check only channel files for channel data age
            val channelFiles = listOf(
                "ayna_channels_cache.json",
                "bdix_channels_cache.json",
                "all_channels_cache.json"
            )

            for (filename in channelFiles) {
                try {
                    val age = getSingleFileAge(filename)
                    Log.d(TAG, "   $filename age: ${age}m")

                    if (age > 0L) {
                        totalAge += age
                        count++
                    } else if (age == -1L) {
                        Log.d(TAG, "   $filename: Does not exist on GitHub")
                        // If any channel file doesn't exist, consider data as non-existent
                        return@withContext -1L
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "⚠️ Could not get age for $filename: ${e.message}")
                }
            }

            if (count == 0) {
                -1L // No files on GitHub
            } else {
                val avgAge = totalAge / count
                Log.d(TAG, "📊 Average channel data age: ${avgAge}m")
                avgAge
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting GitHub data age: ${e.message}")
            -1L
        }
    }

    /**
     * Check if GitHub movie data is fresh (<2 hours)
     */
    private const val MOVIE_FRESHNESS_THRESHOLD_MINUTES = 120L // 2 hours
    //private const val MOVIE_FRESHNESS_THRESHOLD_MINUTES = 5L // 5 Minutes test

    /**
     * Check if GitHub movie data is fresh (<2 hours)
     */
    suspend fun isMovieDataFresh(): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            val movieFileAge = getSingleFileAge("movies_cache.json")

            if (movieFileAge == -1L) {
                Log.d(TAG, "⚠️ No movie data on GitHub")
                return@withContext false
            }

            val isFresh = movieFileAge <= SyncConfig.MOVIE_FRESHNESS_THRESHOLD_MINUTES

            Log.d(TAG, "📊 Movie data age: ${movieFileAge}m (fresh: $isFresh, threshold: ${SyncConfig.MOVIE_FRESHNESS_THRESHOLD_MINUTES}m)")
            isFresh
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error checking movie data freshness: ${e.message}")
            false
        }
    }

    /**
     * Get GitHub movie data age in minutes
     */
    suspend fun getMovieDataAge(): Long = withContext(Dispatchers.IO) {
        return@withContext try {
            getSingleFileAge("movies_cache.json")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting movie data age: ${e.message}")
            -1L
        }
    }

    /**
     * Get local movie cache age in minutes
     */
    fun getLocalMovieCacheAge(context: Context): Long {
        return try {
            val file = File(context.filesDir, "movies_cache.json")
            if (file.exists()) {
                val ageMinutes = (System.currentTimeMillis() - file.lastModified()) / (60 * 1000)
                ageMinutes
            } else {
                -1L // File doesn't exist
            }
        } catch (e: Exception) {
            -1L
        }
    }

    /**
     * Get single file age from GitHub
     */
    private suspend fun getSingleFileAge(filename: String): Long = withContext(Dispatchers.IO) {
        return@withContext try {
            val request = Request.Builder()
                .url("$GITHUB_API_URL/repos/$REPO_OWNER/$REPO_NAME/contents/$CHANNELS_DIR/$filename")
                .header("Authorization", "Bearer $githubToken")
                .get()
                .build()

            val response = client.newCall(request).execute()

            if (response.isSuccessful) {
                val commitsRequest = Request.Builder()
                    .url("$GITHUB_API_URL/repos/$REPO_OWNER/$REPO_NAME/commits?path=$CHANNELS_DIR/$filename&per_page=1")
                    .header("Authorization", "Bearer $githubToken")
                    .get()
                    .build()

                val commitsResponse = client.newCall(commitsRequest).execute()
                if (commitsResponse.isSuccessful) {
                    val commitsArray = JSONArray(commitsResponse.body?.string() ?: "")
                    if (commitsArray.length() > 0) {
                        val commit = commitsArray.getJSONObject(0)
                        val commitDate = commit.getJSONObject("commit")
                            .getJSONObject("committer")
                            .getString("date")

                        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
                        dateFormat.timeZone = TimeZone.getTimeZone("UTC")
                        val date = dateFormat.parse(commitDate)

                        if (date != null) {
                            return@withContext (System.currentTimeMillis() - date.time) / (60 * 1000)
                        }
                    }
                }
            } else if (response.code == 404) {
                return@withContext -1L // File doesn't exist
            }
            response.close()
            -1L
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting file age for $filename: ${e.message}")
            -1L
        }
    }

    /**
     * Download ALL files from GitHub (including tokens.json)
     */
    suspend fun downloadAllFiles(context: Context): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "📥 Starting download of ${ALL_FILES.size} files...")
            var successCount = 0

            for (filename in ALL_FILES) {
                Log.d(TAG, "   Downloading $filename...")
                if (downloadSingleFile(filename, context)) {
                    successCount++
                }
            }

            val result = successCount == ALL_FILES.size
            Log.d(TAG, "📊 Download result: $successCount/${ALL_FILES.size} files ${if (result) "✅" else "❌"}")
            result
        } catch (e: Exception) {
            Log.e(TAG, "❌ Download error: ${e.message}", e)
            false
        }
    }

    /**
     * Download single file from GitHub
     */
    private fun downloadSingleFile(filename: String, context: Context): Boolean {
        var response: Response? = null
        return try {
            val fileUrl = "$GITHUB_API_URL/repos/$REPO_OWNER/$REPO_NAME/contents/$CHANNELS_DIR/$filename"
            Log.d(TAG, "   📡 Requesting: $fileUrl")

            val request = Request.Builder()
                .url(fileUrl)
                .header("Authorization", "Bearer $githubToken")
                .get()
                .build()

            response = client.newCall(request).execute()

            Log.d(TAG, "   📡 Response for $filename: HTTP ${response.code}")

            // Read the response body once and store it
            val responseBody = response.body?.string() ?: ""

            if (response.isSuccessful) {
                // Check if response is empty
                if (responseBody.isEmpty()) {
                    Log.e(TAG, "   ❌ Empty response body for $filename")
                    return false
                }

                val json = try {
                    JSONObject(responseBody)
                } catch (e: Exception) {
                    Log.e(TAG, "   ❌ Invalid JSON for $filename: ${e.message}")
                    Log.e(TAG, "   Response: ${responseBody.take(200)}")
                    return false
                }

                // Check for GitHub API errors
                if (json.has("message")) {
                    val errorMessage = json.getString("message")
                    Log.e(TAG, "   ❌ GitHub API error for $filename: $errorMessage")
                    return false
                }

                // Check file size
                val size = json.optLong("size", 0)
                Log.d(TAG, "   📏 File size: $size bytes")

                // For large files, GitHub returns empty content and provides download_url
                val content = json.optString("content", "")
                val downloadUrl = json.optString("download_url", "")
                val encoding = json.optString("encoding", "base64")

                Log.d(TAG, "   📡 Content length: ${content.length}")
                Log.d(TAG, "   📡 Download URL: $downloadUrl")
                Log.d(TAG, "   📡 Encoding: $encoding")

                val decodedContent: String = if (content.isNotEmpty()) {
                    // Small file - content is included directly
                    if (encoding == "base64") {
                        try {
                            String(Base64.decode(content, Base64.DEFAULT))
                        } catch (e: Exception) {
                            Log.e(TAG, "   ❌ Base64 decode error: ${e.message}")
                            return false
                        }
                    } else {
                        content
                    }
                } else if (downloadUrl.isNotEmpty()) {
                    // Large file - need to download separately
                    Log.d(TAG, "   📥 Large file detected, downloading from: $downloadUrl")
                    downloadLargeFile(downloadUrl)
                } else {
                    // No content and no download URL
                    Log.e(TAG, "   ❌ No content or download URL for $filename")
                    return false
                }

                if (decodedContent.isEmpty()) {
                    Log.e(TAG, "   ❌ Decoded content is empty for $filename")
                    return false
                }

                // Validate content based on file type
                val isContentValid = when (filename) {
                    "tokens.json" -> {
                        // tokens.json can be JSON object or array
                        decodedContent.isNotEmpty() &&
                                decodedContent.trim().let { trimmed ->
                                    trimmed.startsWith("{") || trimmed.startsWith("[")
                                }
                    }
                    "movies_cache.json" -> {
                        // movies_cache.json should be a non-empty JSON array
                        decodedContent.isNotEmpty() &&
                                decodedContent.trim().let { trimmed ->
                                    trimmed.startsWith("[") && trimmed.endsWith("]") &&
                                            trimmed.length > 2 // Not just "[]"
                                }
                    }
                    "series_cache.json" -> {
                        // series_cache.json should be a non-empty JSON array
                        decodedContent.isNotEmpty() &&
                                decodedContent.trim().let { trimmed ->
                                    trimmed.startsWith("[") && trimmed.endsWith("]") &&
                                            trimmed.length > 2 // Not just "[]"
                                }
                    }
                    else -> { // Channel files
                        // Channel files should be JSON objects with content
                        decodedContent.isNotEmpty() &&
                                decodedContent.trim().let { trimmed ->
                                    trimmed.startsWith("{") && trimmed.endsWith("}")
                                }
                    }
                }

                if (isContentValid) {
                    val file = File(context.filesDir, filename)
                    file.writeText(decodedContent)
                    file.setLastModified(System.currentTimeMillis())

                    // Log file size and sample
                    val sizeKB = decodedContent.length / 1024
                    val sample = decodedContent.take(100).replace("\n", " ")
                    Log.d(TAG, "   ✅ Downloaded $filename ($sizeKB KB, ${decodedContent.length} chars)")
                    Log.d(TAG, "   Sample: $sample...")
                    return true
                } else {
                    // Log what we actually received for debugging
                    Log.w(TAG, "   ⚠️ $filename validation failed")
                    Log.w(TAG, "   Content length: ${decodedContent.length}")
                    if (decodedContent.isNotEmpty()) {
                        Log.w(TAG, "   First 200 chars: ${decodedContent.take(200)}")
                        Log.w(TAG, "   Content starts with: '${decodedContent.take(10)}'")
                        Log.w(TAG, "   Content ends with: '${decodedContent.takeLast(10)}'")
                    } else {
                        Log.w(TAG, "   Content is completely empty")
                    }
                    return false
                }
            } else if (response.code == 404) {
                Log.d(TAG, "   ⚠️ $filename doesn't exist on GitHub (404)")
                return false
            } else {
                Log.e(TAG, "   ❌ Failed to download $filename: HTTP ${response.code}")
                Log.e(TAG, "   Error body: ${responseBody.take(200)}")
                return false
            }
        } catch (e: Exception) {
            Log.e(TAG, "   ❌ Download error for $filename: ${e.message}", e)
            false
        } finally {
            response?.close()
        }
    }

    /**
     * Download large file using the download_url
     */
    private fun downloadLargeFile(downloadUrl: String): String {
        var response: Response? = null
        return try {
            Log.d(TAG, "   📥 Downloading large file from: $downloadUrl")

            val request = Request.Builder()
                .url(downloadUrl)
                .get()
                .build()

            response = client.newCall(request).execute()

            if (response.isSuccessful) {
                val content = response.body?.string() ?: ""
                Log.d(TAG, "   📥 Large file download successful: ${content.length} bytes")
                content
            } else {
                Log.e(TAG, "   ❌ Large file download failed: HTTP ${response.code}")
                ""
            }
        } catch (e: Exception) {
            Log.e(TAG, "   ❌ Large file download error: ${e.message}")
            ""
        } finally {
            response?.close()
        }
    }

    /**
     * Check if downloaded data is valid
     */
    private fun isDownloadedDataValid(context: Context): Boolean {
        return try {
            var validFiles = 0
            var totalFiles = 0

            for (filename in ALL_FILES) {
                totalFiles++
                val file = File(context.filesDir, filename)
                if (file.exists()) {
                    val content = file.readText()

                    // Different validation for different file types
                    val isValid = when (filename) {
                        "tokens.json" -> {
                            val result = content.isNotEmpty() &&
                                    (content.contains("\"aynaott\"") || content.contains("\"access_token\"")) &&
                                    !content.trim().endsWith("[]")
                            Log.d(TAG, "tokens.json validation: $result (${content.length} bytes)")
                            result
                        }
                        "movies_cache.json" -> {
                            val result = content.isNotEmpty() &&
                                    content.length > 100 && // Lower threshold for testing
                                    content.trim().startsWith("[") &&
                                    content.trim().endsWith("]") &&
                                    content.contains("\"title\"")
                            Log.d(TAG, "movies_cache.json validation: $result (${content.length} bytes)")
                            Log.d(TAG, "   First 50 chars: ${content.take(50)}")
                            Log.d(TAG, "   Last 50 chars: ${content.takeLast(50)}")
                            result
                        }
                        else -> { // Channel files
                            val result = content.length > 100 &&
                                    content.contains("\"channels\"") &&
                                    !content.trim().endsWith("[]")
                            Log.d(TAG, "$filename validation: $result (${content.length} bytes)")
                            result
                        }
                    }

                    if (isValid) {
                        validFiles++
                    }
                } else {
                    Log.w(TAG, "⚠️ $filename does not exist locally")
                }
            }

            Log.d(TAG, "📊 Validation: $validFiles/$totalFiles files valid")

            // Need at least tokens.json and one channel file to be valid
            val atLeastOneChannelFile = File(context.filesDir, "all_channels_cache.json").exists() ||
                    File(context.filesDir, "ayna_channels_cache.json").exists() ||
                    File(context.filesDir, "bdix_channels_cache.json").exists()

            val result = validFiles >= 2 && atLeastOneChannelFile
            Log.d(TAG, "📊 Final validation result: $result")
            result
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error validating data: ${e.message}", e)
            false
        }
    }

    /**
     * UPLOAD ALL FILES to GitHub (including tokens.json)
     */
    suspend fun uploadAllFiles(context: Context): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "🚀 === STARTING UPLOAD ===")

            var uploadedCount = 0

            for (filename in ALL_FILES) {
                val file = File(context.filesDir, filename)

                Log.d(TAG, "📤 Processing $filename...")
                Log.d(TAG, "   File exists: ${file.exists()}")

                if (file.exists()) {
                    Log.d(TAG, "   File size: ${file.length()} bytes")
                    Log.d(TAG, "   Last modified: ${Date(file.lastModified())}")

                    val content = file.readText()
                    Log.d(TAG, "   Content length: ${content.length} chars")
                    Log.d(TAG, "   Content preview: ${content.take(50)}...")

                    // Different validation for different file types
                    val shouldUpload = when (filename) {
                        "tokens.json" -> {
                            // tokens.json can be smaller, just not empty
                            content.isNotEmpty() && content.trim() != "[]" && content.trim() != "{}"
                        }
                        "movies_cache.json" -> {
                            // Movie files should have substantial content
                            content.isNotEmpty() && content.length > 1000 && !content.trim().endsWith("[]")
                        }
                        else -> {
                            // Channel files should have substantial content
                            content.isNotEmpty() && content.length > 100 && !content.trim().endsWith("[]")
                        }
                    }

                    if (shouldUpload) {
                        Log.d(TAG, "   ✅ $filename has valid data, uploading...")
                        if (uploadSingleFile(file, filename)) {
                            uploadedCount++
                            Log.d(TAG, "   ✅ Uploaded $filename")
                        } else {
                            Log.e(TAG, "   ❌ Failed to upload $filename")
                        }
                    } else {
                        Log.w(TAG, "   ⚠️ Skipping $filename - invalid content")
                        Log.w(TAG, "      Length: ${content.length}")
                        Log.w(TAG, "      Content: '${content.take(30)}...'")
                    }
                } else {
                    Log.w(TAG, "   ⚠️ $filename does not exist locally")
                }
                Log.d(TAG, "---")
            }

            val success = uploadedCount > 0
            Log.d(TAG, "📊 Upload summary: $uploadedCount/${ALL_FILES.size} files ${if (success) "✅" else "❌"}")
            success
        } catch (e: Exception) {
            Log.e(TAG, "❌ Upload error: ${e.message}", e)
            false
        }
    }

    /**
     * Upload single file to GitHub - FIXED TOKENS.JSON VALIDATION
     */
    private fun uploadSingleFile(file: File, filename: String): Boolean {
        return try {
            Log.d(TAG, "   🔄 Starting upload of $filename...")

            val content = file.readText()

            // Special JSON validation for different file types
            when (filename) {
                "tokens.json" -> {
                    // FIXED: Accept multiple tokens.json formats
                    try {
                        val json = JSONObject(content)

                        // Check for different valid formats:
                        val hasValidFormat = when {
                            // Format 1: Has aynaott object with access_token
                            json.has("aynaott") -> {
                                val aynaott = json.getJSONObject("aynaott")
                                aynaott.has("access_token")
                            }
                            // Format 2: Direct access_token at root
                            json.has("access_token") -> true
                            // Format 3: Other valid token structure
                            json.has("token") -> true
                            // No valid format
                            else -> false
                        }

                        if (!hasValidFormat) {
                            Log.e(TAG, "   ❌ tokens.json has invalid format")
                            return false
                        }
                        Log.d(TAG, "   ✅ tokens.json has valid format")
                    } catch (e: Exception) {
                        Log.e(TAG, "   ❌ Invalid tokens.json: ${e.message}")
                        return false
                    }
                }
                "movies_cache.json" -> {
                    // Validate movie JSON
                    try {
                        val type = object : TypeToken<List<com.shimulfp.bdixlivetv.models.Movie>>() {}.type
                        val movies = Gson().fromJson<List<com.shimulfp.bdixlivetv.models.Movie>>(content, type)
                        if (movies.isNullOrEmpty()) {
                            Log.e(TAG, "   ❌ No movies in movies_cache.json")
                            return false
                        }
                        Log.d(TAG, "   ✅ movies_cache.json has ${movies.size} movies")
                    } catch (e: Exception) {
                        Log.e(TAG, "   ❌ Invalid movies JSON: ${e.message}")
                        return false
                    }
                }
                "series_cache.json" -> {
                    // Validate series JSON
                    try {
                        val type = object : TypeToken<List<com.shimulfp.bdixlivetv.models.Series>>() {}.type
                        val series = Gson().fromJson<List<com.shimulfp.bdixlivetv.models.Series>>(content, type)
                        if (series.isNullOrEmpty()) {
                            Log.e(TAG, "   ❌ No series in series_cache.json")
                            return false
                        }
                        Log.d(TAG, "   ✅ series_cache.json has ${series.size} series")
                    } catch (e: Exception) {
                        Log.e(TAG, "   ❌ Invalid series JSON: ${e.message}")
                        return false
                    }
                }
                else -> {
                    // Channel file validation
                    try {
                        val type = object : TypeToken<ChannelCache>() {}.type
                        val cache = Gson().fromJson<ChannelCache>(content, type)
                        if (cache?.channels?.isEmpty() != false) {
                            Log.e(TAG, "   ❌ No channels in $filename")
                            return false
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "   ❌ Invalid JSON in $filename: ${e.message}")
                        return false
                    }
                }
            }

            val base64Content = Base64.encodeToString(content.toByteArray(), Base64.NO_WRAP)

            // Get existing SHA if file exists
            val existingSha = getFileSha(filename)
            Log.d(TAG, "   Existing SHA: ${if (existingSha.isNotEmpty()) "Found" else "Not found"}")

            val json = JSONObject().apply {
                put("message", "Update $filename - ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
                put("content", base64Content)
                if (existingSha.isNotEmpty()) {
                    put("sha", existingSha)
                }
                put("branch", BRANCH)
            }

            val requestBody = json.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("$GITHUB_API_URL/repos/$REPO_OWNER/$REPO_NAME/contents/$CHANNELS_DIR/$filename")
                .header("Authorization", "Bearer $githubToken")
                .put(requestBody)
                .build()

            val response = client.newCall(request).execute()

            if (response.isSuccessful) {
                Log.d(TAG, "   ✅ Upload successful! HTTP ${response.code}")
                return true
            } else {
                Log.e(TAG, "   ❌ Upload failed: HTTP ${response.code}")
                val errorBody = response.body?.string() ?: ""
                Log.e(TAG, "   Error: ${errorBody.take(200)}")
                return false
            }
        } catch (e: Exception) {
            Log.e(TAG, "   ❌ Upload error: ${e.message}", e)
            false
        }
    }

    /**
     * Get existing file SHA from GitHub
     */
    private fun getFileSha(filename: String): String {
        return try {
            val request = Request.Builder()
                .url("$GITHUB_API_URL/repos/$REPO_OWNER/$REPO_NAME/contents/$CHANNELS_DIR/$filename")
                .header("Authorization", "Bearer $githubToken")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "")
                json.optString("sha", "")
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }
    }

    // ============ MOVIE-SPECIFIC METHODS ============

    /**
     * Upload movies to GitHub
     */
    suspend fun uploadMovies(context: Context, movies: List<com.shimulfp.bdixlivetv.models.Movie>): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            if (!::githubToken.isInitialized || githubToken.isEmpty()) {
                Log.e(TAG, "❌ No GitHub token for movie upload")
                return@withContext false
            }

            if (movies.isEmpty()) {
                Log.e(TAG, "❌ No movies to upload")
                return@withContext false
            }

            Log.d(TAG, "🚀 Uploading ${movies.size} movies to GitHub...")

            // Convert movies to JSON
            val json = Gson().toJson(movies)
            val base64Content = Base64.encodeToString(json.toByteArray(), Base64.NO_WRAP)

            // Create/update the file
            val jsonData = JSONObject().apply {
                put("message", "Update movies - ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
                put("content", base64Content)
                val existingSha = getFileSha("movies_cache.json")
                if (existingSha.isNotEmpty()) {
                    put("sha", existingSha)
                }
                put("branch", BRANCH)
            }

            val requestBody = jsonData.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("$GITHUB_API_URL/repos/$REPO_OWNER/$REPO_NAME/contents/$CHANNELS_DIR/movies_cache.json")
                .header("Authorization", "Bearer $githubToken")
                .put(requestBody)
                .build()

            val response = client.newCall(request).execute()

            if (response.isSuccessful) {
                Log.d(TAG, "✅ Successfully uploaded ${movies.size} movies to GitHub")

                // Update sync timestamp
                saveMovieSyncTime(context, System.currentTimeMillis())

                true
            } else {
                Log.e(TAG, "❌ Movie upload failed: HTTP ${response.code}")
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Movie upload error: ${e.message}", e)
            false
        }
    }

    /**
     * Download movies from GitHub - OPTIMIZED VERSION
     */
    suspend fun downloadMovies(context: Context): List<com.shimulfp.bdixlivetv.models.Movie> = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "📥 DOWNLOAD MOVIES: Starting...")

            // Remove any existing stop flags at start
            removeStopFlag(context)

            // Check if file exists on GitHub first
            val fileInfo = getFileInfo("movies_cache.json")
            if (fileInfo == null) {
                Log.d(TAG, "⚠️ No movie data on GitHub")
                return@withContext emptyList()
            }

            // Download the file
            val content = downloadFileContent(fileInfo)
            if (content.isEmpty()) {
                Log.w(TAG, "⚠️ Downloaded empty movie content")
                return@withContext emptyList()
            }

            Log.d(TAG, "📥 DOWNLOAD MOVIES: Content length: ${content.length} chars")

            // Parse movies
            val movies = try {
                val type = object : TypeToken<List<com.shimulfp.bdixlivetv.models.Movie>>() {}.type
                val parsedMovies = Gson().fromJson<List<com.shimulfp.bdixlivetv.models.Movie>>(content, type)
                parsedMovies ?: emptyList()
            } catch (e: Exception) {
                Log.e(TAG, "❌ JSON parsing error: ${e.message}")
                Log.e(TAG, "❌ Error details: ${e.stackTraceToString()}")
                emptyList()
            }

            if (movies.isNotEmpty()) {
                // Create stop flag to signal Python scraper to stop
                createStopFlag(context)

                // Save locally
                val localFile = File(context.filesDir, "movies_cache.json")
                localFile.writeText(content)
                localFile.setLastModified(System.currentTimeMillis())

                Log.d(TAG, "✅ DOWNLOAD MOVIES: Success! Downloaded ${movies.size} movies from GitHub")
                movies
            } else {
                Log.w(TAG, "⚠️ DOWNLOAD MOVIES: Parsed movies list is empty")

                // Try alternative parsing method
                Log.d(TAG, "🔄 Trying alternative parsing method...")
                try {
                    val alternativeMovies = parseMoviesAlternative(content)
                    if (alternativeMovies.isNotEmpty()) {
                        Log.d(TAG, "✅ Alternative parsing successful: ${alternativeMovies.size} movies")
                        // Create stop flag
                        createStopFlag(context)
                        alternativeMovies
                    } else {
                        emptyList()
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "❌ Alternative parsing also failed: ${e.message}")
                    emptyList()
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "❌ MOVIE DOWNLOAD ERROR: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Create stop flag file to signal Python to stop scraping
     */
    private fun createStopFlag(context: Context) {
        try {
            val stopFile = File(context.filesDir, "stop_scraping.flag")
            stopFile.writeText("STOP")
            Log.d(TAG, "🛑 Created stop flag for Python scraper")
        } catch (e: Exception) {
            Log.e(TAG, "Error creating stop flag: ${e.message}")
        }
    }

    /**
     * Remove stop flag file
     */
    private fun removeStopFlag(context: Context) {
        try {
            val stopFile = File(context.filesDir, "stop_scraping.flag")
            if (stopFile.exists()) {
                stopFile.delete()
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    /**
     * Get file info from GitHub
     */
    private suspend fun getFileInfo(filename: String): JSONObject? = withContext(Dispatchers.IO) {
        return@withContext try {
            val request = Request.Builder()
                .url("$GITHUB_API_URL/repos/$REPO_OWNER/$REPO_NAME/contents/$CHANNELS_DIR/$filename")
                .header("Authorization", "Bearer $githubToken")
                .get()
                .build()

            val response = client.newCall(request).execute()

            if (response.isSuccessful) {
                val responseBody = response.body?.string() ?: ""
                JSONObject(responseBody)
            } else if (response.code == 404) {
                null
            } else {
                Log.e(TAG, "❌ Failed to get file info: HTTP ${response.code}")
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting file info: ${e.message}")
            null
        }
    }

    /**
     * Download file content using appropriate method
     */
    private suspend fun downloadFileContent(fileInfo: JSONObject): String = withContext(Dispatchers.IO) {
        return@withContext try {
            val size = fileInfo.optLong("size", 0)
            val content = fileInfo.optString("content", "")
            val downloadUrl = fileInfo.optString("download_url", "")
            val encoding = fileInfo.optString("encoding", "base64")

            val decodedContent: String = if (content.isNotEmpty()) {
                // Small file - content is included directly
                if (encoding == "base64") {
                    String(Base64.decode(content, Base64.DEFAULT))
                } else {
                    content
                }
            } else if (downloadUrl.isNotEmpty()) {
                // Large file - need to download separately
                Log.d(TAG, "📥 Large file detected (${size} bytes), downloading from: $downloadUrl")
                downloadLargeFile(downloadUrl)
            } else {
                Log.e(TAG, "❌ No content or download URL")
                ""
            }

            decodedContent
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error downloading file content: ${e.message}")
            ""
        }
    }

    // ============ SCRIPT DOWNLOAD METHODS ============

    /**
     * PUBLIC: Download a script file from channels_v1 directory
     * Used by SportsService to download Python scripts
     */
    suspend fun downloadScriptFile(filename: String): String = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "📥 Downloading script: $filename")

            val request = Request.Builder()
                .url("$GITHUB_API_URL/repos/$REPO_OWNER/$REPO_NAME/contents/$CHANNELS_DIR/$filename")
                .header("Authorization", "Bearer $githubToken")
                .get()
                .build()

            val response = client.newCall(request).execute()

            if (response.isSuccessful) {
                val responseBody = response.body?.string() ?: ""
                val json = JSONObject(responseBody)

                val content = json.optString("content", "")
                val downloadUrl = json.optString("download_url", "")
                val encoding = json.optString("encoding", "base64")

                val scriptContent: String = if (content.isNotEmpty()) {
                    if (encoding == "base64") {
                        String(Base64.decode(content, Base64.DEFAULT))
                    } else {
                        content
                    }
                } else if (downloadUrl.isNotEmpty()) {
                    downloadLargeFile(downloadUrl)
                } else {
                    ""
                }

                if (scriptContent.isNotEmpty()) {
                    Log.d(TAG, "✅ Downloaded script: $filename (${scriptContent.length} chars)")
                    scriptContent
                } else {
                    Log.e(TAG, "❌ Empty script content for: $filename")
                    ""
                }
            } else if (response.code == 404) {
                Log.e(TAG, "❌ Script not found: $filename (404)")
                ""
            } else {
                Log.e(TAG, "❌ Failed to download script: HTTP ${response.code}")
                ""
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error downloading script $filename: ${e.message}")
            ""
        }
    }

    /**
     * Alternative parsing method
     */
    private fun parseMoviesAlternative(jsonString: String): List<com.shimulfp.bdixlivetv.models.Movie> {
        return try {
            // Try to parse as array directly
            if (jsonString.trim().startsWith("[") && jsonString.trim().endsWith("]")) {
                val type = object : TypeToken<List<com.shimulfp.bdixlivetv.models.Movie>>() {}.type
                Gson().fromJson(jsonString, type) ?: emptyList()
            } else {
                // Try to extract array from JSON object
                val jsonObject = JSONObject(jsonString)
                if (jsonObject.has("movies")) {
                    val moviesArray = jsonObject.getJSONArray("movies")
                    val type = object : TypeToken<List<com.shimulfp.bdixlivetv.models.Movie>>() {}.type
                    Gson().fromJson(moviesArray.toString(), type) ?: emptyList()
                } else {
                    emptyList()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Alternative parsing failed: ${e.message}")
            emptyList()
        }
    }

    /**
     * Save movie sync timestamp
     */
    private fun saveMovieSyncTime(context: Context, timestamp: Long) {
        try {
            val syncFile = File(context.filesDir, "movie_sync_status.json")
            val syncData = JSONObject().apply {
                put("last_sync_time", timestamp)
                put("last_sync_type", "github_upload")
                put("timestamp", System.currentTimeMillis())
            }
            syncFile.writeText(syncData.toString())
            Log.d(TAG, "💾 Saved movie sync time: ${Date(timestamp)}")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving sync time: ${e.message}")
        }
    }

    /**
     * Force upload current movie cache
     */
    suspend fun forceUploadMovies(context: Context, movies: List<com.shimulfp.bdixlivetv.models.Movie>): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "🚀 FORCE UPLOAD MOVIES REQUESTED")
            uploadMovies(context, movies)
        } catch (e: Exception) {
            Log.e(TAG, "❌ Force movie upload error: ${e.message}")
            false
        }
    }

    // ============ SERIES SYNC METHODS ============

    /**
     * Check if GitHub series data is fresh (<2 hours)
     */
    suspend fun isSeriesDataFresh(): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            val seriesFileAge = getSingleFileAge("series_cache.json")

            if (seriesFileAge == -1L) {
                Log.d(TAG, "⚠️ No series data on GitHub")
                return@withContext false
            }

            val isFresh = seriesFileAge <= SyncConfig.SERIES_FRESHNESS_THRESHOLD_MINUTES

            Log.d(TAG, "📊 Series data age: ${seriesFileAge}m (fresh: $isFresh, threshold: ${SyncConfig.SERIES_FRESHNESS_THRESHOLD_MINUTES}m)")
            isFresh
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error checking series data freshness: ${e.message}")
            false
        }
    }

    /**
     * Get GitHub series data age in minutes
     */
    suspend fun getSeriesDataAge(): Long = withContext(Dispatchers.IO) {
        return@withContext try {
            getSingleFileAge("series_cache.json")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting series data age: ${e.message}")
            -1L
        }
    }

    /**
     * Get local series cache age in minutes
     */
    fun getLocalSeriesCacheAge(context: Context): Long {
        return try {
            val file = File(context.filesDir, "series_cache.json")
            if (file.exists()) {
                val ageMinutes = (System.currentTimeMillis() - file.lastModified()) / (60 * 1000)
                ageMinutes
            } else {
                -1L // File doesn't exist
            }
        } catch (e: Exception) {
            -1L
        }
    }

    /**
     * Upload series to GitHub
     */
    suspend fun uploadSeries(context: Context, series: List<com.shimulfp.bdixlivetv.models.Series>): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            if (!::githubToken.isInitialized || githubToken.isEmpty()) {
                Log.e(TAG, "❌ No GitHub token for series upload")
                return@withContext false
            }

            if (series.isEmpty()) {
                Log.e(TAG, "❌ No series to upload")
                return@withContext false
            }

            Log.d(TAG, "🚀 Uploading ${series.size} series to GitHub...")

            // Convert series to JSON
            val json = Gson().toJson(series)
            val base64Content = Base64.encodeToString(json.toByteArray(), Base64.NO_WRAP)

            // Create/update the file
            val jsonData = JSONObject().apply {
                put("message", "Update series - ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
                put("content", base64Content)
                val existingSha = getFileSha("series_cache.json")
                if (existingSha.isNotEmpty()) {
                    put("sha", existingSha)
                }
                put("branch", BRANCH)
            }

            val requestBody = jsonData.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("$GITHUB_API_URL/repos/$REPO_OWNER/$REPO_NAME/contents/$CHANNELS_DIR/series_cache.json")
                .header("Authorization", "Bearer $githubToken")
                .put(requestBody)
                .build()

            val response = client.newCall(request).execute()

            if (response.isSuccessful) {
                Log.d(TAG, "✅ Successfully uploaded ${series.size} series to GitHub")

                // Update sync timestamp
                saveSeriesSyncTime(context, System.currentTimeMillis())

                true
            } else {
                Log.e(TAG, "❌ Series upload failed: HTTP ${response.code}")
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Series upload error: ${e.message}", e)
            false
        }
    }

    /**
     * Download series from GitHub
     */
    suspend fun downloadSeries(context: Context): List<com.shimulfp.bdixlivetv.models.Series> = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "📥 DOWNLOAD SERIES: Starting...")

            // Remove any existing stop flags at start
            removeStopFlag(context)

            // Check if file exists on GitHub first
            val fileInfo = getFileInfo("series_cache.json")
            if (fileInfo == null) {
                Log.d(TAG, "⚠️ No series data on GitHub")
                return@withContext emptyList()
            }

            // Download the file
            val content = downloadFileContent(fileInfo)
            if (content.isEmpty()) {
                Log.w(TAG, "⚠️ Downloaded empty series content")
                return@withContext emptyList()
            }

            Log.d(TAG, "📥 DOWNLOAD SERIES: Content length: ${content.length} chars")

            // Parse series
            val series = try {
                val type = object : TypeToken<List<com.shimulfp.bdixlivetv.models.Series>>() {}.type
                val parsedSeries = Gson().fromJson<List<com.shimulfp.bdixlivetv.models.Series>>(content, type)
                parsedSeries ?: emptyList()
            } catch (e: Exception) {
                Log.e(TAG, "❌ JSON parsing error: ${e.message}")
                Log.e(TAG, "❌ Error details: ${e.stackTraceToString()}")
                emptyList()
            }

            if (series.isNotEmpty()) {
                // Create stop flag to signal Python scraper to stop
                createStopFlag(context)

                // Save locally
                val localFile = File(context.filesDir, "series_cache.json")
                localFile.writeText(content)
                localFile.setLastModified(System.currentTimeMillis())

                Log.d(TAG, "✅ Downloaded ${series.size} series from GitHub")
            } else {
                Log.w(TAG, "⚠️ No series found in downloaded content")
            }

            series
        } catch (e: Exception) {
            Log.e(TAG, "❌ Series download error: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Download backup channels from GitHub (for fast initial load)
     * Downloads backup_channels.json and saves locally
     */
    suspend fun downloadBackupChannels(context: Context): List<Channel> = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "📥 DOWNLOAD BACKUP CHANNELS: Starting...")

            // Remove any existing stop flags at start
            removeStopFlag(context)

            // Check if backup_channels.json exists on GitHub
            val fileInfo = getFileInfo("backup_channels.json")
            if (fileInfo == null) {
                Log.d(TAG, "⚠️ No backup channels on GitHub")
                return@withContext emptyList()
            }

            // Download the file
            val content = downloadFileContent(fileInfo)
            if (content.isEmpty()) {
                Log.w(TAG, "⚠️ Downloaded empty backup channels content")
                return@withContext emptyList()
            }

            Log.d(TAG, "📥 DOWNLOAD BACKUP CHANNELS: Content length: ${content.length} chars")

            // Parse channels with type-safe conversion to handle LinkedTreeMap
            val channels = try {
                val type = object : TypeToken<List<*>>() {}.type
                val rawChannels = Gson().fromJson<Any>(content, type)

                // Convert any LinkedTreeMap to Channel objects
                if (rawChannels is List<*>) {
                    @Suppress("UNCHECKED_CAST")
                    val channelList = rawChannels as List<Any>
                    ChannelCacheManager.validateAndConvertChannels(channelList)
                } else {
                    Log.e(TAG, "❌ Unexpected type in backup channels: ${rawChannels?.javaClass?.simpleName}")
                    emptyList()
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Backup channels JSON parsing error: ${e.message}")
                Log.e(TAG, "❌ Error details: ${e.stackTraceToString()}")
                emptyList()
            }

            if (channels.isNotEmpty()) {
                // Save locally with timestamp
                val localFile = File(context.filesDir, "backup_channels_cache.json")
                localFile.writeText(content)
                localFile.setLastModified(System.currentTimeMillis())

                // Save metadata
                val metadata = mapOf(
                    "timestamp" to System.currentTimeMillis(),
                    "channel_count" to channels.size,
                    "download_time" to SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                )
                val metadataFile = File(context.filesDir, "backup_channels_metadata.json")
                metadataFile.writeText(Gson().toJson(metadata))

                Log.d(TAG, "✅ Downloaded ${channels.size} backup channels from GitHub")
            } else {
                Log.w(TAG, "⚠️ No channels found in backup content")
            }

            channels
        } catch (e: Exception) {
            Log.e(TAG, "❌ Backup channels download error: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Force upload series to GitHub
     */
    suspend fun forceUploadSeries(context: Context, series: List<com.shimulfp.bdixlivetv.models.Series>): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "🚀 FORCE UPLOAD SERIES REQUESTED")
            uploadSeries(context, series)
        } catch (e: Exception) {
            Log.e(TAG, "❌ Force series upload error: ${e.message}")
            false
        }
    }

    /**
     * Save series sync time
     */
    private fun saveSeriesSyncTime(context: Context, timestamp: Long) {
        try {
            val prefs = context.getSharedPreferences("series_sync", Context.MODE_PRIVATE)
            prefs.edit().putLong("last_sync", timestamp).apply()
            Log.d(TAG, "💾 Saved series sync time: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(timestamp))}")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving series sync time: ${e.message}")
        }
    }

    // ============ UTILITY METHODS ============

    private fun saveChannelsToFile(context: Context, filename: String, channels: List<Channel>) {
        try {
            val file = File(context.filesDir, filename)
            val cache = ChannelCache(channels, System.currentTimeMillis(),
                filename.replace("_cache.json", ""))

            val json = Gson().toJson(cache)
            file.writeText(json)
            file.setLastModified(System.currentTimeMillis())

            Log.d(TAG, "💾 Saved $filename (${channels.size} channels)")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving $filename: ${e.message}")
        }
    }

    /**
     * Force upload current cache
     */
    suspend fun forceUpload(context: Context): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "🚀 FORCE UPLOAD REQUESTED")
            uploadAllFiles(context)
        } catch (e: Exception) {
            Log.e(TAG, "❌ Force upload error: ${e.message}")
            false
        }
    }

    // ============ DATA CLASSES ============

    sealed class SyncResult {
        object NoToken : SyncResult()
        data class Downloaded(val ageMinutes: Long) : SyncResult()
        data class ScrapedAndUploaded(val channelCount: Int) : SyncResult()
        data class ScrapedOnly(val channelCount: Int) : SyncResult()
        object ScrapingFailed : SyncResult()

        // Alternative fix: Use @JvmField to avoid generating getter
        data class Error(@JvmField val message: String) : SyncResult()

        fun getMessage(): String {
            return when (this) {
                is Downloaded -> "Downloaded channels from GitHub (${ageMinutes}m old)"
                is ScrapedAndUploaded -> "Scraped and uploaded $channelCount channels"
                is ScrapedOnly -> "Scraped $channelCount channels"
                is ScrapingFailed -> "Scraping failed"
                is Error -> "Error: ${this.message}"
                NoToken -> "No GitHub token"
            }
        }
    }

    /**
     * Check if we should run background sync based on last sync time
     *
     * @param context The application context
     * @return true if sync should run (last sync > 2 hours ago or never synced), false otherwise
     */
    suspend fun shouldRunSync(context: Context): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "📊 Checking if background sync should run...")

            // Check 1: Do we have a GitHub token?
            if (!::githubToken.isInitialized || githubToken.isEmpty()) {
                Log.d(TAG, "⚠️ No GitHub token available, skipping sync")
                return@withContext false
            }

            // Check 2: Look for sync log file
            val syncLogFile = File(context.filesDir, "github_sync_log.json")

            // If no sync log exists, we've never synced - should sync
            if (!syncLogFile.exists()) {
                Log.d(TAG, "📊 No sync log found - first time sync needed")
                return@withContext true
            }

            // Check 3: Read the sync log to see when we last synced
            val lastSyncTime = try {
                val logContent = syncLogFile.readText()
                if (logContent.isBlank()) {
                    0L
                } else {
                    val json = JSONObject(logContent)
                    val time = json.optLong("last_sync_time", 0)
                    Log.d(TAG, "📊 Found last sync time: $time")
                    time
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error reading sync log: ${e.message}")
                0L // If error, assume never synced
            }

            // If we've never synced before, should sync
            if (lastSyncTime == 0L) {
                Log.d(TAG, "📊 Never synced before - should sync")
                return@withContext true
            }

            // Check 4: Calculate how many minutes since last sync
            val minutesSinceLastSync = (System.currentTimeMillis() - lastSyncTime) / (1000 * 60)
            Log.d(TAG, "📊 Minutes since last sync: $minutesSinceLastSync")

            // Sync if it's been more than the configured threshold
            val shouldSync = minutesSinceLastSync > SyncConfig.MAX_CHANNEL_CACHE_AGE_MINUTES

            Log.d(TAG, "📊 Should run sync: $shouldSync")
            shouldSync

        } catch (e: Exception) {
            Log.e(TAG, "❌ Error in shouldRunSync: ${e.message}", e)
            false // On error, don't sync
        }
    }

    /**
     * Save sync log after successful background sync
     * This helps track when we last synced and what happened
     *
     * @param context The application context
     * @param result The sync result to log
     */
    private fun saveSyncLog(context: Context, result: SyncResult) {
        try {
            Log.d(TAG, "💾 Saving sync log...")

            val syncLogFile = File(context.filesDir, "github_sync_log.json")

            // Create JSON object with sync details
            val syncData = JSONObject().apply {
                put("last_sync_time", System.currentTimeMillis())
                put("timestamp", System.currentTimeMillis())
                put("last_sync_date", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))

                // Save result type
                val resultType = when (result) {
                    is SyncResult.Downloaded -> "downloaded"
                    is SyncResult.ScrapedAndUploaded -> "scraped_and_uploaded"
                    is SyncResult.ScrapedOnly -> "scraped_only"
                    is SyncResult.ScrapingFailed -> "scraping_failed"
                    is SyncResult.Error -> "error"
                    is SyncResult.NoToken -> "no_token"
                    else -> "unknown"
                }
                put("last_sync_result", resultType)

                // Add extra info based on result
                when (result) {
                    is SyncResult.Downloaded -> {
                        put("age_minutes", result.ageMinutes)
                        put("message", "Downloaded fresh data from GitHub")
                    }
                    is SyncResult.ScrapedAndUploaded -> {
                        put("channel_count", result.channelCount)
                        put("message", "Scraped fresh data and uploaded to GitHub")
                    }
                    is SyncResult.ScrapedOnly -> {
                        put("channel_count", result.channelCount)
                        put("message", "Scraped fresh data (upload failed)")
                    }
                    is SyncResult.Error -> {
                        put("error_message", result.message)
                        put("message", "Error during sync")
                    }
                    is SyncResult.NoToken -> {
                        put("message", "No GitHub token available")
                    }
                    else -> {
                        put("message", "Unknown sync result")
                    }
                }
            }

            // Save to file
            syncLogFile.writeText(syncData.toString())
            Log.d(TAG, "✅ Sync log saved successfully")
            Log.d(TAG, "📄 Sync log content: ${syncData.toString()}")

        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving sync log: ${e.message}", e)
        }
    }
}
package com.shimulfp.bdixlivetv

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ChannelViewModel : ViewModel() {
    private val _channels = MutableStateFlow<List<Channel>>(emptyList())
    val channels: StateFlow<List<Channel>> = _channels

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing

    fun updateChannels(newChannels: List<Channel>) {
        _channels.value = newChannels
    }

    fun startRefresh() {
        _isRefreshing.value = true
    }

    fun finishRefresh() {
        _isRefreshing.value = false
    }
}
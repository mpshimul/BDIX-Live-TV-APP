package com.shimulfp.bdixlivetv

import android.content.Context
import android.content.SharedPreferences
import android.util.Log

/**
 * BackgroundSyncSettings - Manages background sync preferences
 *
 * Allows users to:
 * - Enable/disable background sync
 * - Set custom sync intervals
 * - Configure sync behavior
 */
object BackgroundSyncSettings {
    private const val TAG = "BackgroundSyncSettings"
    private const val PREFS_NAME = "background_sync_settings"

    // Preference keys
    private const val KEY_ENABLED = "background_sync_enabled"
    private const val KEY_INTERVAL_MINUTES = "sync_interval_minutes"
    private const val KEY_SYNC_CHANNELS = "sync_channels"
    private const val KEY_SYNC_MOVIES = "sync_movies"
    private const val KEY_SYNC_SERIES = "sync_series"
    private const val KEY_ONLY_ON_WIFI = "only_on_wifi"
    private const val KEY_ONLY_WHILE_CHARGING = "only_while_charging"

    // Default values
    private const val DEFAULT_ENABLED = true
    private const val DEFAULT_INTERVAL_MINUTES = 60L
    private const val DEFAULT_SYNC_CHANNELS = true
    private const val DEFAULT_SYNC_MOVIES = true
    private const val DEFAULT_SYNC_SERIES = true
    private const val DEFAULT_ONLY_ON_WIFI = false
    private const val DEFAULT_ONLY_WHILE_CHARGING = false

    /**
     * Get SharedPreferences instance
     */
    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    // ========== ENABLE/DISABLE ==========

    /**
     * Check if background sync is enabled
     */
    fun isEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_ENABLED, DEFAULT_ENABLED)
    }

    /**
     * Enable or disable background sync
     */
    fun setEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()

        if (enabled) {
            Log.d(TAG, "✅ Background sync enabled")
            BackgroundSyncManager.scheduleBackgroundSync(context, getSyncIntervalMinutes(context))
        } else {
            Log.d(TAG, "🛑 Background sync disabled")
            BackgroundSyncManager.cancelBackgroundSync(context)
        }
    }

    // ========== SYNC INTERVAL ==========

    /**
     * Get sync interval in minutes
     */
    fun getSyncIntervalMinutes(context: Context): Long {
        return getPrefs(context).getLong(KEY_INTERVAL_MINUTES, DEFAULT_INTERVAL_MINUTES)
    }

    /**
     * Set sync interval in minutes
     * Minimum: 15 minutes
     * Maximum: 1440 minutes (24 hours)
     */
    fun setSyncIntervalMinutes(context: Context, minutes: Long) {
        val validMinutes = minutes.coerceIn(15L, 1440L)
        getPrefs(context).edit().putLong(KEY_INTERVAL_MINUTES, validMinutes).apply()

        Log.d(TAG, "⏱ Sync interval updated: ${validMinutes} minutes")

        // Reschedule with new interval
        if (isEnabled(context)) {
            BackgroundSyncManager.updateSyncInterval(context, validMinutes)
        }
    }

    // ========== SYNC CONTENT TYPES ==========

    /**
     * Check if channels should be synced
     */
    fun shouldSyncChannels(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_SYNC_CHANNELS, DEFAULT_SYNC_CHANNELS)
    }

    /**
     * Enable/disable channel sync
     */
    fun setSyncChannels(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_SYNC_CHANNELS, enabled).apply()
        Log.d(TAG, "📺 Channel sync: ${if (enabled) "enabled" else "disabled"}")
    }

    /**
     * Check if movies should be synced
     */
    fun shouldSyncMovies(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_SYNC_MOVIES, DEFAULT_SYNC_MOVIES)
    }

    /**
     * Enable/disable movie sync
     */
    fun setSyncMovies(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_SYNC_MOVIES, enabled).apply()
        Log.d(TAG, "🎬 Movie sync: ${if (enabled) "enabled" else "disabled"}")
    }

    /**
     * Check if series should be synced
     */
    fun shouldSyncSeries(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_SYNC_SERIES, DEFAULT_SYNC_SERIES)
    }

    /**
     * Enable/disable series sync
     */
    fun setSyncSeries(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_SYNC_SERIES, enabled).apply()
        Log.d(TAG, "📺 Series sync: ${if (enabled) "enabled" else "disabled"}")
    }

    // ========== NETWORK & POWER CONSTRAINTS ==========

    /**
     * Check if sync should only run on WiFi
     */
    fun onlyOnWifi(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_ONLY_ON_WIFI, DEFAULT_ONLY_ON_WIFI)
    }

    /**
     * Set whether sync should only run on WiFi
     */
    fun setOnlyOnWifi(context: Context, onlyWifi: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_ONLY_ON_WIFI, onlyWifi).apply()
        Log.d(TAG, "📶 WiFi-only mode: ${if (onlyWifi) "enabled" else "disabled"}")
    }

    /**
     * Check if sync should only run while charging
     */
    fun onlyWhileCharging(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_ONLY_WHILE_CHARGING, DEFAULT_ONLY_WHILE_CHARGING)
    }

    /**
     * Set whether sync should only run while charging
     */
    fun setOnlyWhileCharging(context: Context, onlyCharging: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_ONLY_WHILE_CHARGING, onlyCharging).apply()
        Log.d(TAG, "🔌 Charging-only mode: ${if (onlyCharging) "enabled" else "disabled"}")
    }

    // ========== RESET TO DEFAULTS ==========

    /**
     * Reset all settings to defaults
     */
    fun resetToDefaults(context: Context) {
        getPrefs(context).edit().clear().apply()
        Log.d(TAG, "🔄 Background sync settings reset to defaults")

        // Reschedule with default settings
        if (DEFAULT_ENABLED) {
            BackgroundSyncManager.scheduleBackgroundSync(context, DEFAULT_INTERVAL_MINUTES)
        }
    }

    // ========== SUMMARY ==========

    /**
     * Get a summary of current settings
     */
    fun getSettingsSummary(context: Context): String {
        return """
            Background Sync Settings:
            - Enabled: ${isEnabled(context)}
            - Interval: ${getSyncIntervalMinutes(context)} minutes
            - Sync Channels: ${shouldSyncChannels(context)}
            - Sync Movies: ${shouldSyncMovies(context)}
            - Sync Series: ${shouldSyncSeries(context)}
            - WiFi Only: ${onlyOnWifi(context)}
            - Charging Only: ${onlyWhileCharging(context)}
        """.trimIndent()
    }
}

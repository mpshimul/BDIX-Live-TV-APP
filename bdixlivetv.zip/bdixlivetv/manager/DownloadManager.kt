package com.shimulfp.bdixlivetv.manager

import android.annotation.SuppressLint
import android.app.DownloadManager as SystemDownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.models.MovieDownload
import com.shimulfp.bdixlivetv.models.StreamUrl
import com.shimulfp.bdixlivetv.models.DownloadStatus
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Manages movie downloads using Android's DownloadManager
 * Supports concurrent downloads, pause/resume, progress tracking
 */
class DownloadManager private constructor(
    private val context: Context
) {
    companion object {
        private const val TAG = "DownloadManager"
        private const val PREFS_NAME = "movie_downloads"
        private const val KEY_DOWNLOADS = "active_downloads"

        @Volatile
        private var instance: DownloadManager? = null

        fun getInstance(context: Context): DownloadManager {
            return instance ?: synchronized(this) {
                instance ?: DownloadManager(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }

    private val systemDownloadManager: SystemDownloadManager =
        context.getSystemService(Context.DOWNLOAD_SERVICE) as SystemDownloadManager

    // Active downloads map (downloadId -> MovieDownload)
    private val activeDownloads = mutableMapOf<String, MovieDownload>()

    // System download ID mapping
    private val systemDownloadIds = mutableMapOf<String, Long>()

    // State flow for UI to observe
    private val _downloadsState = MutableStateFlow<List<MovieDownload>>(emptyList())
    val downloadsState: StateFlow<List<MovieDownload>> = _downloadsState

    // Coroutine scope for download operations
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // Download directory
    private val downloadsDir: File =
        File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "BDIX_Movies")

    init {
        Log.d(TAG, "🚀 DownloadManager initialized")
        ensureDownloadsDirectory()
        loadSavedDownloads()
        registerDownloadReceiver()
        startProgressTracking()
    }

    /**
     * Ensure downloads directory exists
     */
    private fun ensureDownloadsDirectory() {
        if (!downloadsDir.exists()) {
            downloadsDir.mkdirs()
            Log.d(TAG, "✅ Created downloads directory: ${downloadsDir.absolutePath}")
        }
    }

    /**
     * Start a new download
     */
    suspend fun startDownload(movie: Movie, streamUrl: StreamUrl, qualityIndex: Int) {
        val download = MovieDownload.fromMovie(movie, streamUrl, qualityIndex)

        Log.d(TAG, "🎬 Starting download: ${download.title} (${download.quality})")

        // Check if already downloading OR completed
        activeDownloads[download.id]?.let { existingDownload ->
            when (existingDownload.status) {
                DownloadStatus.COMPLETED -> {
                    Log.d(TAG, "⚠️ Download already completed: ${download.id}")
                    return
                }
                DownloadStatus.DOWNLOADING, DownloadStatus.PAUSED -> {
                    Log.d(TAG, "⚠️ Download already in progress: ${download.id}")
                    return
                }
                else -> {
                    // Allow re-downloading for failed, pending, or cancelled downloads
                    Log.d(TAG, "🔄 Re-downloading: ${download.id} (previous status: ${existingDownload.status})")
                }
            }
        }

        // Add to active downloads
        activeDownloads[download.id] = download
        updateDownloadsState()
        saveDownloads()

        // Create download request
        val request = createDownloadRequest(download)

        // Enqueue download
        try {
            val downloadId = systemDownloadManager.enqueue(request)
            Log.d(TAG, "✅ Download enqueued: $downloadId")

            // Store mapping
            systemDownloadIds[download.id] = downloadId

            // Update download status
            activeDownloads[download.id]?.let { currentDownload ->
                activeDownloads[download.id] = currentDownload.copy(
                    status = DownloadStatus.DOWNLOADING
                )
            }
            updateDownloadsState()
            saveDownloads()
        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to start download: ${e.message}", e)
            // Mark as failed
            activeDownloads[download.id]?.let { currentDownload ->
                activeDownloads[download.id] = currentDownload.copy(
                    status = DownloadStatus.FAILED,
                    error = e.message
                )
            }
            updateDownloadsState()
        }
    }

    /**
     * Create a DownloadManager.Request for a given download
     */
    private fun createDownloadRequest(download: MovieDownload): SystemDownloadManager.Request {
        val request = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            SystemDownloadManager.Request(Uri.parse(download.url))
        } else {
            @Suppress("DEPRECATION")
            SystemDownloadManager.Request(Uri.parse(download.url))
        }

        // Set request title
        request.setTitle(download.title)

        // Set request description
        request.setDescription("Downloading ${download.title} - ${download.quality}")

        // Set notification title (visible in status bar)
        request.setNotificationVisibility(SystemDownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)

        // Set destination directory
        request.setDestinationInExternalFilesDir(
            context,
            Environment.DIRECTORY_MOVIES,
            "BDIX_Movies/${download.fileName}"
        )

        // Set allowed network types
        request.setAllowedNetworkTypes(
            SystemDownloadManager.Request.NETWORK_WIFI or SystemDownloadManager.Request.NETWORK_MOBILE
        )

        return request
    }

    /**
     * Pause a download
     */
    suspend fun pauseDownload(downloadId: String) {
        val download = activeDownloads[downloadId] ?: return

        if (download.status != DownloadStatus.DOWNLOADING) {
            Log.d(TAG, "⚠️ Cannot pause download: ${download.status}")
            return
        }

        Log.d(TAG, "⏸️ Pausing download: ${download.title}")

        // Android DownloadManager doesn't support pause directly
        // We'll cancel and mark as paused
        try {
            val systemId = systemDownloadIds[downloadId]
            if (systemId != null) {
                systemDownloadManager.remove(systemId)
                systemDownloadIds.remove(downloadId)
            }
            activeDownloads[downloadId] = download.copy(
                status = DownloadStatus.PAUSED
            )
            updateDownloadsState()
            saveDownloads()
            Log.d(TAG, "✅ Download paused")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to pause download: ${e.message}", e)
        }
    }

    /**
     * Resume a paused download
     */
    suspend fun resumeDownload(downloadId: String, movie: Movie, streamUrl: StreamUrl, qualityIndex: Int) {
        val download = activeDownloads[downloadId] ?: return

        if (!download.canResume()) {
            Log.d(TAG, "⚠️ Cannot resume download")
            return
        }

        Log.d(TAG, "▶️ Resuming download: ${download.title}")

        // Cancel old download and start new one
        try {
            val systemId = systemDownloadIds[downloadId]
            if (systemId != null) {
                systemDownloadManager.remove(systemId)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error removing old download: ${e.message}")
        }

        // Start fresh download
        activeDownloads[downloadId] = download.copy(
            status = DownloadStatus.DOWNLOADING,
            progress = 0,
            error = null
        )
        updateDownloadsState()
        saveDownloads()

        val request = createDownloadRequest(download)
        try {
            val newDownloadId = systemDownloadManager.enqueue(request)
            systemDownloadIds[downloadId] = newDownloadId
            Log.d(TAG, "✅ Download resumed: $newDownloadId")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to resume download: ${e.message}", e)
            activeDownloads[downloadId] = download.copy(
                status = DownloadStatus.FAILED,
                error = e.message
            )
            updateDownloadsState()
        }
    }

    /**
     * Cancel a download
     */
    suspend fun cancelDownload(downloadId: String) {
        val download = activeDownloads[downloadId] ?: return

        if (!download.canCancel()) {
            Log.d(TAG, "⚠️ Cannot cancel download")
            return
        }

        Log.d(TAG, "❌ Cancelling download: ${download.title}")

        try {
            val systemId = systemDownloadIds[downloadId]
            if (systemId != null) {
                systemDownloadManager.remove(systemId)
                systemDownloadIds.remove(downloadId)
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to cancel download: ${e.message}", e)
        }

        activeDownloads[downloadId] = download.copy(
            status = DownloadStatus.CANCELLED
        )
        updateDownloadsState()
        saveDownloads()
        Log.d(TAG, "✅ Download cancelled")
    }

    /**
     * Delete a downloaded file
     */
    suspend fun deleteDownload(downloadId: String) {
        val download = activeDownloads[downloadId] ?: return

        Log.d(TAG, "🗑️ Deleting download: ${download.title}")

        // Delete file if exists
        download.filePath?.let { path ->
            val file = File(path)
            if (file.exists()) {
                file.delete()
                Log.d(TAG, "✅ File deleted: $path")
            }
        }

        // Remove from active downloads
        activeDownloads.remove(downloadId)
        systemDownloadIds.remove(downloadId)
        updateDownloadsState()
        saveDownloads()
        Log.d(TAG, "✅ Download removed from list")
    }

    /**
     * Retry a failed download
     */
    suspend fun retryDownload(downloadId: String, movie: Movie, streamUrl: StreamUrl, qualityIndex: Int) {
        val download = activeDownloads[downloadId] ?: return

        if (download.status != DownloadStatus.FAILED) {
            Log.d(TAG, "⚠️ Cannot retry download")
            return
        }

        Log.d(TAG, "🔄 Retrying download: ${download.title}")

        // Reset download state
        activeDownloads[downloadId] = download.copy(
            status = DownloadStatus.DOWNLOADING,
            progress = 0,
            downloadedSize = 0,
            error = null
        )
        updateDownloadsState()
        saveDownloads()

        // Create and enqueue new request
        val request = createDownloadRequest(download)
        try {
            val newDownloadId = systemDownloadManager.enqueue(request)
            systemDownloadIds[downloadId] = newDownloadId
            Log.d(TAG, "✅ Download retry started: $newDownloadId")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to retry download: ${e.message}", e)
            activeDownloads[downloadId] = download.copy(
                status = DownloadStatus.FAILED,
                error = e.message
            )
            updateDownloadsState()
        }
    }

    /**
     * Get download by ID
     */
    fun getDownload(downloadId: String): MovieDownload? {
        return activeDownloads[downloadId]
    }

    /**
     * Get all active downloads
     */
    fun getAllDownloads(): List<MovieDownload> {
        return activeDownloads.values.toList().sortedByDescending { it.createdAt }
    }

    /**
     * Get downloads by status
     */
    fun getDownloadsByStatus(status: DownloadStatus): List<MovieDownload> {
        return activeDownloads.values.filter { it.status == status }
            .sortedByDescending { it.createdAt }
    }

    /**
     * Get download progress percentage
     */
    fun getDownloadProgress(downloadId: String): Int {
        return activeDownloads[downloadId]?.progress ?: 0
    }

    /**
     * Get total downloads count
     */
    fun getDownloadsCount(): Int {
        return activeDownloads.size
    }

    /**
     * Get completed downloads count
     */
    fun getCompletedCount(): Int {
        return activeDownloads.values.count { it.status == DownloadStatus.COMPLETED }
    }

    /**
     * Get failed downloads count
     */
    fun getFailedCount(): Int {
        return activeDownloads.values.count { it.status == DownloadStatus.FAILED }
    }

    /**
     * Get total downloaded size
     */
    fun getTotalDownloadedSize(): Long {
        return activeDownloads.values
            .filter { it.status == DownloadStatus.COMPLETED }
            .sumOf { it.fileSize }
    }

    /**
     * Clear all downloads from list (files are preserved)
     */
    suspend fun clearDownloadHistory() {
        Log.d(TAG, "🗑️ Clearing download history")
        activeDownloads.clear()
        systemDownloadIds.clear()
        updateDownloadsState()
        saveDownloads()
        Log.d(TAG, "✅ Download history cleared")
    }

    /**
     * Clear all downloads AND delete actual files
     */
    suspend fun clearDownloadsWithFiles() {
        Log.d(TAG, "🗑️ Clearing downloads and deleting files")

        // Delete all files first
        activeDownloads.values.forEach { download ->
            download.filePath?.let { path ->
                try {
                    val file = File(path)
                    if (file.exists()) {
                        file.delete()
                        Log.d(TAG, "✅ File deleted: $path")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "❌ Failed to delete file: $path", e)
                }
            }
        }

        // Clear the lists
        activeDownloads.clear()
        systemDownloadIds.clear()
        updateDownloadsState()
        saveDownloads()
        Log.d(TAG, "✅ Downloads and files cleared")
    }

    /**
     * Track download progress periodically
     */
    private fun startProgressTracking() {
        scope.launch {
            while (isActive) {
                delay(1000) // Update every second

                activeDownloads.forEach { (id, download) ->
                    if (download.status == DownloadStatus.DOWNLOADING) {
                        val systemId = systemDownloadIds[id]
                        if (systemId != null) {
                            updateDownloadProgress(id, systemId)
                        }
                    }
                }
            }
        }
    }

    /**
     * Update download progress from system download manager
     */
    @SuppressLint("Range")
    private fun updateDownloadProgress(downloadId: String, systemId: Long) {
        try {
            val query = SystemDownloadManager.Query().setFilterById(systemId)
            val cursor: Cursor = systemDownloadManager.query(query) ?: return

            cursor.use {
                if (it.moveToFirst()) {
                    val statusIndex = it.getColumnIndex(SystemDownloadManager.COLUMN_STATUS)
                    val status = it.getInt(statusIndex)

                    when (status) {
                        SystemDownloadManager.STATUS_RUNNING -> {
                            val bytesDownloadedIndex = it.getColumnIndex(SystemDownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                            val bytesTotalIndex = it.getColumnIndex(SystemDownloadManager.COLUMN_TOTAL_SIZE_BYTES)

                            val bytesDownloaded = it.getLong(bytesDownloadedIndex)
                            val bytesTotal = it.getLong(bytesTotalIndex)

                            if (bytesTotal > 0) {
                                val progress = ((bytesDownloaded * 100) / bytesTotal).toInt()

                                // Check if download is complete (progress >= 99% and bytes match)
                                if (progress >= 99 && bytesDownloaded >= bytesTotal) {
                                    // Mark as complete
                                    val localUriIndex = it.getColumnIndex(SystemDownloadManager.COLUMN_LOCAL_URI)
                                    val localUri = it.getString(localUriIndex)
                                    val localFile = getFilePathFromUri(localUri)

                                    activeDownloads[downloadId]?.let { currentDownload ->
                                        activeDownloads[downloadId] = currentDownload.copy(
                                            status = DownloadStatus.COMPLETED,
                                            progress = 100,
                                            downloadedSize = bytesDownloaded,
                                            fileSize = bytesTotal,
                                            filePath = localFile,
                                            completedAt = System.currentTimeMillis()
                                        )
                                        updateDownloadsState()
                                        saveDownloads()
                                        Log.d(TAG, "✅ Download completed (progress check): ${currentDownload.title}")
                                    }
                                } else {
                                    activeDownloads[downloadId]?.let { currentDownload ->
                                        activeDownloads[downloadId] = currentDownload.copy(
                                            progress = progress,
                                            downloadedSize = bytesDownloaded,
                                            fileSize = bytesTotal
                                        )
                                        updateDownloadsState()
                                    }
                                }
                            }
                        }
                        SystemDownloadManager.STATUS_SUCCESSFUL -> {
                            // Success is handled by broadcast receiver
                            // But also handle it here as backup
                            val localUriIndex = it.getColumnIndex(SystemDownloadManager.COLUMN_LOCAL_URI)
                            val localUri = it.getString(localUriIndex)
                            val localFile = getFilePathFromUri(localUri)

                            activeDownloads[downloadId]?.let { currentDownload ->
                                if (currentDownload.status != DownloadStatus.COMPLETED) {
                                    activeDownloads[downloadId] = currentDownload.copy(
                                        status = DownloadStatus.COMPLETED,
                                        progress = 100,
                                        filePath = localFile,
                                        completedAt = System.currentTimeMillis()
                                    )
                                    updateDownloadsState()
                                    saveDownloads()
                                    Log.d(TAG, "✅ Download completed (backup): ${currentDownload.title}")
                                }
                            }
                        }
                        SystemDownloadManager.STATUS_FAILED -> {
                            // Failure is handled by broadcast receiver
                            // But also handle it here as backup
                            val reasonIndex = it.getColumnIndex(SystemDownloadManager.COLUMN_REASON)
                            val reason = it.getInt(reasonIndex)

                            activeDownloads[downloadId]?.let { currentDownload ->
                                if (currentDownload.status != DownloadStatus.FAILED) {
                                    activeDownloads[downloadId] = currentDownload.copy(
                                        status = DownloadStatus.FAILED,
                                        error = "Download failed: $reason"
                                    )
                                    updateDownloadsState()
                                    saveDownloads()
                                    Log.d(TAG, "❌ Download failed (backup): ${currentDownload.title}")
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating progress: ${e.message}")
        }
    }

    /**
     * Save downloads to persistent storage
     */
    private fun saveDownloads() {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val jsonArray = JSONArray()

            activeDownloads.values.forEach { download ->
                val jsonObject = JSONObject().apply {
                    put("id", download.id)
                    put("movieId", download.movieId)
                    put("title", download.title)
                    put("url", download.url)
                    put("quality", download.quality)
                    put("poster", download.poster ?: "")
                    put("fileName", download.fileName)
                    put("progress", download.progress)
                    put("status", download.status.name)
                    put("fileSize", download.fileSize)
                    put("downloadedSize", download.downloadedSize)
                    put("filePath", download.filePath ?: "")
                    put("createdAt", download.createdAt)
                    put("completedAt", download.completedAt ?: 0)
                    put("error", download.error ?: "")
                }
                jsonArray.put(jsonObject)
            }

            prefs.edit()
                .putString(KEY_DOWNLOADS, jsonArray.toString())
                .apply()

            Log.d(TAG, "✅ Saved ${activeDownloads.size} downloads to storage")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to save downloads: ${e.message}", e)
        }
    }

    /**
     * Load downloads from persistent storage
     */
    private fun loadSavedDownloads() {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val jsonString = prefs.getString(KEY_DOWNLOADS, null) ?: return

            val jsonArray = JSONArray(jsonString)
            val loadedDownloads = mutableMapOf<String, MovieDownload>()

            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val download = MovieDownload(
                    id = jsonObject.getString("id"),
                    movieId = jsonObject.getString("movieId"),
                    title = jsonObject.getString("title"),
                    url = jsonObject.getString("url"),
                    quality = jsonObject.getInt("quality"),
                    poster = jsonObject.optString("poster", null),
                    fileName = jsonObject.getString("fileName"),
                    progress = jsonObject.getInt("progress"),
                    status = DownloadStatus.valueOf(jsonObject.getString("status")),
                    fileSize = jsonObject.getLong("fileSize"),
                    downloadedSize = jsonObject.getLong("downloadedSize"),
                    filePath = jsonObject.optString("filePath", null),
                    createdAt = jsonObject.getLong("createdAt"),
                    completedAt = if (jsonObject.has("completedAt")) jsonObject.getLong("completedAt") else null,
                    error = jsonObject.optString("error", null)
                )
                loadedDownloads[download.id] = download
            }

            activeDownloads.clear()
            activeDownloads.putAll(loadedDownloads)
            updateDownloadsState()

            Log.d(TAG, "✅ Loaded ${activeDownloads.size} downloads from storage")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to load downloads: ${e.message}", e)
        }
    }

    /**
     * Update downloads state for UI observation
     */
    private fun updateDownloadsState() {
        _downloadsState.value = activeDownloads.values.toList().sortedByDescending { it.createdAt }
    }

    /**
     * Broadcast receiver for download completion
     */
    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != SystemDownloadManager.ACTION_DOWNLOAD_COMPLETE) {
                return
            }

            val systemId = intent.getLongExtra(SystemDownloadManager.EXTRA_DOWNLOAD_ID, -1)

            Log.d(TAG, "📥 Download completed: $systemId")

            // Find our download ID by system ID
            val downloadId = systemDownloadIds.entries.find { it.value == systemId }?.key
                ?: return

            // Get the actual download from activeDownloads
            val download = activeDownloads[downloadId]
                ?: return

            // Get download info from system
            val query = SystemDownloadManager.Query().setFilterById(systemId)
            val cursor = systemDownloadManager.query(query)

            cursor?.use {
                if (it.moveToFirst()) {
                    val statusIndex = it.getColumnIndex(SystemDownloadManager.COLUMN_STATUS)
                    val status = it.getInt(statusIndex)

                    if (status == SystemDownloadManager.STATUS_SUCCESSFUL) {
                        val localUriIndex = it.getColumnIndex(SystemDownloadManager.COLUMN_LOCAL_URI)
                        val localUri = it.getString(localUriIndex)
                        val localFile = getFilePathFromUri(localUri)

                        activeDownloads[downloadId] = download.copy(
                            status = DownloadStatus.COMPLETED,
                            progress = 100,
                            filePath = localFile,
                            completedAt = System.currentTimeMillis()
                        )
                        updateDownloadsState()
                        saveDownloads()
                        Log.d(TAG, "✅ Download marked as completed: ${download.title}")
                    } else if (status == SystemDownloadManager.STATUS_FAILED) {
                        val reasonIndex = it.getColumnIndex(SystemDownloadManager.COLUMN_REASON)
                        val reason = it.getInt(reasonIndex)

                        activeDownloads[downloadId] = download.copy(
                            status = DownloadStatus.FAILED,
                            error = "Download failed: $reason"
                        )
                        updateDownloadsState()
                        saveDownloads()
                        Log.d(TAG, "❌ Download marked as failed: ${download.title}")
                    }
                }
            }
        }
    }

    /**
     * Get file path from URI
     */
    private fun getFilePathFromUri(uri: String?): String? {
        if (uri == null) return null

        return try {
            // Handle content:// URIs
            if (uri.startsWith("content://")) {
                val cursor = context.contentResolver.query(Uri.parse(uri), null, null, null, null)
                cursor?.use {
                    if (it.moveToFirst()) {
                        val pathIndex = it.getColumnIndex("_data")
                        return it.getString(pathIndex)
                    }
                }
            }
            // Handle file:// URIs
            else if (uri.startsWith("file://")) {
                return Uri.parse(uri).path
            }
            null
        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to get file path from URI: ${e.message}", e)
            null
        }
    }

    /**
     * Register download completion receiver
     */
    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    private fun registerDownloadReceiver() {
        val filter = IntentFilter(SystemDownloadManager.ACTION_DOWNLOAD_COMPLETE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(
                downloadReceiver,
                filter,
                Context.RECEIVER_NOT_EXPORTED
            )
        } else {
            context.registerReceiver(downloadReceiver, filter)
        }

        Log.d(TAG, "✅ Download receiver registered")
    }

    /**
     * Unregister download completion receiver
     */
    fun unregisterReceiver() {
        try {
            context.unregisterReceiver(downloadReceiver)
            Log.d(TAG, "✅ Download receiver unregistered")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to unregister receiver: ${e.message}", e)
        }
    }
}

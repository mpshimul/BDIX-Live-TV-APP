package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Log
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

object PythonHelper {
    private const val TAG = "PythonHelper"
    private val isPythonInitialized = AtomicBoolean(false)
    private val initializationLock = Any()

    // List of required Python modules to verify (core modules only)
    private val REQUIRED_MODULES = listOf(
        "sys",
        "json"
    )

    /**
     * Initialize Python with auto-download of scripts
     */
    suspend fun initialize(context: Context): Boolean = withContext(Dispatchers.IO) {
        Log.d(TAG, "🚀 Initializing Python Helper...")

        return@withContext try {
            // Step 1: Ensure scripts are downloaded
            ensureScriptsAvailable(context)

            // Step 2: Start Python
            startPython(context)

            // Step 3: Set up Python environment
            setupPythonEnvironment(context)

            // Step 4: Verify modules (non-critical)
            verifyPythonModules()

            Log.d(TAG, "✅ Python Helper initialized successfully")
            true
        } catch (e: Exception) {
            Log.e(TAG, "❌ Python Helper initialization had issues: ${e.message}", e)
            // Return true anyway to allow fallback functionality
            true
        }
    }

    /**
     * Ensure scripts are available (download if needed)
     */
    private suspend fun ensureScriptsAvailable(context: Context) {
        Log.d(TAG, "🔍 Checking scripts availability...")

        // Auto-download scripts if not available
        if (!PythonScriptsDownloader.scriptsExistLocally(context)) {
            Log.d(TAG, "📥 Scripts not found locally, downloading...")
            PythonScriptsDownloader.initialize(context)
        }

        // Copy fallback scripts from assets as backup
        copyFallbackScripts(context)
    }

    /**
     * Start Python interpreter - FIXED VERSION
     */
    private fun startPython(context: Context) {
        synchronized(initializationLock) {
            if (isPythonInitialized.get()) {
                return
            }

            try {
                if (!Python.isStarted()) {
                    // FIX: Use standard AndroidPlatform constructor
                    Python.start(AndroidPlatform(context.applicationContext))
                    Log.d(TAG, "✅ Python interpreter started")
                } else {
                    Log.d(TAG, "⚠️ Python already started")
                }
                isPythonInitialized.set(true)
            } catch (e: IllegalStateException) {
                if (!Python.isStarted()) {
                    throw e
                }
                Log.d(TAG, "Python already running")
                isPythonInitialized.set(true)
            } catch (e: Exception) {
                Log.e(TAG, "❌ Failed to start Python: ${e.message}")
                throw e
            }
        }
    }

    /**
     * Set up Python environment with scripts directory - FIXED NULL SAFETY
     */
    private fun setupPythonEnvironment(context: Context) {
        try {
            val py = Python.getInstance()
            val sys = py.getModule("sys")

            // Add scripts directory to Python path
            val scriptsDir = PythonScriptsDownloader.getScriptsDir(context)

            // Get current Python path
            val pythonPath = sys["path"]

            // Add our scripts directory if not already there - FIXED NULL SAFETY
            pythonPath?.let { pathObj ->
                try {
                    // Convert to list to check
                    val pathList = mutableListOf<String>()
                    val iterable = pathObj.asIterable()
                    for (item in iterable) {
                        item?.toString()?.let { pathList.add(it) }
                    }

                    if (!pathList.contains(scriptsDir.absolutePath)) {
                        // Add to path using Python's append method
                        pathObj.callAttr("append", scriptsDir.absolutePath)
                        Log.d(TAG, "✅ Added to Python path: ${scriptsDir.absolutePath}")
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "⚠️ Could not check Python path: ${e.message}")
                }
            }

            // Set environment variables safely
            try {
                val os = py.getModule("os")
                // Set environment variable using putenv
                os.callAttr("putenv", "PYTHON_SCRIPTS_DIR", scriptsDir.absolutePath)
                os.callAttr("putenv", "APP_DATA_DIR", context.filesDir.absolutePath)
                Log.d(TAG, "✅ Environment variables set via putenv")
            } catch (e: Exception) {
                Log.w(TAG, "⚠️ Could not set environment variables: ${e.message}")
            }

            Log.d(TAG, "✅ Python environment configured")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error setting up Python environment: ${e.message}")
        }
    }

    /**
     * Verify all required Python modules can be imported - FIXED NULL SAFETY
     */
    private fun verifyPythonModules() {
        try {
            val py = Python.getInstance()

            Log.d(TAG, "🔍 Verifying Python modules...")

            // First check if Python itself is working
            try {
                val sys = py.getModule("sys")
                val version = sys["version"]?.toString() ?: "unknown"
                Log.d(TAG, "✅ Python version: $version")
            } catch (e: Exception) {
                Log.e(TAG, "❌ Could not get Python sys module")
            }

            // Check if json module exists
            try {
                val jsonModule = py.getModule("json")
                Log.d(TAG, "✅ JSON module loaded")
            } catch (e: Exception) {
                Log.e(TAG, "❌ JSON module not found: ${e.message}")
                // Try to load it differently
                try {
                    py.builtins.get("__import__")?.call("json") // FIXED: Safe call
                    Log.d(TAG, "✅ JSON module loaded via __import__")
                } catch (e2: Exception) {
                    Log.e(TAG, "❌ Could not import JSON at all")
                    // Create a minimal json module
                    createMinimalJsonModule(py)
                }
            }

            // Check required modules with better error handling
            REQUIRED_MODULES.forEach { moduleName ->
                try {
                    py.getModule(moduleName)
                    Log.d(TAG, "✅ Module loaded: $moduleName")
                } catch (e: Exception) {
                    Log.e(TAG, "⚠️ Failed to import $moduleName: ${e.message}")
                    // Don't throw exception - continue with what we have
                }
            }

            Log.d(TAG, "✅ Python modules verified (some warnings may exist)")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Module verification had issues: ${e.message}")
            // Don't throw - let the app continue with fallback
        }
    }

    /**
     * Create minimal JSON module if missing
     */
    private fun createMinimalJsonModule(py: Python) {
        try {
            // Create a minimal JSON module if the real one doesn't exist
            val jsonCode = """
                import sys
                
                class MinimalJSON:
                    @staticmethod
                    def dumps(obj):
                        import reprlib
                        return reprlib.repr(obj)
                        
                    @staticmethod  
                    def loads(s):
                        # Very basic parsing - just for fallback
                        if s == "[]":
                            return []
                        if s == "{}":
                            return {}
                        return s
                
                # Create module
                json = MinimalJSON()
            """.trimIndent()

            // Execute the code to create the module - FIXED NULL SAFETY
            py.getModule("builtins").callAttr("exec", jsonCode)
            Log.d(TAG, "📝 Created minimal JSON module")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Could not create minimal JSON module: ${e.message}")
        }
    }

    /**
     * Copy fallback scripts from assets
     */
    private fun copyFallbackScripts(context: Context) {
        try {
            val scriptsDir = PythonScriptsDownloader.getScriptsDir(context)
            if (!scriptsDir.exists()) {
                scriptsDir.mkdirs()
            }

            // List of critical scripts to copy from assets
            val criticalScripts = listOf(
                "aynaott_with_cache.py",
                "bootstrap.py"
            )

            criticalScripts.forEach { scriptName ->
                val targetFile = File(scriptsDir, scriptName)

                // Only copy if file doesn't exist or is empty
                if (!targetFile.exists() || targetFile.length() < 100) {
                    try {
                        val inputStream = context.assets.open(scriptName)
                        FileOutputStream(targetFile).use { output ->
                            inputStream.copyTo(output)
                        }
                        Log.d(TAG, "📦 Copied fallback script: $scriptName")
                    } catch (e: Exception) {
                        Log.w(TAG, "⚠️ Could not copy $scriptName from assets: ${e.message}")
                    }
                }
            }

            // Create __init__.py if missing
            val initFile = File(scriptsDir, "__init__.py")
            if (!initFile.exists() || initFile.length() < 10) {
                initFile.writeText("""
                    # Auto-generated __init__.py for BDIX TV Python scripts
                    # This makes the directory a Python package
                    
                    __version__ = "1.0.0"
                    __author__ = "BDIX TV App"
                    
                    print("[BDIX-TV] Python scripts package loaded")
                    
                    # Import common modules
                    try:
                        import json
                        import os
                        import sys
                        import re
                        from datetime import datetime
                        print(f"[BDIX-TV] Python {sys.version}")
                    except ImportError as e:
                        print(f"[BDIX-TV] Warning: {e}")
                """.trimIndent())
                Log.d(TAG, "📝 Created default __init__.py")
            }

            // Create minimal master_scraper if missing
            val masterScraper = File(scriptsDir, "master_scraper.py")
            if (!masterScraper.exists() || masterScraper.length() < 100) {
                masterScraper.writeText("""
                    import json
                    
                    def get_other_sources_channels():
                        '''Fallback master scraper'''
                        print("[master_scraper] Using fallback scraper")
                        return json.dumps([])
                        
                    if __name__ == "__main__":
                        print(get_other_sources_channels())
                """.trimIndent())
                Log.d(TAG, "📝 Created minimal master_scraper.py")
            }

            // Create minimal individual scrapers if missing
            listOf("ksb_scraper.py", "basnet_scraper.py", "redforce_scraper.py").forEach { scriptName ->
                val scriptFile = File(scriptsDir, scriptName)
                if (!scriptFile.exists() || scriptFile.length() < 100) {
                    scriptFile.writeText("""
                        import json
                        
                        def get_channels():
                            '''Fallback scraper'''
                            print("[${scriptName.replace(".py", "")}] Using fallback")
                            return json.dumps([])
                            
                        if __name__ == "__main__":
                            print(get_channels())
                    """.trimIndent())
                    Log.d(TAG, "📝 Created minimal $scriptName")
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "❌ Error copying fallback scripts: ${e.message}")
        }
    }

    /**
     * Get AynaOTT channels (main function) - FIXED NULL SAFETY
     */
    suspend fun getAynaChannels(
        context: Context,
        username: String,
        password: String,
        forceRefresh: Boolean = false
    ): List<Channel> = withContext(Dispatchers.IO) {
        return@withContext try {
            // Ensure Python is initialized
            initialize(context)

            Log.d(TAG, "🔄 Getting AynaOTT channels...")

            val py = Python.getInstance()
            val aynaModule = py.getModule("aynaott_with_cache")

            val dataDir = context.filesDir.absolutePath
            val result = aynaModule.callAttr(
                "get_channels_with_cache",
                dataDir,
                username,
                password,
                forceRefresh
            )

            val jsonString = result?.toString() ?: ""

            if (jsonString.length < 10 || jsonString == "[]") {
                Log.w(TAG, "⚠️ Empty response from AynaOTT")
                return@withContext emptyList()
            }

            val channels = parseJsonChannels(jsonString)
            Log.d(TAG, "✅ AynaOTT: ${channels.size} channels")

            channels
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting AynaOTT channels: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Get BDIX channels (main function) - FIXED NULL SAFETY
     */
    // Inside PythonHelper.kt – replace getOtherSourcesChannels()

    suspend fun getOtherSourcesChannels(context: Context): List<Channel> = withContext(Dispatchers.IO) {
        return@withContext try {
            // Ensure Python is initialized
            initialize(context)

            Log.d(TAG, "🔄 Getting BDIX channels from master_scraper...")

            val py = Python.getInstance()
            val masterModule = py.getModule("master_scraper")
            val result = masterModule.callAttr("get_other_sources_channels")
            val jsonString = result?.toString() ?: ""

            if (jsonString.isNotEmpty() && jsonString != "[]") {
                val channels = parseJsonChannels(jsonString)
                Log.d(TAG, "✅ Master scraper: ${channels.size} channels")
                channels
            } else {
                Log.w(TAG, "⚠️ Master scraper returned empty result, using fallback")
                getFallbackChannels()
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting BDIX channels: ${e.message}", e)
            getFallbackChannels()
        }
    }

    /**
     * Try individual scrapers as fallback - FIXED NULL SAFETY
     */
    private fun tryIndividualScrapers(py: Python): List<Channel> {
        val allChannels = mutableListOf<Channel>()

        // Try KSB scraper
        try {
            val ksbModule = py.getModule("ksb_scraper")
            val result = ksbModule.callAttr("get_channels")
            result?.let {
                val channels = parseJsonChannels(it.toString())
                allChannels.addAll(channels)
                Log.d(TAG, "✅ KSB: ${channels.size} channels")
            }
        } catch (e: Exception) {
            Log.w(TAG, "⚠️ KSB scraper failed")
        }

        // Try BasNet scraper
        try {
            val basnetModule = py.getModule("basnet_scraper")
            val result = basnetModule.callAttr("get_channels")
            result?.let {
                val channels = parseJsonChannels(it.toString())
                allChannels.addAll(channels)
                Log.d(TAG, "✅ BasNet: ${channels.size} channels")
            }
        } catch (e: Exception) {
            Log.w(TAG, "⚠️ BasNet scraper failed")
        }

        // Try RedForce scraper
        try {
            val redforceModule = py.getModule("redforce_scraper")
            val result = redforceModule.callAttr("get_channels")
            result?.let {
                val channels = parseJsonChannels(it.toString())
                allChannels.addAll(channels)
                Log.d(TAG, "✅ RedForce: ${channels.size} channels")
            }
        } catch (e: Exception) {
            Log.w(TAG, "⚠️ RedForce scraper failed")
        }

        return if (allChannels.isNotEmpty()) {
            allChannels
        } else {
            getFallbackChannels()
        }
    }

    /**
     * Reset Python state
     */
    fun resetPythonState() {
        synchronized(initializationLock) {
            isPythonInitialized.set(false)
            Log.d(TAG, "🔄 Python state reset")
        }
    }

    /**
     * Get scripts status
     */
    suspend fun getScriptsStatus(context: Context): String = withContext(Dispatchers.IO) {
        return@withContext PythonScriptsDownloader.getStatusInfo(context)
    }

    /**
     * Test if Python is working
     */
    suspend fun testPython(context: Context): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            initialize(context)
            val py = Python.getInstance()
            val sys = py.getModule("sys")
            val version = sys["version"]?.toString() ?: "unknown"
            Log.d(TAG, "✅ Python version: $version")
            true
        } catch (e: Exception) {
            Log.e(TAG, "❌ Python test failed: ${e.message}")
            false
        }
    }

    /**
     * Parse JSON channels with URL fixing
     */
    private fun parseJsonChannels(jsonString: String): List<Channel> {
        return try {
            // Fix Unicode escapes in the JSON string
            val fixedJson = jsonString
                .replace("\\u003d", "=")
                .replace("\\u0026", "&")
                .replace("\\u0027", "'")
                .replace("\\u0022", "\"")

            val gson = Gson()
            val type = object : TypeToken<List<Map<String, Any>>>() {}.type
            val channelsList = gson.fromJson<List<Map<String, Any>>>(fixedJson, type)

            val channels = mutableListOf<Channel>()

            channelsList.forEach { map ->
                try {
                    val channel = parseChannelMap(map)
                    if (channel != null) {
                        channels.add(channel)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to parse channel: ${e.message}")
                }
            }

            channels
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing JSON: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Parse a single channel map
     */
    private fun parseChannelMap(map: Map<String, Any>): Channel? {
        return try {
            var name = map["name"]?.toString() ?: "Unknown"
            val urls = mutableListOf<String>()

            when (val urlsObj = map["urls"]) {
                is String -> {
                    var url = urlsObj
                    url = url.replace("\\u003d", "=").replace("\\u0026", "&")
                    if (url.startsWith("http")) urls.add(url)
                }
                is List<*> -> {
                    urlsObj.forEach { urlItem ->
                        when (urlItem) {
                            is String -> {
                                var url = urlItem
                                url = url.replace("\\u003d", "=").replace("\\u0026", "&")
                                if (url.startsWith("http")) urls.add(url)
                            }
                        }
                    }
                }
            }

            var logo = map["logo"]?.toString() ?: ""
            val category = map["category"]?.toString() ?: "General"
            val source = map["source"]?.toString() ?: "unknown"

            Channel(
                name = name.uppercase().trim(),
                urls = urls,
                logo = logo,
                category = category,
                source = source
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing channel map: ${e.message}")
            null
        }
    }

    /**
     * Get fallback channels when scrapers fail
     */
    private fun getFallbackChannels(): List<Channel> {
        return listOf(
            Channel(
                name = "ATN BANGLA",
                urls = listOf("https://owrcovcrpy.gpcdn.net/bpk-tv/1722/output/index.m3u8"),
                logo = "https://i.postimg.cc/BbLck5F4/atn-bangla.jpg",
                category = "Entertainment",
                source = "fallback_bdix"
            ),
            Channel(
                name = "ATN NEWS",
                urls = listOf("https://owrcovcrpy.gpcdn.net/bpk-tv/1706/output/index.m3u8"),
                logo = "https://i.postimg.cc/ZRFCxYdp/atn-news.png",
                category = "Entertainment",
                source = "fallback_bdix"
            ),
            Channel(
                name = "BANGLAVISION",
                urls = listOf("https://owrcovcrpy.gpcdn.net/bpk-tv/1715/output/index.m3u8"),
                logo = "https://i.postimg.cc/PJxGv57P/banglavision.jpg",
                category = "Entertainment",
                source = "fallback_bdix"
            ),
            Channel(
                name = "BTV",
                urls = listOf("https://owrcovcrpy.gpcdn.net/bpk-tv/1709/output/index.m3u8"),
                logo = "https://i.postimg.cc/nzQXt33R/btv.jpg",
                category = "Entertainment",
                source = "fallback_bdix"
            ),
            Channel(
                name = "CHANNEL 24",
                urls = listOf("https://owrcovcrpy.gpcdn.net/bpk-tv/1703/output/index.m3u8"),
                logo = "https://i.postimg.cc/QdqkCSFX/channel-24.png",
                category = "Entertainment",
                source = "fallback_bdix"
            ),
            Channel(
                name = "CHANNEL I",
                urls = listOf("https://owrcovcrpy.gpcdn.net/bpk-tv/1723/output/index.m3u8"),
                logo = "https://i.postimg.cc/4NzjyVPN/channel-i.jpg",
                category = "Entertainment",
                source = "fallback_bdix"
            ),
            Channel(
                name = "DEEPTO TV",
                urls = listOf("https://owrcovcrpy.gpcdn.net/bpk-tv/1711/output/index.m3u8"),
                logo = "https://i.postimg.cc/m2tN6sc9/deepto-tv.jpg",
                category = "Entertainment",
                source = "fallback_bdix"
            ),
            Channel(
                name = "EKATTOR TV",
                urls = listOf("https://owrcovcrpy.gpcdn.net/bpk-tv/1705/output/index.m3u8"),
                logo = "https://i.postimg.cc/jjtWwrG9/ekattor-tv.png",
                category = "Entertainment",
                source = "fallback_bdix"
            ),
            Channel(
                name = "INDEPENDENT TV",
                urls = listOf("https://owrcovcrpy.gpcdn.net/bpk-tv/1704/output/index.m3u8"),
                logo = "https://i.postimg.cc/3rL7TH81/Independent-TV.png",
                category = "Entertainment",
                source = "fallback_bdix"
            ),
            Channel(
                name = "JAMUNA TV",
                urls = listOf("https://owrcovcrpy.gpcdn.net/bpk-tv/1701/output/index.m3u8"),
                logo = "https://i.postimg.cc/dtR7Gh4t/jamuna-tv.png",
                category = "Entertainment",
                source = "fallback_bdix"
            ),
            Channel(
                name = "SOMOY TV",
                urls = listOf("https://owrcovcrpy.gpcdn.net/bpk-tv/1702/output/index.m3u8"),
                logo = "https://i.postimg.cc/HsVVr6FH/somoy-tv.png",
                category = "Entertainment",
                source = "fallback_bdix"
            ),
            Channel(
                name = "NTV",
                urls = listOf("https://owrcovcrpy.gpcdn.net/bpk-tv/1716/output/index.m3u8"),
                logo = "https://i.postimg.cc/xjZDZLjt/ntvbd.jpg",
                category = "Entertainment",
                source = "fallback_bdix"
            )
        )
    }

    /**
     * Debug Python environment
     */
    fun debugPythonEnvironment(context: Context) {
        try {
            val py = Python.getInstance()

            Log.d(TAG, "=== PYTHON DEBUG ===")

            // Check sys module
            val sys = py.getModule("sys")
            Log.d(TAG, "Python version: ${sys["version"]}")

            // Check path
            val path = sys["path"]
            Log.d(TAG, "Python path: $path")

            // Check what modules are available
            Log.d(TAG, "Trying to import json...")
            try {
                val json = py.getModule("json")
                Log.d(TAG, "✅ JSON module: $json")
            } catch (e: Exception) {
                Log.e(TAG, "❌ JSON import failed: ${e.message}")
            }

            // Check our scripts directory
            val scriptsDir = PythonScriptsDownloader.getScriptsDir(context)
            Log.d(TAG, "Scripts dir: $scriptsDir")
            Log.d(TAG, "Scripts dir exists: ${scriptsDir.exists()}")

            if (scriptsDir.exists()) {
                val files = scriptsDir.listFiles()
                Log.d(TAG, "Scripts count: ${files?.size ?: 0}")
                files?.take(5)?.forEach { file ->
                    Log.d(TAG, "  ${file.name}: ${file.length()} bytes")
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "Debug error: ${e.message}")
        }
    }
}
package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * BackgroundSyncManager - Manages background sync scheduling
 *
 * This class handles:
 * - Scheduling periodic background sync work
 * - Managing work constraints (network, charging, etc.)
 * - Updating sync intervals dynamically
 * - Canceling and rescheduling work
 */
object BackgroundSyncManager {
    private const val TAG = "BackgroundSyncManager"

    /**
     * Schedule periodic background sync
     * This should be called when the app starts
     *
     * @param context Application context
     * @param intervalMinutes Sync interval in minutes (default: 60)
     */
    fun scheduleBackgroundSync(context: Context, intervalMinutes: Long = BackgroundSyncWorker.getSyncIntervalMinutes()) {
        try {
            Log.d(TAG, "📅 Scheduling background sync (every ${intervalMinutes} minutes)")

            // Define constraints for the work
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED) // Require network connection
                .setRequiresBatteryNotLow(true) // Don't run when battery is low
                .setRequiresCharging(false) // Can run even when not charging
                .build()

            // Build the periodic work request
            val workRequest = PeriodicWorkRequestBuilder<BackgroundSyncWorker>(
                intervalMinutes, // Repeat interval
                TimeUnit.MINUTES
            )
                .setConstraints(constraints)
                .setInitialDelay(intervalMinutes, TimeUnit.MINUTES) // First run after interval
                .addTag(BackgroundSyncWorker.WORK_NAME)
                .build()

            // Enqueue the work (keep existing work if already scheduled)
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                BackgroundSyncWorker.WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP, // Don't replace if already exists
                workRequest
            )

            Log.d(TAG, "✅ Background sync scheduled successfully")
            Log.d(TAG, "   - Interval: ${intervalMinutes} minutes")
            Log.d(TAG, "   - Flex interval: ${BackgroundSyncWorker.getFlexIntervalMinutes()} minutes")
            Log.d(TAG, "   - Constraints: Network required, battery not low")

        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to schedule background sync: ${e.message}", e)
        }
    }

    /**
     * Update sync interval
     * Cancels existing work and reschedules with new interval
     *
     * @param context Application context
     * @param intervalMinutes New sync interval in minutes
     */
    fun updateSyncInterval(context: Context, intervalMinutes: Long) {
        try {
            Log.d(TAG, "🔄 Updating sync interval to ${intervalMinutes} minutes")

            // Cancel existing work
            cancelBackgroundSync(context)

            // Schedule with new interval
            scheduleBackgroundSync(context, intervalMinutes)

            Log.d(TAG, "✅ Sync interval updated successfully")

        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to update sync interval: ${e.message}", e)
        }
    }

    /**
     * Cancel all background sync work
     *
     * @param context Application context
     */
    fun cancelBackgroundSync(context: Context) {
        try {
            Log.d(TAG, "🛑 Canceling background sync")

            WorkManager.getInstance(context).cancelUniqueWork(BackgroundSyncWorker.WORK_NAME)

            Log.d(TAG, "✅ Background sync canceled")

        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to cancel background sync: ${e.message}", e)
        }
    }

    /**
     * Check if background sync is enabled
     *
     * @param context Application context
     * @return true if background sync is scheduled
     */
    fun isBackgroundSyncEnabled(context: Context): Boolean {
        return try {
            val workInfos = WorkManager.getInstance(context)
                .getWorkInfosByTag(BackgroundSyncWorker.WORK_NAME)
                .get()

            workInfos.isNotEmpty() && workInfos.any { !it.state.isFinished }

        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to check background sync status: ${e.message}", e)
            false
        }
    }

    /**
     * Get next scheduled sync time
     *
     * @param context Application context
     * @return Next run time in milliseconds, or 0 if not scheduled
     */
    fun getNextSyncTime(context: Context): Long {
        return try {
            val workInfos = WorkManager.getInstance(context)
                .getWorkInfosByTag(BackgroundSyncWorker.WORK_NAME)
                .get()

            if (workInfos.isNotEmpty()) {
                val workInfo = workInfos[0]

                // For periodic work, estimate next run time
                // based on the configured interval
                val intervalMillis = BackgroundSyncSettings.getSyncIntervalMinutes(context) * 60 * 1000

                // Simple estimate: current time + interval
                // This is an approximation since WorkManager doesn't expose exact next run time
                val nextRunTime = System.currentTimeMillis() + intervalMillis

                Log.d(TAG, "📅 Next sync scheduled at: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date(nextRunTime))}")
                nextRunTime
            } else {
                0L
            }

        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to get next sync time: ${e.message}", e)
            0L
        }
    }

    /**
     * Trigger an immediate sync (one-time work)
     * Useful for manual refresh or force sync
     *
     * @param context Application context
     */
    fun triggerImmediateSync(context: Context) {
        try {
            Log.d(TAG, "⚡ Triggering immediate sync")

            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true)
                .build()

            val workRequest = androidx.work.OneTimeWorkRequestBuilder<BackgroundSyncWorker>()
                .setConstraints(constraints)
                .addTag("${BackgroundSyncWorker.WORK_NAME}_immediate")
                .build()

            WorkManager.getInstance(context).enqueue(workRequest)

            Log.d(TAG, "✅ Immediate sync triggered")

        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to trigger immediate sync: ${e.message}", e)
        }
    }

    /**
     * Get sync status information
     *
     * @param context Application context
     * @return Pair of (isEnabled, nextRunTimeMillis)
     */
    fun getSyncStatus(context: Context): Pair<Boolean, Long> {
        return Pair(
            isBackgroundSyncEnabled(context),
            getNextSyncTime(context)
        )
    }
}

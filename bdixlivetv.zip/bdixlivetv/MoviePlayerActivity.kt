package com.shimulfp.bdixlivetv

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.util.Rational
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import coil.Coil
import coil.request.ImageRequest
import com.shimulfp.bdixlivetv.data.MovieRepository
import com.shimulfp.bdixlivetv.models.Episode
import com.shimulfp.bdixlivetv.models.StreamUrl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.Runnable
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.concurrent.TimeUnit
import kotlin.math.abs

@UnstableApi
class MoviePlayerActivity : ComponentActivity() {

    private var playerManager: PlayerManager? = null
    private var movieRepository: MovieRepository? = null

    private lateinit var exoPlayerView: PlayerView
    private lateinit var vlcVideoLayout: VLCVideoLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var titleText: TextView
    private lateinit var qualityText: TextView
    private lateinit var timeText: TextView
    private lateinit var durationText: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var controlsContainer: View
    private lateinit var serverButton: Button
    private lateinit var backButton: ImageButton
    private lateinit var playPauseButton: ImageButton
    private lateinit var rewindButton: ImageButton
    private lateinit var forwardButton: ImageButton
    private lateinit var bufferingText: TextView
    private lateinit var codecInfoText: TextView
    private lateinit var pipButton: ImageButton
    private lateinit var playerModeText: TextView
    private lateinit var speedButton: Button
    private lateinit var audioButton: Button

    private lateinit var seekOverlay: FrameLayout
    private lateinit var seekIcon: ImageView
    private lateinit var seekTimeText: TextView
    private lateinit var seekDeltaText: TextView

    private lateinit var gestureOverlay: View
    private lateinit var brightnessSideIndicator: RelativeLayout
    private lateinit var volumeSideIndicator: RelativeLayout
    private lateinit var brightnessIcon: ImageView
    private lateinit var volumeIcon: ImageView
    private lateinit var brightnessText: TextView
    private lateinit var volumeText: TextView
    private lateinit var brightnessBarFill: View
    private lateinit var volumeBarFill: View

    private lateinit var audioManager: AudioManager
    private var maxVolume = 0
    private var currentBrightness = 0.5f
    private val windowManager = WindowManager.LayoutParams()

    private var movieUrl: String = ""
    private var movieTitle: String = ""
    private var movieId: String = ""
    private var movieQuality: String = ""
    private var streamUrls: List<StreamUrl> = emptyList()
    private var currentServerIndex: Int = 0

    // Series/Episode info
    private var isSeries = false
    private var seriesId: String = ""
    private var seriesTitle: String = ""
    private var seriesPosterUrl: String = ""
    private var seasonNumber: Int = 0
    private var episodeNumber: Int = 0
    private var allEpisodes: List<Episode> = emptyList()
    private var currentSeasonEpisodes: List<Episode> = emptyList()
    private var currentEpisodeIndex: Int = 0

    // Watch progress cache for episodes
    private val episodeWatchProgress = mutableMapOf<String, Int>()

    // Next Episode Button (for series)
    private lateinit var nextEpisodeButton: ImageButton

    // Episodes Ribbon
    private lateinit var episodesRibbonContainer: FrameLayout
    private lateinit var episodesRibbonContent: LinearLayout
    private lateinit var episodesList: LinearLayout
    private lateinit var episodesRibbonTitle: TextView
    private lateinit var episodesScrollView: HorizontalScrollView

    // Ribbon state
    private var ribbonExpanded = false
    private var ribbonPeeking = false
    private val RIBBON_PEEK_HEIGHT_DP = 12
    private val RIBBON_FULL_HEIGHT_DP = 140
    private var lastFocusedEpisodeIndex: Int = -1

    private var controlsVisible = true
    private var resumePosition: Long = 0
    private var isUserSeeking = false
    private var isBuffering = false
    private var isSeekable = true
    private var userHidControlsTimestamp = 0L
    private val AUTO_SHOW_CONTROLS_COOLDOWN = 2000L

    // Gesture variables
    private var startX = 0f
    private var startY = 0f
    private var previousX = 0f
    private var previousY = 0f
    private var isBrightnessControl = false
    private var isVolumeControl = false
    private var gestureStartTime = 0L
    private var volumeAccumulator = 0f
    private var displayBrightness = 0.5f
    private var displayVolume = 0.5f
    private val GESTURE_THRESHOLD = 50f
    private val GESTURE_THRESHOLD_RATIO = 1.2f
    private val SENSITIVITY = 0.003f

    private var controlsBounds = android.graphics.Rect()

    private val hideHandler = Handler(Looper.getMainLooper())
    private val updateHandler = Handler(Looper.getMainLooper())
    private val seekOverlayHandler = Handler(Looper.getMainLooper())
    private val seekAccumulatorHandler = Handler(Looper.getMainLooper())

    private var isPipSupported = false
    private var isInPipMode = false
    private var shouldRestorePlayback = true
    private var accumulatedSeekDelta = 0L

    private val hideControlsRunnable = Runnable { hideControls() }
    private val updateProgressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            updateHandler.postDelayed(this, 1000)
        }
    }
    private val hideSeekOverlayRunnable = Runnable { hideSeekOverlay() }
    private val applySeekRunnable = Runnable { applyAccumulatedSeek() }

    companion object {
        private const val TAG = "MoviePlayer"
        private const val HIDE_DELAY = 3000L
        private const val SEEK_INCREMENT = 10000L
        private const val SEEK_OVERLAY_HIDE_DELAY = 1000L
        private const val SEEK_ACCUMULATOR_DELAY = 300L
        private const val PREFS_NAME = "MoviePlayerPrefs"
        private const val PREF_AUTO_PLAY_NEXT = "auto_play_next_episode"
        private const val NEXT_EPISODE_SHOW_TIME_MS = 60000L
    }

    private var autoPlayNextEpisode: Boolean = true
    private var hasShownNextEpisodeButton = false
    private var hasAutoPlayedNext = false
    private var currentPlaybackSpeed: Float = 1.0f
    private val SPEED_OPTIONS = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    private var hasAutoSwitchedToVLC = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        setRealFullscreen()
        setContentView(R.layout.activity_movie_player)

        isPipSupported = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        } else false

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        autoPlayNextEpisode = prefs.getBoolean(PREF_AUTO_PLAY_NEXT, true)

        initViews()
        extractIntentData()
        setupListeners()
        setupFocusDebugging()
        initPlayerManager()

        // Synchronous (blocking) repository initialization – ensures repository is ready immediately
        runBlocking(Dispatchers.IO) {
            movieRepository = MovieRepository.getInstance(this@MoviePlayerActivity)
            Log.d(TAG, "✅ MovieRepository initialized synchronously")
        }

        // Load resume position
        lifecycleScope.launch {
            loadResumePosition()
        }

        loadMovie()

        // Ensure back button saves progress before finishing
        onBackPressedDispatcher.addCallback(this) {
            Log.d(TAG, "onBackPressedDispatcher: saving synchronously")
            runBlocking {
                saveCurrentProgress()
            }
            Log.d(TAG, "onBackPressedDispatcher: save completed, finishing")
            finish()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && isPipSupported) {
            buildPipParams()?.let { params ->
                setPictureInPictureParams(params)
            }
        }
    }

    private fun setRealFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val layoutParams = window.attributes
        val screenBrightness = layoutParams.screenBrightness
        currentBrightness = if (screenBrightness > 0) screenBrightness else getBrightness()
    }

    // ----- Brightness & Volume Helpers -----
    private fun isTouchInControls(x: Float, y: Float): Boolean {
        return controlsBounds.contains(x.toInt(), y.toInt())
    }

    private fun setBrightness(brightness: Float) {
        val layoutParams = window.attributes
        layoutParams.screenBrightness = brightness.coerceIn(0.01f, 1f)
        window.attributes = layoutParams
        currentBrightness = layoutParams.screenBrightness
    }

    private fun getBrightness(): Float {
        val brightness = window.attributes.screenBrightness
        return if (brightness < 0) {
            try {
                Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
            } catch (e: Exception) {
                0.5f
            }
        } else brightness
    }

    private fun initViews() {
        exoPlayerView = findViewById(R.id.movie_player_view)
        vlcVideoLayout = findViewById(R.id.movie_vlc_view)
        progressBar = findViewById(R.id.movie_progress_bar)
        errorText = findViewById(R.id.movie_error_text)
        titleText = findViewById(R.id.movie_title_text)
        qualityText = findViewById(R.id.movie_quality_text)
        timeText = findViewById(R.id.movie_time_text)
        durationText = findViewById(R.id.movie_duration_text)
        seekBar = findViewById(R.id.movie_seek_bar)
        controlsContainer = findViewById(R.id.movie_controls_container)
        serverButton = findViewById(R.id.movie_server_button)
        backButton = findViewById(R.id.movie_back_button)
        playPauseButton = findViewById(R.id.movie_play_pause_button)
        rewindButton = findViewById(R.id.movie_rewind_button)
        forwardButton = findViewById(R.id.movie_forward_button)
        bufferingText = findViewById(R.id.movie_buffering_text)
        codecInfoText = findViewById(R.id.movie_codec_info)
        pipButton = findViewById(R.id.movie_pip_button)
        playerModeText = findViewById(R.id.movie_player_mode_text)
        speedButton = findViewById(R.id.movie_speed_button)
        audioButton = findViewById(R.id.movie_audio_button)

        updateSpeedButtonText()

        seekOverlay = findViewById(R.id.seek_overlay)
        seekIcon = findViewById(R.id.seek_icon)
        seekTimeText = findViewById(R.id.seek_time_text)
        seekDeltaText = findViewById(R.id.seek_delta_text)

        episodesRibbonContainer = findViewById(R.id.episodes_ribbon_container)
        episodesRibbonContent = findViewById(R.id.episodes_ribbon_content)
        episodesList = findViewById(R.id.episodes_list)
        episodesScrollView = findViewById(R.id.episodes_scroll_view)
        episodesRibbonTitle = findViewById(R.id.episodes_ribbon_title)

        nextEpisodeButton = findViewById(R.id.next_episode_button)

        gestureOverlay = findViewById(R.id.gesture_overlay)
        brightnessSideIndicator = findViewById(R.id.brightness_side_indicator)
        volumeSideIndicator = findViewById(R.id.volume_side_indicator)
        brightnessIcon = findViewById(R.id.brightness_side_icon)
        volumeIcon = findViewById(R.id.volume_side_icon)
        brightnessText = findViewById(R.id.brightness_side_text)
        volumeText = findViewById(R.id.volume_side_text)
        brightnessBarFill = findViewById(R.id.brightness_bar_fill)
        volumeBarFill = findViewById(R.id.volume_bar_fill)

        codecInfoText.visibility = View.GONE
        bufferingText.visibility = View.GONE
        playerModeText.visibility = View.GONE
        brightnessSideIndicator.visibility = View.GONE
        volumeSideIndicator.visibility = View.GONE

        nextEpisodeButton.visibility = if (isSeries) View.VISIBLE else View.GONE
        if (!isPipSupported) pipButton.visibility = View.GONE

        playPauseButton.isFocusable = true
        playPauseButton.isClickable = true
        playPauseButton.requestFocus()

        controlsContainer.viewTreeObserver.addOnGlobalLayoutListener(
            object : ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    controlsContainer.getGlobalVisibleRect(controlsBounds)
                    controlsContainer.viewTreeObserver.removeOnGlobalLayoutListener(this)
                }
            }
        )

        updateBrightnessUI()
        updateVolumeUI()
    }

    private fun extractIntentData() {
        movieId = intent.getStringExtra("MOVIE_ID") ?: ""
        movieTitle = intent.getStringExtra("MOVIE_TITLE") ?: "Movie"
        movieUrl = intent.getStringExtra("MOVIE_URL") ?: ""
        movieQuality = intent.getStringExtra("MOVIE_QUALITY") ?: "HD"

        isSeries = intent.getBooleanExtra("IS_SERIES", false)
        seriesId = intent.getStringExtra("SERIES_ID") ?: ""
        seriesTitle = intent.getStringExtra("SERIES_TITLE") ?: ""
        seriesPosterUrl = intent.getStringExtra("SERIES_POSTER") ?: ""
        seasonNumber = intent.getIntExtra("SEASON_NUMBER", 0)
        episodeNumber = intent.getIntExtra("EPISODE_NUMBER", 0)

        Log.d(TAG, "📺 Series Info - isSeries: $isSeries, seriesTitle: $seriesTitle, episodeNumber: $episodeNumber")

        val episodesJson = intent.getStringExtra("ALL_EPISODES")
        if (!episodesJson.isNullOrEmpty() && episodesJson != "null") {
            try {
                val gson = com.google.gson.Gson()
                val listType = object : com.google.gson.reflect.TypeToken<List<Episode>>() {}.type
                allEpisodes = gson.fromJson(episodesJson, listType) ?: emptyList()

                // Filter for current season
                currentSeasonEpisodes = allEpisodes.filter { it.seasonNumber == seasonNumber }

                currentEpisodeIndex = currentSeasonEpisodes.indexOfFirst { it.episodeNumber == episodeNumber }
                if (currentEpisodeIndex < 0) currentEpisodeIndex = 0

                Log.d(TAG, "📋 Episodes loaded: ${allEpisodes.size}, Current season: $seasonNumber, Season episodes: ${currentSeasonEpisodes.size}, Current index: $currentEpisodeIndex")

                if (isSeries) {
                    val currentEpisode = currentSeasonEpisodes.getOrNull(currentEpisodeIndex)
                    if (currentEpisode != null) {
                        titleText.text = "${seriesTitle} - ${currentEpisode.getFormattedName()}"
                        if (currentEpisode.title.isNotEmpty()) {
                            qualityText.text = currentEpisode.title
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error parsing episodes: ${e.message}")
            }
        } else {
            Log.w(TAG, "⚠️ No episodes data found")
        }

        @Suppress("DEPRECATION")
        streamUrls = intent.getParcelableArrayListExtra("STREAM_URLS") ?: emptyList()

        titleText.text = movieTitle
        qualityText.text = movieQuality

        if (streamUrls.isNotEmpty()) {
            currentServerIndex = streamUrls.indexOfFirst { it.url == movieUrl }.takeIf { it >= 0 } ?: 0
            serverButton.text = "Server ${currentServerIndex + 1}/${streamUrls.size}"
            serverButton.visibility = if (streamUrls.size > 1) View.VISIBLE else View.GONE
        } else {
            serverButton.visibility = View.GONE
        }
    }

    private fun setupListeners() {
        backButton.setOnClickListener {
            lifecycleScope.launch {
                saveCurrentProgress()
                finish()
            }
        }

        playPauseButton.setOnClickListener {
            togglePlayPause()
            showControls()
            scheduleHideControls()
        }

        rewindButton.setOnClickListener {
            safeSeekBy(-SEEK_INCREMENT)
            showSeekOverlay(-SEEK_INCREMENT)
            showControls()
            scheduleHideControls()
        }

        forwardButton.setOnClickListener {
            safeSeekBy(SEEK_INCREMENT)
            showSeekOverlay(SEEK_INCREMENT)
            showControls()
            scheduleHideControls()
        }

        nextEpisodeButton.setOnClickListener {
            playEpisodeAtIndex(currentEpisodeIndex + 1)
            showControls()
            scheduleHideControls()
        }

        serverButton.setOnClickListener {
            showServerDialog()
            showControls()
            scheduleHideControls()
        }

        audioButton.setOnClickListener {
            showAudioTrackDialog()
            showControls()
            scheduleHideControls()
        }

        pipButton.setOnClickListener {
            if (isPipSupported) {
                enterPictureInPicture()
            }
            showControls()
            scheduleHideControls()
        }

        speedButton.setOnClickListener {
            showSpeedDialog()
            showControls()
            scheduleHideControls()
        }

        exoPlayerView.setOnClickListener {
            if (!isBrightnessControl && !isVolumeControl) toggleControls()
        }
        vlcVideoLayout.setOnClickListener {
            if (!isBrightnessControl && !isVolumeControl) toggleControls()
        }

        gestureOverlay.isClickable = false
        gestureOverlay.isFocusable = false
        gestureOverlay.isFocusableInTouchMode = false
        gestureOverlay.setOnTouchListener(null)

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val pm = playerManager ?: return
                    val duration = pm.getDuration()
                    if (duration > 0) {
                        val position = (duration * progress) / 100
                        timeText.text = formatTime(position)
                    }
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = true
                cancelHideControls()
                showControls()
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = false
                val pm = playerManager ?: return
                val duration = pm.getDuration()
                if (duration > 0 && isSeekable) {
                    val position = (duration * (seekBar?.progress ?: 0)) / 100
                    pm.seekTo(position)
                }
                scheduleHideControls()
            }
        })

        seekBar.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        safeSeekBy(-1000L)
                        showSeekOverlay(-1000L)
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        safeSeekBy(1000L)
                        showSeekOverlay(1000L)
                        true
                    }
                    else -> false
                }
            } else false
        }
    }

    private fun setupFocusDebugging() {
        val rootView = window.decorView.findViewById<View>(android.R.id.content)
        rootView.viewTreeObserver.addOnGlobalFocusChangeListener { oldFocus, newFocus ->
            Log.d(TAG, "=== FOCUS CHANGED ===")
            Log.d(TAG, "Old focus: ${oldFocus?.javaClass?.simpleName} (ID: ${oldFocus?.id})")
            Log.d(TAG, "New focus: ${newFocus?.javaClass?.simpleName} (ID: ${newFocus?.id})")

            var wasFromRibbon = false
            if (oldFocus != null) {
                for (i in 0 until episodesList.childCount) {
                    if (episodesList.getChildAt(i) == oldFocus) {
                        wasFromRibbon = true
                        break
                    }
                    val parent = oldFocus.parent as? ViewGroup
                    if (parent != null && episodesList.getChildAt(i) == parent) {
                        wasFromRibbon = true
                        break
                    }
                }
            }

            if (wasFromRibbon && newFocus != null) {
                val inControlsContainer = controlsContainer.findViewById<View>(newFocus.id) != null
                val isBackButton = newFocus.id == backButton.id
                val isPipButton = newFocus.id == pipButton.id
                val isInControls = inControlsContainer || isBackButton || isPipButton

                if (isInControls && ribbonPeeking) {
                    Log.d(TAG, "FOCUS MOVED FROM RIBBON TO CONTROLS - HIDING RIBBON")
                    hideEpisodesRibbon()
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleGesture(event: MotionEvent): Boolean {
        val screenWidth = resources.displayMetrics.widthPixels

        if (controlsVisible && isTouchInControls(event.x, event.y)) {
            return false
        }

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                previousX = event.x
                previousY = event.y
                gestureStartTime = System.currentTimeMillis()
                isBrightnessControl = false
                isVolumeControl = false
                volumeAccumulator = 0f
                cancelHideControls()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - startX
                val dy = event.y - startY
                val dragAmountY = event.y - previousY

                previousX = event.x
                previousY = event.y

                if (!isBrightnessControl && !isVolumeControl) {
                    if (abs(dy) > GESTURE_THRESHOLD && abs(dy) > abs(dx) * GESTURE_THRESHOLD_RATIO) {
                        if (startX < screenWidth * 0.35f) {
                            isBrightnessControl = true
                            showBrightnessSideIndicator()
                            displayBrightness = currentBrightness
                        } else if (startX > screenWidth * 0.65f) {
                            isVolumeControl = true
                            showVolumeSideIndicator()
                            val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                            displayVolume = currentVol.toFloat() / maxVolume.toFloat()
                        }
                    }
                }

                if (isBrightnessControl) {
                    val delta = -dragAmountY * SENSITIVITY
                    adjustBrightness(delta)
                }
                if (isVolumeControl) {
                    val delta = -dragAmountY * SENSITIVITY
                    adjustVolume(delta)
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isBrightnessControl || isVolumeControl) {
                    hideSideIndicators()
                    scheduleHideControls()
                    isBrightnessControl = false
                    isVolumeControl = false
                    volumeAccumulator = 0f
                    return true
                } else {
                    val elapsedTime = System.currentTimeMillis() - gestureStartTime
                    val movedDistance = abs(event.x - startX) + abs(event.y - startY)
                    val dy = event.y - startY

                    if (elapsedTime < 300 && movedDistance < 20) {
                        toggleControls()
                    } else if (isSeries && ribbonPeeking) {
                        if (dy < -100 && !ribbonExpanded) {
                            expandEpisodesRibbon()
                        } else if (dy > 100 && ribbonExpanded) {
                            collapseEpisodesRibbon()
                        }
                    }
                }
                return true
            }
        }
        return true
    }

    private fun adjustBrightness(delta: Float) {
        val newBrightness = (displayBrightness + delta).coerceIn(0.01f, 1.0f)
        displayBrightness = newBrightness
        try {
            val layoutParams = window.attributes
            layoutParams.screenBrightness = newBrightness
            window.attributes = layoutParams
            currentBrightness = newBrightness
            updateBrightnessUI()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to adjust brightness", e)
        }
    }

    private fun adjustVolume(delta: Float) {
        volumeAccumulator += delta
        displayVolume = (displayVolume + delta).coerceIn(0f, 1f)
        val stepSize = 1f / maxVolume.toFloat()
        val stepsToChange = (volumeAccumulator / stepSize).toInt()

        if (stepsToChange != 0) {
            val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            val newVolume = (currentVolume + stepsToChange).coerceIn(0, maxVolume)
            if (newVolume != currentVolume) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0)
                updateVolumeUI()
            }
            volumeAccumulator = 0f
        }
    }

    private fun showBrightnessSideIndicator() {
        brightnessSideIndicator.visibility = View.VISIBLE
        updateBrightnessUI()
    }

    private fun showVolumeSideIndicator() {
        volumeSideIndicator.visibility = View.VISIBLE
        updateVolumeUI()
    }

    private fun updateBrightnessUI() {
        val percentage = (currentBrightness * 100).toInt()
        brightnessText.text = "$percentage%"
        val iconRes = when {
            percentage > 66 -> R.drawable.ic_brightness_high
            percentage > 33 -> R.drawable.ic_brightness_medium
            else -> R.drawable.ic_brightness_low
        }
        brightnessIcon.setImageResource(iconRes)
        val barHeight = (percentage / 100f) * resources.getDimension(R.dimen.gesture_bar_max_height)
        val layoutParams = brightnessBarFill.layoutParams
        layoutParams.height = barHeight.toInt()
        brightnessBarFill.layoutParams = layoutParams
    }

    private fun updateVolumeUI() {
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val percentage = (currentVolume * 100 / maxVolume)
        volumeText.text = "$percentage%"
        val iconRes = when {
            currentVolume == 0 -> R.drawable.ic_volume_off
            currentVolume < maxVolume / 3 -> R.drawable.ic_volume_down
            else -> R.drawable.ic_volume_up
        }
        volumeIcon.setImageResource(iconRes)
        val barHeight = (percentage / 100f) * resources.getDimension(R.dimen.gesture_bar_max_height)
        val layoutParams = volumeBarFill.layoutParams
        layoutParams.height = barHeight.toInt()
        volumeBarFill.layoutParams = layoutParams
    }

    private fun hideSideIndicators() {
        brightnessSideIndicator.visibility = View.GONE
        volumeSideIndicator.visibility = View.GONE
    }

    private fun initPlayerManager() {
        playerManager = PlayerManager(
            context = this,
            exoPlayerView = exoPlayerView,
            vlcVideoLayout = vlcVideoLayout,
            listener = object : PlayerManager.PlayerListener {
                override fun onPlayerReady() {
                    progressBar.visibility = View.GONE
                    errorText.visibility = View.GONE
                    updateDuration()
                    updatePlayPauseButton()

                    val pm = playerManager ?: return
                    val playerType = pm.getPlayerType()
                    playerModeText.text = when (playerType) {
                        PlayerManager.PlayerType.EXOPLAYER -> "ExoPlayer"
                        PlayerManager.PlayerType.VLC -> "VLC"
                    }
                    playerModeText.setTextColor(
                        if (playerType == PlayerManager.PlayerType.VLC) 0xFFFF9800.toInt() else 0xFF4CAF50.toInt()
                    )

                    if (resumePosition > 0 && pm.isSeekable() && shouldRestorePlayback) {
                        pm.seekTo(resumePosition)
                        resumePosition = 0
                        Toast.makeText(this@MoviePlayerActivity, "Resuming playback", Toast.LENGTH_SHORT).show()
                    }

                    showCodecInfo()
                    scheduleHideControls()
                }

                override fun onPlayerError(error: String, isFatal: Boolean) {
                    if (isFatal) {
                        progressBar.visibility = View.GONE
                        errorText.visibility = View.VISIBLE
                        errorText.text = error
                        if (streamUrls.size > 1) {
                            errorText.append("\n\nTrying next server...")
                            Handler(Looper.getMainLooper()).postDelayed({ tryNextServer() }, 2000)
                        }
                    } else {
                        Toast.makeText(this@MoviePlayerActivity, error, Toast.LENGTH_LONG).show()
                    }
                }

                override fun onBuffering(isBuffering: Boolean, percentage: Int) {
                    this@MoviePlayerActivity.isBuffering = isBuffering
                    progressBar.visibility = View.GONE
                    bufferingText.visibility = if (isBuffering) View.VISIBLE else View.GONE
                    bufferingText.text = if (isBuffering && percentage > 0) "Buffering... $percentage%" else "Buffering..."
                    if (!isBuffering) scheduleHideControls()
                }

                override fun onPlaybackStateChanged(isPlaying: Boolean) {
                    updatePlayPauseButton()
                    if (isPlaying) {
                        scheduleHideControls()
                    } else {
                        cancelHideControls()
                        val timeSinceUserHidControls = System.currentTimeMillis() - userHidControlsTimestamp
                        if (timeSinceUserHidControls > AUTO_SHOW_CONTROLS_COOLDOWN) {
                            showControls()
                        }
                    }
                }

                override fun onDurationChanged(duration: Long) {
                    updateDuration()
                }

                override fun onPositionChanged(position: Long) { /* handled in updateProgress */ }

                override fun onSeekableChanged(isSeekable: Boolean) {
                    this@MoviePlayerActivity.isSeekable = isSeekable
                    seekBar.isEnabled = isSeekable
                    val pm = playerManager ?: return
                    val duration = pm.getDuration()
                    if (!isSeekable && duration > 0) {
                        Handler(Looper.getMainLooper()).postDelayed({ showNonSeekableDialog() }, 2000)
                    } else if (!isSeekable && duration <= 0) {
                        Toast.makeText(this@MoviePlayerActivity, "Live stream - seeking unavailable", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onTracksChanged() {
                    val pm = playerManager ?: return
                    val audioTracks = pm.getAvailableAudioTracks()
                    audioButton.visibility = if (audioTracks.size > 1) View.VISIBLE else View.GONE
                    audioButton.text = if (audioTracks.size > 1) "Audio (${audioTracks.size})" else "Audio"
                }

                override fun onProblematicCodecDetected(codecInfo: String) {
                    Log.w(TAG, "Problematic codec detected: $codecInfo")
                    val pm = playerManager ?: return
                    if (!hasAutoSwitchedToVLC && pm.getPlayerType() == PlayerManager.PlayerType.EXOPLAYER) {
                        hasAutoSwitchedToVLC = true
                        val currentPos = pm.getCurrentPosition()
                        runOnUiThread {
                            Toast.makeText(
                                this@MoviePlayerActivity,
                                "Auto‑switching to VLC for better audio compatibility",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                        pm.switchToVLC(movieUrl, currentPos, autoSwitch = true)
                    }
                }
            }
        )
    }

    private fun loadMovie(url: String = movieUrl) {
        hasShownNextEpisodeButton = false
        hasAutoPlayedNext = false
        nextEpisodeButton.visibility = View.GONE

        if (url.isEmpty()) {
            errorText.visibility = View.VISIBLE
            errorText.text = "No video URL provided"
            return
        }
        if (playerManager == null) {
            errorText.visibility = View.VISIBLE
            errorText.text = "Player not initialized. Please try again."
            return
        }

        errorText.visibility = View.GONE
        progressBar.visibility = View.VISIBLE
        shouldRestorePlayback = true

        val urlLower = url.lowercase()
        val forceVLC = (urlLower.contains(".mkv") &&
                (urlLower.contains("ac3") || urlLower.contains("dts") ||
                        urlLower.contains("dd5.1") || urlLower.contains("dd+") || urlLower.contains("eac3"))) ||
                urlLower.contains(".avi") || urlLower.contains(".hevc") ||
                urlLower.contains("h265") || urlLower.contains("x265")

        if (forceVLC) {
            Log.d(TAG, "⚠️ Auto-forcing VLC for: $url")
            Toast.makeText(this, "Using VLC player for better format support", Toast.LENGTH_LONG).show()
        }
        playerManager!!.load(url, autoPlay = true, forceVLC = forceVLC)
    }

    private fun showCodecInfo() {
        val pm = playerManager ?: return
        if (pm.getPlayerType() == PlayerManager.PlayerType.EXOPLAYER) {
            pm.getExoPlayer()?.let { p ->
                val videoFormat = p.videoFormat
                val audioFormat = p.audioFormat
                if (videoFormat != null) {
                    val codecInfo = buildString {
                        append("Video: ${videoFormat.sampleMimeType ?: "Unknown"}")
                        append(" ${videoFormat.width}x${videoFormat.height}")
                        if (videoFormat.frameRate > 0) append(" ${videoFormat.frameRate.toInt()}fps")
                        if (audioFormat != null) {
                            append("\nAudio: ${audioFormat.sampleMimeType ?: "Unknown"}")
                            if (audioFormat.channelCount > 0) append(" ${audioFormat.channelCount}ch")
                            if (audioFormat.sampleRate > 0) append(" ${audioFormat.sampleRate}Hz")
                        }
                    }
                    codecInfoText.text = codecInfo
                    codecInfoText.visibility = View.VISIBLE
                    Handler(Looper.getMainLooper()).postDelayed({ codecInfoText.visibility = View.GONE }, 5000)
                }
            }
        } else {
            codecInfoText.text = "VLC Player - All codecs supported"
            codecInfoText.visibility = View.VISIBLE
            Handler(Looper.getMainLooper()).postDelayed({ codecInfoText.visibility = View.GONE }, 3000)
        }
    }

    // ----- Dialogs -----
    private fun showAudioTrackDialog() {
        val pm = playerManager ?: return
        val audioTracks = pm.getAvailableAudioTracks()
        if (audioTracks.isEmpty()) {
            Toast.makeText(this, "No audio tracks available", Toast.LENGTH_SHORT).show()
            return
        }
        if (audioTracks.size == 1) {
            Toast.makeText(this, "Only one audio track available", Toast.LENGTH_SHORT).show()
            return
        }
        val trackLabels = audioTracks.map { track ->
            buildString {
                append(track.label)
                if (track.language.isNotEmpty() && track.language != "und" && track.language != "Unknown") {
                    append(" [${track.language}]")
                }
                if (track.channels > 0 && track.channels != 2) {
                    append(" - ${track.channels}ch")
                }
                if (track.isSelected) {
                    append(" ✓")
                }
            }
        }.toTypedArray()
        val selectedIndex = audioTracks.indexOfFirst { it.isSelected }.takeIf { it >= 0 } ?: 0
        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Select Audio Track")
            .setSingleChoiceItems(trackLabels, selectedIndex) { dialog, which ->
                if (which != selectedIndex && which < audioTracks.size) {
                    val success = pm.setAudioTrack(audioTracks[which].trackIndex)
                    if (success) Toast.makeText(this, "Audio track switched", Toast.LENGTH_SHORT).show()
                    else Toast.makeText(this, "Failed to switch audio track", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun showServerDialog() {
        if (streamUrls.isEmpty() || streamUrls.size == 1) {
            Toast.makeText(this, "No alternative servers available", Toast.LENGTH_SHORT).show()
            return
        }
        val serverNames = streamUrls.mapIndexed { index, url ->
            buildString {
                append("Server ${index + 1}")
                if (url.server.isNotEmpty()) append(" - ${url.server}")
                if (url.quality.isNotEmpty()) append(" (${url.quality})")
                if (index == currentServerIndex) append(" ✓")
            }
        }.toTypedArray()
        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Select Server")
            .setSingleChoiceItems(serverNames, currentServerIndex) { dialog, which ->
                if (which != currentServerIndex && which < streamUrls.size) {
                    switchToServer(which)
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun switchToServer(serverIndex: Int) {
        if (serverIndex !in streamUrls.indices) return
        val pm = playerManager ?: return
        val currentPos = pm.getCurrentPosition()
        currentServerIndex = serverIndex
        serverButton.text = "Server ${serverIndex + 1}/${streamUrls.size}"
        qualityText.text = streamUrls[serverIndex].quality
        movieUrl = streamUrls[serverIndex].url
        loadMovie(movieUrl)
        resumePosition = currentPos
        shouldRestorePlayback = true
    }

    private fun tryNextServer() {
        if (streamUrls.size <= 1) return
        val nextIndex = (currentServerIndex + 1) % streamUrls.size
        Toast.makeText(this, "Trying server ${nextIndex + 1}...", Toast.LENGTH_SHORT).show()
        switchToServer(nextIndex)
    }

    private fun testSeekFunctionality() {
        val pm = playerManager ?: return
        val duration = pm.getDuration()
        val currentPosition = pm.getCurrentPosition()
        val isSeekable = pm.isSeekable()
        val playerType = pm.getPlayerType()
        val message = """
            Seek Test Results:
            Player: $playerType
            Duration: ${formatTime(duration)}
            Current: ${formatTime(currentPosition)}
            Seekable: $isSeekable
            Live Stream: ${duration <= 0}
        """.trimIndent()
        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Seek Test")
            .setMessage(message)
            .setPositiveButton("Test Seek Forward") { _, _ -> pm.seekBy(30000) }
            .setNegativeButton("Test Seek Back") { _, _ -> pm.seekBy(-15000) }
            .setNeutralButton("Cancel", null)
            .show()
    }

    private fun showAC3DetectedDialog(codecInfo: String) {
        val pm = playerManager ?: return
        if (pm.getPlayerType() == PlayerManager.PlayerType.VLC) return
        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("⚠️ AC3/DTS Audio Detected")
            .setMessage("$codecInfo\n\nThis audio format may not play correctly with ExoPlayer.\n\nSwitch to VLC player for full compatibility?")
            .setPositiveButton("Switch to VLC") { _, _ ->
                val currentPos = pm.getCurrentPosition()
                pm.switchToVLC(movieUrl, currentPos, autoSwitch = false)
            }
            .setNegativeButton("Continue with ExoPlayer") { _, _ ->
                Toast.makeText(this, "Audio may not play. Use 'Use VLC' button if needed.", Toast.LENGTH_LONG).show()
            }
            .setCancelable(true)
            .show()
    }

    private fun showNonSeekableDialog() {
        val pm = playerManager ?: return
        if (pm.getPlayerType() == PlayerManager.PlayerType.VLC) return
        if (!isSeekable) {
            android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("⚠️ Seeking Not Available")
                .setMessage("This video doesn't support seeking with ExoPlayer.\n\nVLC player may provide better seeking support.\n\nSwitch to VLC?")
                .setPositiveButton("Switch to VLC") { _, _ ->
                    val currentPos = pm.getCurrentPosition()
                    pm.switchToVLC(movieUrl, currentPos, autoSwitch = false)
                }
                .setNegativeButton("Continue", null)
                .setCancelable(true)
                .show()
        }
    }

    private fun showVLCSwitchDialog() {
        val pm = playerManager ?: return
        if (pm.getPlayerType() == PlayerManager.PlayerType.VLC) {
            Toast.makeText(this, "Already using VLC player", Toast.LENGTH_SHORT).show()
            return
        }
        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Switch to VLC Player")
            .setMessage("VLC player supports:\n\n✓ AC3/DTS audio\n✓ Better seeking\n✓ All video formats\n✓ Better network handling\n\nCurrent position will be preserved.")
            .setPositiveButton("Switch to VLC") { _, _ ->
                val currentPos = pm.getCurrentPosition()
                pm.switchToVLC(movieUrl, currentPos, autoSwitch = false)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showExoSwitchDialog() {
        val pm = playerManager ?: return
        if (pm.getPlayerType() == PlayerManager.PlayerType.EXOPLAYER) {
            Toast.makeText(this, "Already using ExoPlayer", Toast.LENGTH_SHORT).show()
            return
        }
        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Switch to ExoPlayer")
            .setMessage("ExoPlayer supports:\n\n✓ Better battery efficiency\n✓ Smoother UI integration\n✓ Native Android features\n✓ Better HLS/DASH streaming\nCurrent position will be preserved.")
            .setPositiveButton("Switch to ExoPlayer") { _, _ ->
                val currentPos = pm.getCurrentPosition()
                pm.switchToExoPlayer(movieUrl, currentPos)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ----- Speed Control -----
    private fun showSpeedDialog() {
        val speedLabels = SPEED_OPTIONS.map { "${it}x" }.toTypedArray()
        val currentIndex = SPEED_OPTIONS.indexOfFirst { it == currentPlaybackSpeed }.takeIf { it >= 0 } ?: 2
        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Playback Speed")
            .setSingleChoiceItems(speedLabels, currentIndex) { dialog, which ->
                if (which != currentIndex && which < SPEED_OPTIONS.size) {
                    setPlaybackSpeed(SPEED_OPTIONS[which])
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateSpeedButtonText() {
        speedButton.text = "${currentPlaybackSpeed}x"
    }

    private fun setPlaybackSpeed(speed: Float) {
        currentPlaybackSpeed = speed
        updateSpeedButtonText()
        val pm = playerManager ?: return
        when (pm.getPlayerType()) {
            PlayerManager.PlayerType.EXOPLAYER -> pm.getExoPlayer()?.setPlaybackSpeed(speed)
            PlayerManager.PlayerType.VLC -> pm.getVLCPlayer()?.setRate(speed)
        }
        Toast.makeText(this, "Speed: ${speed}x", Toast.LENGTH_SHORT).show()
    }

    private fun showSubtitleDialog() {
        Toast.makeText(this, "Subtitle feature coming soon", Toast.LENGTH_SHORT).show()
    }
    private fun turnOnSubtitles(trackIndex: Int) { Toast.makeText(this, "Subtitle feature coming soon", Toast.LENGTH_SHORT).show() }
    private fun turnOffSubtitles() { Toast.makeText(this, "Subtitle feature coming soon", Toast.LENGTH_SHORT).show() }

    private fun togglePlayPause() {
        val pm = playerManager ?: return
        if (pm.isPlaying()) pm.pause() else pm.play()
        updatePlayPauseButton()
    }

    private fun updatePlayPauseButton() {
        val pm = playerManager
        playPauseButton.setImageResource(
            if (pm != null && pm.isPlaying()) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        )
    }

    private fun safeSeekBy(incrementMs: Long) {
        val pm = playerManager ?: return
        if (!pm.isSeekable()) {
            Toast.makeText(this, "Seeking not supported", Toast.LENGTH_SHORT).show()
            return
        }
        accumulatedSeekDelta += incrementMs
        if (!controlsVisible) {
            userHidControlsTimestamp = System.currentTimeMillis()
        }
        seekAccumulatorHandler.removeCallbacks(applySeekRunnable)
        seekAccumulatorHandler.postDelayed(applySeekRunnable, SEEK_ACCUMULATOR_DELAY)
    }

    private fun applyAccumulatedSeek() {
        val pm = playerManager ?: return
        if (accumulatedSeekDelta == 0L) return
        pm.seekBy(accumulatedSeekDelta)
        accumulatedSeekDelta = 0L
    }

    private fun showSeekOverlay(deltaMs: Long) {
        if (!controlsVisible) return
        val pm = playerManager ?: return
        val currentPosition = pm.getCurrentPosition()
        val newPosition = currentPosition + deltaMs + accumulatedSeekDelta
        val duration = pm.getDuration()
        seekTimeText.text = formatTime(newPosition.coerceIn(0, duration))
        val totalDelta = deltaMs + accumulatedSeekDelta
        val deltaSeconds = totalDelta / 1000
        seekDeltaText.text = if (totalDelta > 0) "+${deltaSeconds}s" else "${deltaSeconds}s"
        seekIcon.setImageResource(if (totalDelta > 0) android.R.drawable.ic_media_ff else android.R.drawable.ic_media_rew)
        seekOverlay.visibility = View.VISIBLE
        seekOverlayHandler.removeCallbacks(hideSeekOverlayRunnable)
        seekOverlayHandler.postDelayed(hideSeekOverlayRunnable, SEEK_OVERLAY_HIDE_DELAY)
    }

    private fun hideSeekOverlay() {
        seekOverlay.visibility = View.GONE
    }

    private fun toggleControls() {
        if (isInPipMode) return
        if (controlsVisible) hideControls() else { showControls(); scheduleHideControls() }
    }

    private fun showControls() {
        if (isInPipMode) return
        controlsContainer.visibility = View.VISIBLE
        controlsVisible = true
        userHidControlsTimestamp = 0L
        cancelHideControls()
        gestureOverlay.isClickable = false
        gestureOverlay.isFocusable = false
        gestureOverlay.isEnabled = false
        gestureOverlay.isFocusableInTouchMode = false
        gestureOverlay.setOnTouchListener(null)
        setupControlsNavigation()
    }

    private fun hideControls() {
        controlsContainer.visibility = View.GONE
        controlsVisible = false
        userHidControlsTimestamp = System.currentTimeMillis()
        gestureOverlay.isEnabled = true
        gestureOverlay.isClickable = true
        gestureOverlay.isFocusable = true
        gestureOverlay.isFocusableInTouchMode = true
        gestureOverlay.setOnTouchListener { _, event -> handleGesture(event) }
        hideEpisodesRibbon()
    }

    private fun scheduleHideControls() {
        if (isInPipMode) return
        cancelHideControls()
        val pm = playerManager
        if (pm != null && pm.isPlaying() && !isBuffering) {
            hideHandler.postDelayed(hideControlsRunnable, HIDE_DELAY)
        }
    }

    private fun cancelHideControls() {
        hideHandler.removeCallbacks(hideControlsRunnable)
    }

    // ----- Episodes Ribbon -----
    private fun showEpisodesRibbon() {
        if (!isSeries || currentSeasonEpisodes.isEmpty()) {
            hideEpisodesRibbon()
            return
        }
        episodesRibbonContainer.visibility = View.VISIBLE
        if (!ribbonExpanded) {
            episodesRibbonContainer.translationY = (RIBBON_FULL_HEIGHT_DP - RIBBON_PEEK_HEIGHT_DP).toFloat() * resources.displayMetrics.density
        } else {
            episodesRibbonContainer.translationY = 0f
        }
        ribbonPeeking = true
        gestureOverlay.isClickable = false
        gestureOverlay.isFocusable = false
        gestureOverlay.setOnTouchListener(null)

        if (episodesList.childCount == 0) {
            populateEpisodesRibbon()
        }
    }

    private fun hideEpisodesRibbon() {
        episodesRibbonContainer.visibility = View.GONE
        episodesRibbonContainer.translationY = 0f
        ribbonPeeking = false
        ribbonExpanded = false
        playPauseButton.nextFocusDownId = View.NO_ID
    }

    private fun expandEpisodesRibbon() {
        if (!isSeries || currentSeasonEpisodes.isEmpty()) return
        if (episodesList.childCount == 0) populateEpisodesRibbon()
        episodesRibbonContainer.visibility = View.VISIBLE
        episodesRibbonContainer.animate()
            .translationY(0f)
            .setDuration(250)
            .start()
        ribbonExpanded = true
        ribbonPeeking = true

        if (episodesList.childCount > 0) {
            val focusIndex = if (currentEpisodeIndex in 0 until episodesList.childCount) currentEpisodeIndex else 0
            episodesList.getChildAt(focusIndex).requestFocus()
            updateEpisodeHighlight(currentEpisodeIndex)
        }
    }

    private fun collapseEpisodesRibbon() {
        if (!ribbonPeeking) return
        episodesRibbonContainer.animate()
            .translationY((RIBBON_FULL_HEIGHT_DP - RIBBON_PEEK_HEIGHT_DP).toFloat() * resources.displayMetrics.density)
            .setDuration(200)
            .start()
        ribbonExpanded = false
        if (controlsVisible) playPauseButton.requestFocus()
    }

    private fun populateEpisodesRibbon() {
        Log.d(TAG, "=== POPULATE EPISODES RIBBON ===")
        if (currentSeasonEpisodes.isEmpty()) {
            episodesList.removeAllViews()
            return
        }

        // Load watch progress for all episodes
        episodeWatchProgress.clear()
        val history = if (movieRepository != null) movieRepository!!.getWatchHistory() else emptyMap()
        currentSeasonEpisodes.forEach { episode ->
            val episodeId = "${seriesId}_S${episode.seasonNumber}_E${episode.episodeNumber}"
            val record = history[episodeId]
            val progress = if (record != null) {
                ((record.progress.coerceIn(0f, 1f)) * 100).toInt()
            } else 0
            episodeWatchProgress[episodeId] = progress
        }

        episodesList.removeAllViews()
        currentSeasonEpisodes.forEachIndexed { index, episode ->
            val episodeView = createEpisodeView(episode, index)
            episodeView.id = View.generateViewId()
            episodesList.addView(episodeView)
        }

        setupEpisodeNavigation()
        updateEpisodeHighlight(currentEpisodeIndex)
    }

    private fun createEpisodeView(episode: Episode, index: Int): View {
        val view = layoutInflater.inflate(R.layout.episode_ribbon_item, episodesList, false)

        val thumbnail = view.findViewById<ImageView>(R.id.episode_thumbnail)
        val episodeNumberText = view.findViewById<TextView>(R.id.episode_number)
        val title = view.findViewById<TextView>(R.id.episode_title)
        val watchedIndicator = view.findViewById<ImageView>(R.id.episode_watched)
        val currentIndicator = view.findViewById<View>(R.id.current_episode_indicator)
        val playButtonOverlay = view.findViewById<ImageView>(R.id.play_button_overlay)
        val progressBar = view.findViewById<ProgressBar>(R.id.episode_progress_bar)

        episodeNumberText.text = String.format("S%02d-E%02d", episode.seasonNumber, episode.episodeNumber)
        title.text = if (episode.title.isNotEmpty()) episode.title else "Episode ${episode.episodeNumber}"

        val episodeId = "${seriesId}_S${episode.seasonNumber}_E${episode.episodeNumber}"
        val progress = episodeWatchProgress[episodeId] ?: 0
        progressBar.progress = progress
        progressBar.visibility = if (progress > 0) View.VISIBLE else View.GONE

        val imageUrl = when {
            !seriesPosterUrl.isNullOrEmpty() -> seriesPosterUrl
            !episode.poster.isNullOrEmpty() -> episode.poster
            else -> null
        }
        if (imageUrl != null) {
            Coil.imageLoader(this).enqueue(
                ImageRequest.Builder(this)
                    .data(imageUrl)
                    .crossfade(true)
                    .placeholder(android.R.drawable.ic_menu_gallery)
                    .error(android.R.drawable.ic_menu_gallery)
                    .target(thumbnail)
                    .build()
            )
        } else {
            thumbnail.setBackgroundColor(0xFF222222.toInt())
            thumbnail.setImageResource(android.R.drawable.ic_menu_gallery)
        }

        if (index == currentEpisodeIndex) {
            currentIndicator.setBackgroundColor(0x809C27B0.toInt())
            currentIndicator.visibility = View.VISIBLE
        }
        if (episode.watchProgress > 0.9f) {
            watchedIndicator.visibility = View.VISIBLE
        }

        view.setOnClickListener { playEpisodeAtIndex(index) }
        view.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                lastFocusedEpisodeIndex = index
                cancelHideControls()
                playButtonOverlay.visibility = View.VISIBLE
                currentIndicator.visibility = View.VISIBLE
                if (index == currentEpisodeIndex) {
                    currentIndicator.setBackgroundColor(0x809C27B0.toInt())
                } else {
                    currentIndicator.setBackgroundColor(0x00000000.toInt())
                }
            } else {
                playButtonOverlay.visibility = View.GONE
                if (index != currentEpisodeIndex) {
                    currentIndicator.visibility = View.GONE
                }
            }
        }
        return view
    }

    private fun setupEpisodeNavigation() {
        val episodeCount = episodesList.childCount
        if (episodeCount == 0) return
        for (i in 0 until episodeCount) {
            val episodeView = episodesList.getChildAt(i)
            episodeView.nextFocusLeftId = if (i > 0) episodesList.getChildAt(i - 1).id else View.NO_ID
            episodeView.nextFocusRightId = if (i < episodeCount - 1) episodesList.getChildAt(i + 1).id else View.NO_ID
            episodeView.nextFocusUpId = playPauseButton.id
        }
    }

    private fun setupControlsNavigation() {
        rewindButton.nextFocusRightId = playPauseButton.id
        playPauseButton.nextFocusLeftId = rewindButton.id
        playPauseButton.nextFocusRightId = forwardButton.id
        forwardButton.nextFocusLeftId = playPauseButton.id

        backButton.nextFocusRightId = speedButton.id
        speedButton.nextFocusLeftId = backButton.id
        speedButton.nextFocusRightId = audioButton.id
        audioButton.nextFocusLeftId = speedButton.id
        audioButton.nextFocusRightId = serverButton.id
        serverButton.nextFocusLeftId = audioButton.id
        serverButton.nextFocusRightId = pipButton.id
        pipButton.nextFocusLeftId = serverButton.id

        backButton.nextFocusDownId = rewindButton.id
        speedButton.nextFocusDownId = playPauseButton.id
        audioButton.nextFocusDownId = playPauseButton.id
        serverButton.nextFocusDownId = playPauseButton.id
        pipButton.nextFocusDownId = forwardButton.id

        rewindButton.nextFocusUpId = backButton.id
        playPauseButton.nextFocusUpId = backButton.id
        forwardButton.nextFocusUpId = pipButton.id

        seekBar.nextFocusUpId = playPauseButton.id
        seekBar.nextFocusLeftId = rewindButton.id
        seekBar.nextFocusRightId = forwardButton.id
        seekBar.nextFocusDownId = View.NO_ID

        playPauseButton.nextFocusDownId = seekBar.id
        rewindButton.nextFocusDownId = seekBar.id
        forwardButton.nextFocusDownId = seekBar.id

        if (nextEpisodeButton.visibility == View.VISIBLE) {
            forwardButton.nextFocusRightId = nextEpisodeButton.id
            nextEpisodeButton.nextFocusLeftId = forwardButton.id
            nextEpisodeButton.nextFocusUpId = playPauseButton.id
            nextEpisodeButton.nextFocusDownId = seekBar.id
        }
    }

    private fun playEpisodeAtIndex(index: Int) {
        if (index !in currentSeasonEpisodes.indices) {
            Log.e(TAG, "Invalid episode index: $index")
            return
        }
        val episode = currentSeasonEpisodes[index]
        val url = episode.getBestStreamUrl() ?: run {
            Log.e(TAG, "No stream URL for episode: ${episode.getFormattedName()}")
            return
        }

        currentEpisodeIndex = index
        episodeNumber = episode.episodeNumber
        seasonNumber = episode.seasonNumber

        hasAutoPlayedNext = false
        hasShownNextEpisodeButton = false

        movieUrl = url
        movieTitle = "${seriesTitle} - ${episode.getFormattedName()}"
        playerManager?.load(url)

        titleText.text = movieTitle
        qualityText.text = episode.title.ifEmpty { episode.quality }

        updateEpisodeHighlight(index)
        Log.d(TAG, "▶️ Playing episode: ${episode.getFormattedName()} (Index: $index)")
    }

    private fun updateEpisodeHighlight(index: Int) {
        for (i in 0 until episodesList.childCount) {
            val episodeView = episodesList.getChildAt(i)
            val currentIndicator = episodeView.findViewById<View>(R.id.current_episode_indicator)
            if (currentIndicator != null) {
                if (i == index) {
                    currentIndicator.setBackgroundColor(0x809C27B0.toInt())
                    currentIndicator.visibility = View.VISIBLE
                } else {
                    currentIndicator.visibility = View.GONE
                }
            }
        }
        val currentEpisodeView = episodesList.getChildAt(index)
        currentEpisodeView?.let {
            episodesScrollView.smoothScrollTo(it.left - 50, 0)
        }
    }

    private fun updateProgress() {
        val pm = playerManager ?: return
        if (!isUserSeeking) {
            val duration = pm.getDuration()
            if (duration > 0) {
                val position = pm.getCurrentPosition()
                val progress = ((position * 100) / duration).toInt()

                if (controlsVisible) {
                    seekBar.progress = progress
                    timeText.text = formatTime(position)
                    val bufferedPosition = pm.getBufferedPosition()
                    val bufferedProgress = ((bufferedPosition * 100) / duration).toInt()
                    seekBar.secondaryProgress = bufferedProgress
                }

                // Auto-play next episode
                if (isSeries && currentSeasonEpisodes.isNotEmpty() && autoPlayNextEpisode) {
                    val timeRemaining = duration - position
                    if (!hasShownNextEpisodeButton && timeRemaining <= NEXT_EPISODE_SHOW_TIME_MS && timeRemaining >= 0) {
                        nextEpisodeButton.visibility = View.VISIBLE
                        hasShownNextEpisodeButton = true
                    }
                    if (!hasAutoPlayedNext && timeRemaining <= 500 && timeRemaining >= 0 && currentEpisodeIndex + 1 < currentSeasonEpisodes.size) {
                        hasAutoPlayedNext = true
                        playEpisodeAtIndex(currentEpisodeIndex + 1)
                    }
                }

                // Update progress bar for current episode if ribbon visible
                if (isSeries && episodesRibbonContainer.visibility == View.VISIBLE) {
                    val currentEpisodeId = "${seriesId}_S${seasonNumber}_E${episodeNumber}"
                    val newProgress = progress
                    val oldProgress = episodeWatchProgress[currentEpisodeId]
                    if (oldProgress != newProgress) {
                        episodeWatchProgress[currentEpisodeId] = newProgress
                        if (currentEpisodeIndex < episodesList.childCount) {
                            val episodeView = episodesList.getChildAt(currentEpisodeIndex)
                            val progressBar = episodeView.findViewById<ProgressBar>(R.id.episode_progress_bar)
                            progressBar?.progress = newProgress
                            progressBar?.visibility = if (newProgress > 0) View.VISIBLE else View.GONE
                        }
                    }
                }
            }
        }
    }

    private fun updateDuration() {
        val pm = playerManager ?: return
        val duration = pm.getDuration()
        if (duration > 0) {
            durationText.text = formatTime(duration)
            seekBar.max = 100
        }
    }

    private fun formatTime(ms: Long): String {
        val hours = TimeUnit.MILLISECONDS.toHours(ms)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(ms) % 60
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
        return if (hours > 0) String.format("%d:%02d:%02d", hours, minutes, seconds)
        else String.format("%02d:%02d", minutes, seconds)
    }

    private fun enterPictureInPicture() {
        if (!isPipSupported) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                enterPictureInPictureMode(buildPipParams())
            } catch (e: Exception) {
                Log.e(TAG, "Failed to enter PiP mode", e)
            }
        }
    }

    private fun buildPipParams(): PictureInPictureParams {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) throw IllegalStateException("PiP not supported below API 26")
        val builder = PictureInPictureParams.Builder()
        builder.setAspectRatio(Rational(16, 9))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setSeamlessResizeEnabled(true)
            builder.setAutoEnterEnabled(true)
        }
        return builder.build()
    }

    private suspend fun loadResumePosition() {
        val uniqueId = if (isSeries) "${seriesId}_S${seasonNumber}_E${episodeNumber}" else movieId
        uniqueId.takeIf { it.isNotEmpty() }?.let { id ->
            try {
                val repo = movieRepository
                if (repo != null) {
                    val watchRecord = repo.getWatchProgress(id)
                    if (watchRecord != null && watchRecord.position > 0) {
                        resumePosition = watchRecord.position
                        Log.d(TAG, "📍 Resuming from position: ${formatTime(resumePosition)}")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to load resume position", e)
            }
        }
    }

    private suspend fun saveCurrentProgress() {
        val uniqueId = if (isSeries) "${seriesId}_S${seasonNumber}_E${episodeNumber}" else movieId
        val pm = playerManager ?: return
        val repo = movieRepository ?: return

        uniqueId.takeIf { it.isNotEmpty() }?.let { id ->
            try {
                val duration = pm.getDuration()
                val position = pm.getCurrentPosition()
                val progress = if (duration > 0) (position * 100f / duration).toFloat() else 0f
                repo.saveWatchProgress(id, progress, position)
                Log.d(TAG, "✅ Saved progress for $id: ${String.format("%.1f%%", progress)} at ${formatTime(position)}")
            } catch (e: Exception) {
                Log.e(TAG, "❌ Failed to save progress", e)
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (isInPipMode) return super.onKeyDown(keyCode, event)

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (controlsVisible) {
                    window.decorView.findFocus()?.performClick()
                    true
                } else false
            }

            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (controlsVisible) {
                    val focusedView = window.decorView.findFocus()
                    if (focusedView?.id == seekBar.id) {
                        val increment = if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) 1000L else -1000L
                        safeSeekBy(increment)
                        showSeekOverlay(increment)
                        true
                    } else super.onKeyDown(keyCode, event)
                } else {
                    val increment = if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) SEEK_INCREMENT else -SEEK_INCREMENT
                    safeSeekBy(increment)
                    true
                }
            }

            KeyEvent.KEYCODE_DPAD_UP -> {
                if (!controlsVisible && isSeries && currentSeasonEpisodes.isNotEmpty()) {
                    if (ribbonExpanded) collapseEpisodesRibbon()
                    else expandEpisodesRibbon()
                    showControls()
                    true
                } else if (!controlsVisible) {
                    showControls()
                    true
                } else super.onKeyDown(keyCode, event)
            }

            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (!controlsVisible && isSeries && currentSeasonEpisodes.isNotEmpty() && ribbonPeeking) {
                    collapseEpisodesRibbon()
                    false
                } else if (!controlsVisible && isSeries && currentSeasonEpisodes.isNotEmpty()) {
                    expandEpisodesRibbon()
                    false
                } else if (!controlsVisible && episodesRibbonContainer.visibility == View.VISIBLE) {
                    collapseEpisodesRibbon()
                    showControls()
                    true
                } else if (!controlsVisible) {
                    showControls()
                    true
                } else super.onKeyDown(keyCode, event)
            }

            // KEYCODE_BACK intentionally omitted – handled by OnBackPressedDispatcher

            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlayPause(); true }
            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                if (playerManager?.isPlaying() == false) togglePlayPause()
                true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                safeSeekBy(SEEK_INCREMENT)
                showSeekOverlay(SEEK_INCREMENT)
                true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                safeSeekBy(-SEEK_INCREMENT)
                showSeekOverlay(-SEEK_INCREMENT)
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onStart() {
        super.onStart()
        updateHandler.postDelayed(updateProgressRunnable, 1000)
    }

    override fun onStop() {
        super.onStop()
        updateHandler.removeCallbacks(updateProgressRunnable)
        cancelHideControls()
        // Save progress when activity stops (ensures it's saved even if back button not used)
        lifecycleScope.launch(Dispatchers.Main) {
            withContext(NonCancellable) {
                saveCurrentProgress()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        hideHandler.removeCallbacksAndMessages(null)
        updateHandler.removeCallbacksAndMessages(null)
        playerManager?.release()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipMode = isInPictureInPictureMode
        if (isInPictureInPictureMode) hideControls()
    }
}
package com.shimulfp.bdixlivetv.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

// ============================================================================
// TV-OPTIMIZED CHANNEL CARD
// ============================================================================

@Composable
fun TvChannelCard(
    channelName: String,
    channelLogo: String,
    isSelected: Boolean,
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isFocused by remember { mutableStateOf(false) }

    // ========== TV FOCUS ANIMATIONS - VERY VISIBLE ==========
    val scale by animateDpAsState(
        targetValue = if (isFocused) 140.dp else 120.dp,
        animationSpec = spring(
            dampingRatio = 0.7f,
            stiffness = 400f
        ),
        label = "scale"
    )

    val borderWidth by animateDpAsState(
        targetValue = if (isFocused) 6.dp else 1.dp,
        animationSpec = tween(150),
        label = "borderWidth"
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color.Red          // Bright red when focused
            isPlaying -> Color.Green        // Green when playing
            else -> Color(0xFF333333)    // Dark gray when normal
        },
        animationSpec = tween(150),
        label = "borderColor"
    )

    val bgColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color(0xFF3D1A1A)  // Dark reddish when focused
            isPlaying -> Color(0xFF1A3D1A)  // Dark greenish when playing
            else -> Color(0xFF1E1E1E)      // Dark gray when normal
        },
        animationSpec = tween(150),
        label = "bgColor"
    )

    val titleColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color.White         // White when focused
            isPlaying -> Color(0xFF90EE90)  // Light green when playing
            else -> Color(0xFFAAAAAA)      // Gray when normal
        },
        animationSpec = tween(150),
        label = "titleColor"
    )

    // Focus requester for programmatic focus
    val focusRequester = remember { FocusRequester() }

    Box(
        modifier = modifier
            .width(scale)
            .height(scale * 0.6f) // Maintain aspect ratio
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .border(
                width = borderWidth,
                color = borderColor,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .onFocusChanged { focusState ->
                isFocused = focusState.isFocused
            }
            .focusable()
            .focusRequester(focusRequester)
    ) {
        // Channel logo or text
        if (channelLogo.isNotEmpty()) {
            AsyncImage(
                model = channelLogo,
                contentDescription = channelName,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                contentScale = androidx.compose.ui.layout.ContentScale.Fit
            )
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    channelName.take(3),
                    color = titleColor,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }

        // ========== FOCUS INDICATOR - TOP RIGHT CORNER ==========
        if (isFocused) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(20.dp)
                    .background(Color.Red, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = "Selected",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // ========== PLAYING INDICATOR - TOP LEFT CORNER ==========
        if (isPlaying) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(4.dp)
                    .size(24.dp)
                    .background(Color.Green, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.PlayArrow,
                    contentDescription = "Playing",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Channel name at bottom
        Text(
            text = channelName,
            color = titleColor,
            fontSize = if (isFocused) 13.sp else 11.sp,
            fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp)
        )
    }
}

// ============================================================================
// TV-OPTIMIZED MOVIE CARD
// ============================================================================

@Composable
fun TvMovieCard(
    movieTitle: String,
    moviePoster: String,
    movieQuality: String,
    movieYear: String,
    isFavorite: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isFocused by remember { mutableStateOf(false) }

    // ========== TV FOCUS ANIMATIONS - VERY VISIBLE ==========
    val scale by animateDpAsState(
        targetValue = if (isFocused) 150.dp else 130.dp,
        animationSpec = spring(
            dampingRatio = 0.7f,
            stiffness = 400f
        ),
        label = "scale"
    )

    val borderWidth by animateDpAsState(
        targetValue = if (isFocused) 6.dp else 2.dp,
        animationSpec = tween(150),
        label = "borderWidth"
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color.Red          // Bright red when focused
            isSelected -> Color.Yellow       // Yellow when selected
            else -> Color(0xFF333333)    // Dark gray when normal
        },
        animationSpec = tween(150),
        label = "borderColor"
    )

    val bgColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color(0xFF3D1A1A)  // Dark reddish when focused
            isSelected -> Color(0xFF3D3D1A) // Dark yellowish when selected
            else -> Color(0xFF1E1E1E)      // Dark gray when normal
        },
        animationSpec = tween(150),
        label = "bgColor"
    )

    // Focus requester for programmatic focus
    val focusRequester = remember { FocusRequester() }

    Column(
        modifier = modifier
            .width(scale)
            .clickable { onClick() }
            .onFocusChanged { focusState ->
                isFocused = focusState.isFocused
            }
            .focusable()
            .focusRequester(focusRequester)
    ) {
        // Poster
        Box(
            modifier = Modifier
                .width(scale)
                .height(scale * 1.5f) // 2:3 aspect ratio
                .clip(RoundedCornerShape(12.dp))
                .background(bgColor)
                .border(
                    width = borderWidth,
                    color = borderColor,
                    shape = RoundedCornerShape(12.dp)
                )
        ) {
            // Movie poster
            if (moviePoster.isNotEmpty()) {
                AsyncImage(
                    model = moviePoster,
                    contentDescription = movieTitle,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                )
            } else {
                // Placeholder
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.Gray,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            movieTitle.take(20),
                            color = Color.Gray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // ========== FOCUS OVERLAY - VERY VISIBLE ==========
            if (isFocused) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.Red.copy(alpha = 0.8f)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Large play button
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .background(Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = Color.Red,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "SELECT",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // ========== QUALITY BADGE - TOP RIGHT ==========
            if (movieQuality.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .background(
                            when {
                                isFocused -> Color.Red
                                movieQuality.contains("4K") -> Color(0xFFFFD700)
                                movieQuality.contains("1080") -> Color(0xFF00FF00)
                                movieQuality.contains("720") -> Color(0xFF00BFFF)
                                else -> Color(0xFF808080)
                            },
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        movieQuality,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // ========== YEAR BADGE - TOP LEFT ==========
            if (movieYear.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        movieYear,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // ========== FAVORITE HEART - BOTTOM LEFT ==========
            if (isFavorite) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                        .size(24.dp)
                        .background(Color.Red, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = "Favorite",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Movie title below poster
        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = movieTitle,
            color = if (isFocused) Color.White else Color(0xFFCCCCCC),
            fontSize = if (isFocused) 13.sp else 11.sp,
            fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Start,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

// ============================================================================
// TV-OPTIMIZED NAV ITEM
// ============================================================================

@Composable
fun TvNavItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isFocused by remember { mutableStateOf(false) }

    // ========== TV FOCUS ANIMATIONS - VERY VISIBLE ==========
    val borderWidth by animateDpAsState(
        targetValue = if (isFocused) 3.dp else 0.dp,
        animationSpec = tween(150),
        label = "borderWidth"
    )

    val borderColor by animateColorAsState(
        targetValue = if (isFocused) Color.Red else Color.Transparent,
        animationSpec = tween(150),
        label = "borderColor"
    )

    val bgColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color(0xFF3D1A1A)  // Dark reddish when focused
            isSelected -> Color(0xFF2A2A2A) // Slightly lighter when selected
            else -> Color.Transparent       // Transparent when normal
        },
        animationSpec = tween(150),
        label = "bgColor"
    )

    val textColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color.White          // White when focused
            isSelected -> Color.Red           // Red when selected
            else -> Color(0xFFAAAAAA)      // Gray when normal
        },
        animationSpec = tween(150),
        label = "textColor"
    )

    val iconColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color.Red            // Red when focused
            isSelected -> Color.Red           // Red when selected
            else -> Color(0xFF808080)      // Gray when normal
        },
        animationSpec = tween(150),
        label = "iconColor"
    )

    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = borderWidth,
                color = borderColor,
                shape = RoundedCornerShape(8.dp)
            )
            .onFocusChanged { focusState ->
                isFocused = focusState.isFocused
            }
            .focusable(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = bgColor
        )
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                title,
                color = textColor,
                fontSize = 14.sp,
                fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

// ============================================================================
// TV-OPTIMIZED CATEGORY CHIP
// ============================================================================

@Composable
fun TvCategoryChip(
    title: String,
    count: Int,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    val borderWidth by animateDpAsState(
        targetValue = if (isFocused) 3.dp else if (isSelected) 2.dp else 0.dp,
        animationSpec = tween(150),
        label = "borderWidth"
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color.Red
            isSelected -> Color.Red
            else -> Color(0xFF333333)
        },
        animationSpec = tween(150),
        label = "borderColor"
    )

    val bgColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color(0xFF3D1A1A)
            isSelected -> Color.Red
            else -> Color(0xFF2A2A2A)
        },
        animationSpec = tween(150),
        label = "bgColor"
    )

    val textColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color.White
            isSelected -> Color.White
            else -> Color(0xFFAAAAAA)
        },
        animationSpec = tween(150),
        label = "textColor"
    )

    FilterChip(
        selected = isSelected,
        onClick = onClick,
        label = {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title)
                if (count > 0) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "($count)",
                        fontSize = 11.sp
                    )
                }
            }
        },
        modifier = Modifier
            .border(
                width = borderWidth,
                color = borderColor,
                shape = RoundedCornerShape(8.dp)
            )
            .onFocusChanged { focusState ->
                isFocused = focusState.isFocused
            }
            .focusable(),
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = bgColor,
            selectedLabelColor = textColor,
            containerColor = Color(0xFF2A2A2A),
            labelColor = Color(0xFFAAAAAA)
        ),
        border = BorderStroke(
            width = borderWidth,
            color = borderColor
        )
    )
}

// ============================================================================
// FOCUS MANAGER HELPER
// ============================================================================

@Composable
fun rememberTvFocusManager(): TvFocusManager {
    return remember { TvFocusManager() }
}

class TvFocusManager {
    private var currentFocusedIndex by mutableStateOf(0)
    private val focusRequesters = mutableMapOf<Int, FocusRequester>()

    fun requestFocus(index: Int) {
        currentFocusedIndex = index
        focusRequesters[index]?.requestFocus()
    }

    fun registerFocusRequester(index: Int, focusRequester: FocusRequester) {
        focusRequesters[index] = focusRequester
    }

    fun moveFocus(direction: Direction, itemCount: Int) {
        val newIndex = when (direction) {
            Direction.UP -> currentFocusedIndex
            Direction.DOWN -> currentFocusedIndex
            Direction.LEFT -> (currentFocusedIndex - 1 + itemCount) % itemCount
            Direction.RIGHT -> (currentFocusedIndex + 1) % itemCount
        }
        currentFocusedIndex = newIndex
        focusRequesters[newIndex]?.requestFocus()
    }

    enum class Direction {
        UP, DOWN, LEFT, RIGHT
    }
}

package com.shimulfp.bdixlivetv.components.series

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusState
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.shimulfp.bdixlivetv.data.MovieRepository
import com.shimulfp.bdixlivetv.models.Episode
import com.shimulfp.bdixlivetv.models.Season
import com.shimulfp.bdixlivetv.models.Series
import kotlinx.coroutines.launch

/**
 * Series Detail Screen - Shows series info with seasons and episodes
 * TV-Friendly: Simple implementation with red border on focus
 */
@Composable
fun SeriesDetailScreen(
    series: Series,
    onBack: () -> Unit,
    onEpisodeClick: (Episode) -> Unit,
    onSeasonClick: (Season) -> Unit
) {
    var selectedSeason by remember { mutableStateOf(series.getLatestSeason()) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Backdrop & Poster Section
            item {
                SeriesHeader(series = series, onBack = onBack)
            }

            // Info Section
            item {
                SeriesInfo(series = series)
            }

            // Seasons Selector
            item {
                if (series.seasons.size > 1) {
                    SeasonSelector(
                        seasons = series.seasons,
                        selectedSeason = selectedSeason,
                        onSeasonClick = { season ->
                            onSeasonClick(season)
                            selectedSeason = season
                        }
                    )
                }
            }

            // Episodes List
            item {
                selectedSeason?.let { season ->
                    EpisodesList(
                        season = season,
                        seriesTitle = series.title,
                        seriesId = series.id,
                        onEpisodeClick = onEpisodeClick
                    )
                }
            }
        }
    }
}

@Composable
fun SeriesHeader(
    series: Series,
    onBack: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp)
    ) {
        // Backdrop
        if (!series.backdrop.isNullOrEmpty()) {
            AsyncImage(
                model = series.backdrop,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else if (!series.poster.isNullOrEmpty()) {
            AsyncImage(
                model = series.poster,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            // Placeholder gradient
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF6200EE),
                                Color(0xFF3700B3)
                            )
                        )
                    )
            )
        }

        // Gradient Overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0xFF0A0A0A)
                        )
                    )
                )
        ) {
            // Back Button
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(50))
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
fun SeriesInfo(series: Series) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        // Title
        Text(
            series.title,
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        if (series.year.isNotEmpty() || series.totalEpisodes > 0) {
            Spacer(modifier = Modifier.height(8.dp))
            // Metadata Row
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (series.year.isNotEmpty()) {
                    InfoChip(label = series.year)
                }
                if (series.totalEpisodes > 0) {
                    InfoChip(label = "${series.totalEpisodes} Episodes")
                }
                if (series.getSeasonCount() > 1) {
                    InfoChip(label = "${series.getSeasonCount()} Seasons")
                }
                if (series.language.isNotEmpty()) {
                    InfoChip(label = series.language)
                }
            }
        }

        // Description
        if (series.description.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                series.description,
                color = Color.Gray,
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        }
    }
}

@Composable
fun InfoChip(label: String) {
    Surface(
        color = Color(0xFF1A1A1A),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Text(
            label,
            color = Color.White,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun SeasonSelector(
    seasons: List<Season>,
    selectedSeason: Season?,
    onSeasonClick: (Season) -> Unit
) {
    Column {
        Text(
            "Seasons",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(seasons) { season ->
                SeasonChip(
                    season = season,
                    isSelected = selectedSeason?.seasonNumber == season.seasonNumber,
                    onClick = { onSeasonClick(season) }
                )
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun SeasonChip(
    season: Season,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    FilterChip(
        selected = isSelected,
        onClick = onClick,
        label = {
            Text(
                season.title,
                fontSize = 14.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        },
        colors = FilterChipDefaults.filterChipColors(
            containerColor = Color(0xFF1A1A1A),
            labelColor = Color.Gray,
            selectedContainerColor = Color(0xFF6200EE),
            selectedLabelColor = Color.White
        ),
        modifier = Modifier
            .onFocusChanged { focusState: FocusState ->
                isFocused = focusState.isFocused
            }
            .focusable()
            .border(
                width = if (isFocused) 2.dp else 0.dp,
                color = if (isFocused) Color(0xFFE53935) else Color.Transparent,
                shape = RoundedCornerShape(20.dp)
            )
            .padding(if (isFocused) 2.dp else 0.dp)
    )
}

@Composable
fun EpisodesList(
    season: Season,
    seriesTitle: String,
    seriesId: String,
    onEpisodeClick: (Episode) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var watchHistoryIds by remember { mutableStateOf(setOf<String>()) }

    // Load watch history
    LaunchedEffect(season) {
        scope.launch {
            try {
                val repo = MovieRepository.getInstance(context)
                val history = repo.getWatchHistory()
                // Extract episode IDs that have significant watch progress (> 5%)
                // Normalize progress: if > 1.0, divide by 100 (convert from percentage)
                watchHistoryIds = history.filter { (id, record) ->
                    val episodeMatch = Regex("${Regex.escape(seriesId)}_S${season.seasonNumber}_E(\\d+)").find(id)
                    val normalizedProgress = if (record.progress > 1.5f) {
                        record.progress / 100f
                    } else {
                        record.progress
                    }
                    episodeMatch != null && normalizedProgress > 0.05f
                }.keys.toSet()
            } catch (e: Exception) {
                // Ignore errors
            }
        }
    }

    Column {
        Text(
            "Episodes (${season.episodes.size})",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        season.episodes.forEach { episode ->
            EpisodeItem(
                episode = episode,
                seriesId = seriesId,
                isWatched = "${seriesId}_S${season.seasonNumber}_E${episode.episodeNumber}" in watchHistoryIds,
                onEpisodeClick = onEpisodeClick
            )
        }
        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun EpisodeItem(
    episode: Episode,
    seriesId: String,
    isWatched: Boolean,
    onEpisodeClick: (Episode) -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp, horizontal = 16.dp)
            .onFocusChanged { focusState ->
                isFocused = focusState.isFocused
            }
            .combinedClickable(
                onClick = { onEpisodeClick(episode) },
                onLongClick = null,
                onDoubleClick = null
            )
            .then(
                if (isFocused) {
                    Modifier.border(
                        width = 2.dp,
                        color = Color(0xFFE53935),
                        shape = RoundedCornerShape(8.dp)
                    )
                } else {
                    Modifier
                }
            )
    ) {
        Surface(
            color = Color(0xFF1A1A1A),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Episode Number
                Surface(
                    color = if (isWatched) Color.Red else Color(0xFF6200EE),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.size(48.dp, 48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            if (isWatched) Icons.Filled.Check else Icons.Filled.PlayArrow,
                            contentDescription = if (isWatched) "Watched" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(16.dp))
                // Episode Info
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        episode.getFormattedName(),
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = if (isWatched) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (episode.title.isNotEmpty()) {
                        Text(
                            episode.title,
                            color = if (isWatched) Color.Red else Color.Gray,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (episode.quality.isNotEmpty()) {
                        Text(
                            episode.quality,
                            color = Color(0xFF4CAF50),
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
                // Play Icon
                Icon(
                    Icons.Filled.PlayArrow,
                    contentDescription = "Play",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
        }

        // Red bottom border for watched episodes (when not focused)
        if (isWatched && !isFocused) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(Color.Red)
            )
        }
    }
}
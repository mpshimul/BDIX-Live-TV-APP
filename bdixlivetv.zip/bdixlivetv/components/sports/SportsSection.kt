package com.shimulfp.bdixlivetv.components.sports

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.shimulfp.bdixlivetv.models.SportsEvent

/**
 * Sports Section - Main container for Live Sports Events
 */
@Composable
fun SportsSection(
    viewModel: com.shimulfp.bdixlivetv.viewmodel.SportsViewModel,
    onEventClick: (SportsEvent) -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val liveEvents by viewModel.liveEvents.collectAsState()
    val upcomingEvents by viewModel.upcomingEvents.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)
    ) {
        // Section Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Title
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Filled.Sports,
                    contentDescription = null,
                    tint = Color(0xFF4CAF50),
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "Live Sports Event",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Refresh button
            var refreshFocused by remember { mutableStateOf(false) }
            val refreshScale by animateFloatAsState(
                targetValue = if (refreshFocused || isRefreshing) 1.15f else 1f,
                animationSpec = tween(150),
                label = "refreshScale"
            )

            IconButton(
                onClick = { viewModel.refreshSportsData(context) },
                modifier = Modifier
                    .scale(refreshScale)
                    .onFocusChanged { refreshFocused = it.isFocused }
                    .then(
                        if (refreshFocused) {
                            Modifier.border(
                                width = 2.dp,
                                color = Color(0xFF4CAF50),
                                shape = RoundedCornerShape(8.dp)
                            )
                        } else {
                            Modifier
                        }
                    ),
                enabled = !isRefreshing
            ) {
                if (isRefreshing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color(0xFF4CAF50),
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        Icons.Filled.Refresh,
                        contentDescription = "Refresh",
                        tint = if (refreshFocused) Color(0xFF4CAF50) else Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
        
        // Content
        when (uiState) {
            is com.shimulfp.bdixlivetv.viewmodel.SportsUiState.Loading -> {
                SportsLoadingState()
            }
            
            is com.shimulfp.bdixlivetv.viewmodel.SportsUiState.Success -> {
                // Show Live Events first
                if (liveEvents.isNotEmpty()) {
                    LiveEventsSection(
                        title = "🔴 Live Now",
                        events = liveEvents,
                        onEventClick = onEventClick
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }
                
                // Show Upcoming Events
                if (upcomingEvents.isNotEmpty()) {
                    UpcomingEventsSection(
                        title = "⏰ Upcoming",
                        events = upcomingEvents,
                        onEventClick = onEventClick
                    )
                }
            }
            
            is com.shimulfp.bdixlivetv.viewmodel.SportsUiState.Empty -> {
                SportsEmptyState()
            }
            
            is com.shimulfp.bdixlivetv.viewmodel.SportsUiState.Error -> {
                SportsErrorState(
                    message = (uiState as com.shimulfp.bdixlivetv.viewmodel.SportsUiState.Error).message,
                    onRetry = {
                        viewModel.refreshSportsData(context)
                    }
                )
            }
        }
    }
}

/**
 * Live Events Section
 */
@Composable
private fun LiveEventsSection(
    title: String,
    events: List<SportsEvent>,
    onEventClick: (SportsEvent) -> Unit
) {
    Column {
        Text(
            text = title,
            color = Color(0xFF4CAF50),
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        
        LazyRow(
            contentPadding = PaddingValues(horizontal = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(events, key = { it.id }) { event ->
                SportsCard(
                    event = event,
                    onClick = { onEventClick(event) },
                    modifier = Modifier.width(320.dp)
                )
            }
        }
    }
}

/**
 * Upcoming Events Section
 */
@Composable
private fun UpcomingEventsSection(
    title: String,
    events: List<SportsEvent>,
    onEventClick: (SportsEvent) -> Unit
) {
    Column {
        Text(
            text = title,
            color = Color(0xFF2196F3),
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        
        LazyRow(
            contentPadding = PaddingValues(horizontal = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(events, key = { it.id }) { event ->
                SportsCard(
                    event = event,
                    onClick = { onEventClick(event) },
                    modifier = Modifier.width(320.dp)
                )
            }
        }
    }
}

/**
 * Sports Card - Individual event card
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SportsCard(
    event: SportsEvent,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isFocused by remember { mutableStateOf(false) }
    
    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.08f else 1f,
        animationSpec = tween(150),
        label = "cardScale"
    )
    
    val borderColor by animateColorAsState(
        targetValue = if (isFocused) Color(0xFF4CAF50) else Color(0xFF333333),
        animationSpec = tween(150),
        label = "borderColor"
    )
    
    Card(
        onClick = onClick,
        modifier = modifier
            .scale(scale)
            .onFocusChanged { isFocused = it.isFocused }
            .height(200.dp)
            .border(
                width = if (isFocused) 3.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(16.dp)
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1E1E1E)
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isFocused) 8.dp else 2.dp
        )
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            // Thumbnail
            if (event.thumbnail.isNotEmpty()) {
                AsyncImage(
                    model = event.thumbnail,
                    contentDescription = event.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                
                // Gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.Black.copy(alpha = 0.7f)
                                )
                            )
                        )
                )
            } else {
                // Placeholder with sports icon
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF4CAF50).copy(alpha = 0.3f),
                                    Color(0xFF1A1A2E)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Filled.Sports,
                            contentDescription = null,
                            tint = Color(0xFF4CAF50),
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = event.getDisplaySport(),
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            
            // Content overlay
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp)
            ) {
                // Sport badge
                Surface(
                    color = if (event.isLive) {
                        Color(0xFF4CAF50)
                    } else {
                        Color(0xFF2196F3)
                    },
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.wrapContentWidth()
                ) {
                    Text(
                        text = event.getStatusText(),
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Title
                Text(
                    text = event.title,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                
                // Teams/League
                if (event.teams.isNotEmpty()) {
                    Text(
                        text = event.teams,
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                
                // League
                if (event.league.isNotEmpty() && event.league != event.teams) {
                    Text(
                        text = event.league,
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Stream count badge
                if (event.streamUrls.isNotEmpty()) {
                    Surface(
                        color = Color(0xFF4CAF50).copy(alpha = 0.8f),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.wrapContentWidth()
                    ) {
                        Text(
                            text = "${event.streamUrls.size} stream${if (event.streamUrls.size > 1) "s" else ""}",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            
            // Play button overlay when focused
            if (isFocused) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        color = Color(0xFF4CAF50),
                        shape = CircleShape,
                        modifier = Modifier.size(64.dp)
                    ) {
                        Icon(
                            Icons.Filled.PlayArrow,
                            contentDescription = "Play",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Empty State - No sports events
 */
@Composable
private fun SportsEmptyState() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .padding(horizontal = 24.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1A1A2E)
        ),
        border = BorderStroke(1.dp, Color(0xFF333333))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                Icons.Filled.Sports,
                contentDescription = null,
                tint = Color(0xFF4CAF50).copy(alpha = 0.5f),
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "No Live Sports Events",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "Check back later for upcoming events",
                color = Color.Gray,
                fontSize = 13.sp
            )
        }
    }
}

/**
 * Loading State
 */
@Composable
private fun SportsLoadingState() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .padding(horizontal = 24.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1A1A2E)
        ),
        border = BorderStroke(1.dp, Color(0xFF333333))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator(
                color = Color(0xFF4CAF50),
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Loading Sports Events...",
                color = Color.White,
                fontSize = 14.sp
            )
        }
    }
}

/**
 * Error State
 */
@Composable
private fun SportsErrorState(
    message: String,
    onRetry: () -> Unit
) {
    var retryFocused by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .padding(horizontal = 24.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1A1A2E)
        ),
        border = BorderStroke(1.dp, Color(0xFFB71C1C))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                Icons.Filled.Error,
                contentDescription = null,
                tint = Color(0xFFB71C1C),
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Unable to load sports events",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = message,
                color = Color.Gray,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF4CAF50)
                ),
                modifier = Modifier
                    .focusRequester(remember { androidx.compose.ui.focus.FocusRequester() })
                    .onFocusChanged { retryFocused = it.isFocused }
            ) {
                Icon(
                    Icons.Filled.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Retry")
            }
        }
    }
}

package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Log
import com.shimulfp.bdixlivetv.ChannelCacheManager.RefreshResult
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * RefreshCoordinator - Unified refresh management
 * Prevents concurrent refreshes and race conditions
 * Single source of truth for all refresh operations
 */
object RefreshCoordinator {
    private const val TAG = "RefreshCoordinator"

    // Thread-safe refresh state
    private val refreshMutex = Mutex()
    @Volatile
    private var lastRefreshTime = 0L
    @Volatile
    private var isRefreshing = false

    /**
     * Request a refresh operation
     * Returns false if refresh was skipped (too soon or already refreshing)
     * Returns true if refresh was attempted
     */
    suspend fun requestRefresh(
        context: Context,
        reason: String,
        username: String?,
        password: String?
    ): Boolean = refreshMutex.withLock {
        val now = System.currentTimeMillis()

        // Check if already refreshing
        if (isRefreshing) {
            Log.w(TAG, "⚠️ Already refreshing, skipping ($reason)")
            return@withLock false
        }

        // Check if too soon (skip for manual refreshes)
        val minInterval = SyncConfig.MIN_REFRESH_INTERVAL_MS
        if (reason != "manual" && (now - lastRefreshTime) < minInterval) {
            val secondsSince = ((now - lastRefreshTime) / 1000)
            Log.w(TAG, "⚠️ Refresh too soon ($reason) - ${secondsSince}s ago, need ${minInterval/1000}s")
            return@withLock false
        }

        try {
            isRefreshing = true
            lastRefreshTime = now

            Log.d(TAG, "🔄 Starting refresh: $reason")
            val result = ChannelCacheManager.refreshAllChannels(context, username, password)

            Log.d(TAG, "✅ Refresh completed: $reason (${result.allChannels.size} channels)")
            return@withLock true
        } catch (e: Exception) {
            Log.e(TAG, "❌ Refresh failed: $reason - ${e.message}", e)
            return@withLock false
        } finally {
            isRefreshing = false
        }
    }

    /**
     * Request a background refresh
     */
    suspend fun requestBackgroundRefresh(
        context: Context,
        username: String?,
        password: String?
    ): Boolean {
        return requestRefresh(context, "background", username, password)
    }

    /**
     * Request a manual refresh (user-triggered)
     * Bypasses the minimum interval check
     */
    suspend fun requestManualRefresh(
        context: Context,
        username: String?,
        password: String?
    ): Boolean {
        return requestRefresh(context, "manual", username, password)
    }

    /**
     * Get current refresh state
     */
    fun getRefreshState(): RefreshState {
        val now = System.currentTimeMillis()
        val timeSinceLastRefresh = if (lastRefreshTime > 0) {
            now - lastRefreshTime
        } else {
            0L
        }

        return RefreshState(
            isRefreshing = isRefreshing,
            lastRefreshTime = lastRefreshTime,
            secondsSinceLastRefresh = timeSinceLastRefresh / 1000,
            canRefresh = !isRefreshing &&
                (timeSinceLastRefresh >= SyncConfig.MIN_REFRESH_INTERVAL_MS)
        )
    }

    /**
     * Reset refresh state (for testing or force refresh)
     */
    fun reset() {
        refreshMutex.tryLock {
            isRefreshing = false
            lastRefreshTime = 0L
            Log.d(TAG, "🔄 Refresh state reset")
        }
    }
}

/**
 * Refresh state information
 */
data class RefreshState(
    val isRefreshing: Boolean,
    val lastRefreshTime: Long,
    val secondsSinceLastRefresh: Long,
    val canRefresh: Boolean
) {
    fun getFormattedTimeSinceRefresh(): String {
        val seconds = secondsSinceLastRefresh
        return when {
            seconds < 60 -> "${seconds}s ago"
            seconds < 3600 -> "${seconds / 60}m ago"
            else -> "${seconds / 3600}h ago"
        }
    }
}

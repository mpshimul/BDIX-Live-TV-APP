package com.shimulfp.bdixlivetv

import android.util.Log
import com.google.firebase.BuildConfig
//import com.shimulfp.bdixlivetv.BuildConfig

/**
 * SyncConfig - Centralized configuration for all sync operations
 * Single source of truth for thresholds, intervals, and timeouts
 */
object SyncConfig {
    private const val TAG = "SyncConfig"

    // ==================== REFRESH INTERVALS ====================
    /**
     * Minimum time between refreshes (in milliseconds)
     * Prevents excessive refresh operations
     */
    const val MIN_REFRESH_INTERVAL_MS = 60_000L  // 1 minute

    /**
     * Background refresh interval (in milliseconds)
     * How often to check if refresh is needed
     */
    const val BACKGROUND_REFRESH_CHECK_INTERVAL_MS = 30_000L  // 30 seconds

    /**
     * GitHub sync check interval (in milliseconds)
     * How often to check if GitHub sync should run
     */
    const val GITHUB_SYNC_CHECK_INTERVAL_MS = 5 * 60 * 1000L  // 5 minutes

    /**
     * Cache age update interval (in milliseconds)
     * How often to update cache age display
     */
    const val CACHE_AGE_UPDATE_INTERVAL_MS = 10_000L  // 10 seconds
    
    /**
     * Sports sync check interval (in milliseconds)
     * How often to check if sports data needs refreshing
     */
    const val SPORTS_SYNC_CHECK_INTERVAL_MS = 10 * 60 * 1000L  // 10 minutes

    // ==================== CACHE THRESHOLDS ====================
    /**
     * Cache expiry time (in minutes)
     * After this time, cache is considered stale
     */
    private const val CHANNEL_CACHE_EXPIRY_MINUTES_NORMAL = 40L
    private const val CHANNEL_CACHE_EXPIRY_MINUTES_DEBUG = 20L
    //private const val CHANNEL_CACHE_EXPIRY_MINUTES_NORMAL = 30L
    //private const val CHANNEL_CACHE_EXPIRY_MINUTES_DEBUG = 10L // 10 Minutes test

    /**
     * Movie data freshness threshold (in minutes)
     */
    const val MOVIE_FRESHNESS_THRESHOLD_MINUTES = 120L  // 2 hours
    //const val MOVIE_FRESHNESS_THRESHOLD_MINUTES = 5L  // 5 Minutes test

    /**
     * Series data freshness threshold (in minutes)
     */
    const val SERIES_FRESHNESS_THRESHOLD_MINUTES = 120L  // 2 hours
    //const val SERIES_FRESHNESS_THRESHOLD_MINUTES = 5L  // 5 Minutes test

    /**
     * GitHub channel data max age (in minutes)
     * After this time, GitHub data is considered too old
     */
    const val MAX_CHANNEL_CACHE_AGE_MINUTES = 40L
    //const val MAX_CHANNEL_CACHE_AGE_MINUTES = 5L // 5 Minutes test

    // ==================== FILE SIZE THRESHOLDS ====================
    /**
     * Minimum cache file size (in bytes)
     * Files smaller than this are considered invalid/corrupted
     */
    const val MIN_CACHE_FILE_SIZE = 500L  // 500 bytes

    /**
     * Minimum channel cache file size (in bytes)
     */
    const val MIN_CHANNEL_CACHE_FILE_SIZE = 100L

    /**
     * Minimum movie/series cache file size (in bytes)
     */
    const val MIN_MOVIE_SERIES_CACHE_FILE_SIZE = 1000L

    // ==================== CACHE VERSIONS ====================
    /**
     * Current cache version
     * Increment when cache structure changes
     */
    const val CURRENT_CACHE_VERSION = 2

    /**
     * Minimum supported cache version
     * Versions below this will be rejected
     */
    const val MIN_SUPPORTED_CACHE_VERSION = 1

    // ==================== RETRY CONFIGURATION ====================
    /**
     * Maximum retry attempts for failed operations
     */
    const val MAX_RETRY_ATTEMPTS = 3

    /**
     * Base delay between retries (in milliseconds)
     */
    const val RETRY_BASE_DELAY_MS = 1000L  // 1 second

    /**
     * Maximum retry delay (in milliseconds)
     */
    const val MAX_RETRY_DELAY_MS = 10_000L  // 10 seconds

    // ==================== PUBLIC GETTERS ====================
    /**
     * Get cache expiry minutes based on build type
     */
    fun getChannelCacheExpiryMinutes(): Long {
        return if (BuildConfig.DEBUG) {
            CHANNEL_CACHE_EXPIRY_MINUTES_DEBUG
        } else {
            CHANNEL_CACHE_EXPIRY_MINUTES_NORMAL
        }
    }

    /**
     * Get cache age display text
     */
    fun getCacheAgeText(ageMinutes: Long): String {
        return when {
            ageMinutes == 0L -> "Just now"
            ageMinutes < 1L -> "Less than 1m ago"
            ageMinutes < 60L -> "${ageMinutes}m ago"
            ageMinutes < 1440L -> "${ageMinutes / 60}h ago"
            else -> "${ageMinutes / 1440}d ago"
        }
    }

    /**
     * Calculate exponential backoff delay
     * @param attempt Current attempt number (0-indexed)
     * @return Delay in milliseconds
     */
    fun getExponentialBackoffDelay(attempt: Int): Long {
        val delay = RETRY_BASE_DELAY_MS * (1 shl attempt) // 2^attempt
        return minOf(delay, MAX_RETRY_DELAY_MS)
    }

    /**
     * Log current configuration
     */
    fun logConfiguration() {
        Log.d(TAG, "=== SYNC CONFIGURATION ===")
        Log.d(TAG, "Build Type: ${if (BuildConfig.DEBUG) "DEBUG" else "RELEASE"}")
        Log.d(TAG, "Min Refresh Interval: ${MIN_REFRESH_INTERVAL_MS / 1000}s")
        Log.d(TAG, "Cache Expiry: ${getChannelCacheExpiryMinutes()}m")
        Log.d(TAG, "Cache Version: $CURRENT_CACHE_VERSION")
        Log.d(TAG, "Max Retry Attempts: $MAX_RETRY_ATTEMPTS")
        Log.d(TAG, "========================")
    }
}

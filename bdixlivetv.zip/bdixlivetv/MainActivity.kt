package com.shimulfp.bdixlivetv

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.google.gson.Gson
import com.shimulfp.bdixlivetv.components.downloads.DownloadsScreen
import com.shimulfp.bdixlivetv.components.series.SeriesDetailScreen
import com.shimulfp.bdixlivetv.components.series.SeriesScreen
import com.shimulfp.bdixlivetv.manager.DownloadManager
import com.shimulfp.bdixlivetv.Channel
import com.shimulfp.bdixlivetv.models.Episode
import com.shimulfp.bdixlivetv.RefreshCoordinator
import com.shimulfp.bdixlivetv.SyncConfig
import com.shimulfp.bdixlivetv.UnifiedSyncManager
import com.shimulfp.bdixlivetv.SeriesSyncService
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.models.MovieCategory
import com.shimulfp.bdixlivetv.models.Series
import com.shimulfp.bdixlivetv.models.SeriesCategory
import com.shimulfp.bdixlivetv.models.StreamUrl
import com.shimulfp.bdixlivetv.viewmodel.MovieViewModel
import com.shimulfp.bdixlivetv.viewmodel.SeriesViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.media3.common.util.UnstableApi
//import com.google.firebase.BuildConfig
import com.shimulfp.bdixlivetv.MovieSyncService
import com.shimulfp.bdixlivetv.AppUpdateManager
import com.shimulfp.bdixlivetv.models.AppUpdateInfo

enum class NavTarget {
    HOME,
    ALL_CONTENT,
    MOVIES,
    MOVIE_DETAIL,
    SERIES,
    SERIES_DETAIL,
    MOVIES_HINDI,
    MOVIES_SOUTH,
    MOVIES_HOLLYWOOD,
    SERIES_KOREAN,
    SEARCH,
    SETTINGS,
    DOWNLOADS,
    PYTHON_TEST
}

class MainActivity : ComponentActivity() {
    private lateinit var channelViewModel: ChannelViewModel
    private lateinit var updateViewModel: AppUpdateChecker
    private val gson = Gson()

    @UnstableApi
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        channelViewModel = ViewModelProvider(this)[ChannelViewModel::class.java]
        updateViewModel = ViewModelProvider(this)[AppUpdateChecker::class.java]

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        setRealFullscreen()

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                MainScreen(channelViewModel = channelViewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        ServerPingHelper.setAppForegroundState(true)
        ServerPingHelper.forceImmediateCheck(this)
        if (::updateViewModel.isInitialized) {
            updateViewModel.onReturnFromSettings(this)
        }
    }

    override fun onPause() {
        super.onPause()
        ServerPingHelper.setAppForegroundState(false)
    }

    private fun setRealFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    @UnstableApi
    @SuppressLint("CoroutineCreationDuringComposition", "ContextCastToActivity")
    @Composable
    fun MainScreen(channelViewModel: ChannelViewModel) {
        val context = LocalContext.current as MainActivity
        val updateViewModel: AppUpdateChecker = viewModel()

        val updateInfo by updateViewModel.updateInfo.collectAsState()
        val downloadState by updateViewModel.downloadState.collectAsState()
        val showDialog by updateViewModel.showDialog.collectAsState()

        var currentNav by remember { mutableStateOf(NavTarget.HOME) }
        var allChannels by remember { mutableStateOf(emptyList<Channel>()) }
        var bdixChannels by remember { mutableStateOf(emptyList<Channel>()) }
        var aynaChannels by remember { mutableStateOf(emptyList<Channel>()) }
        var isSyncing by remember { mutableStateOf(false) }
        var showExitDialog by remember { mutableStateOf(false) }
        var initialLoadComplete by remember { mutableStateOf(false) }
        var showDebugInfo by remember { mutableStateOf(false) }
        var pythonStatus by remember { mutableStateOf("Loading...") }
        var showPythonDebugDialog by remember { mutableStateOf(false) }
        var refreshTrigger by remember { mutableIntStateOf(0) }
        var isBdixAvailable by remember { mutableStateOf(false) }
        var isCheckingBdix by remember { mutableStateOf(false) }
        var bdixStatusMessage by remember { mutableStateOf("Checking...") }
        var cacheAgeMinutes by remember { mutableStateOf(0L) }

        var isBackgroundSyncing by remember { mutableStateOf(false) }
        var lastSyncStatus by remember { mutableStateOf<String?>(null) }
        var lastSyncTime by remember { mutableStateOf(0L) }
        var githubTokenAvailable by remember { mutableStateOf(false) }

        var selectedMovie by remember { mutableStateOf<Movie?>(null) }
        val movieViewModel: MovieViewModel = viewModel()
        val scope = rememberCoroutineScope()
        val allMovies by movieViewModel.allMovies.collectAsState()

        var selectedSeries by remember { mutableStateOf<Series?>(null) }
        val seriesViewModel: SeriesViewModel = viewModel()
        val allSeries by seriesViewModel.allSeries.collectAsState()
        var selectedSeriesCategory by remember { mutableStateOf(SeriesCategory.ALL) }
        var seriesSearchQuery by remember { mutableStateOf("") }
        var isLoadingSeries by remember { mutableStateOf(false) }

        val sportsViewModel: com.shimulfp.bdixlivetv.viewmodel.SportsViewModel = viewModel()

        fun loadSeries() {
            scope.launch {
                isLoadingSeries = true
                try {
                    seriesViewModel.loadAllSeries()
                } finally {
                    isLoadingSeries = false
                }
            }
        }

        LaunchedEffect(allChannels) {
            if (allChannels.isNotEmpty()) {
                channelViewModel.updateChannels(allChannels)
            }
        }

        LaunchedEffect(Unit) {
            ServerPingHelper.bdixStatus.collectLatest { status ->
                status?.let {
                    when (it) {
                        is ServerPingHelper.BdixStatus.Checking -> {
                            isCheckingBdix = true
                            bdixStatusMessage = "Checking BDIX servers..."
                        }
                        is ServerPingHelper.BdixStatus.Available -> {
                            isCheckingBdix = false
                            isBdixAvailable = true
                            bdixStatusMessage = "${it.reachableServers}/${it.totalServers} servers online"
                        }
                        is ServerPingHelper.BdixStatus.Unavailable -> {
                            isCheckingBdix = false
                            isBdixAvailable = false
                            bdixStatusMessage = "BDIX servers unavailable"
                        }
                        is ServerPingHelper.BdixStatus.BackgroundLimited -> {
                            isCheckingBdix = false
                            bdixStatusMessage = "Using cached status (background)"
                        }
                        ServerPingHelper.BdixStatus.Unknown -> {
                            isCheckingBdix = false
                            bdixStatusMessage = "Status unknown"
                        }
                    }
                } ?: run {
                    isCheckingBdix = false
                    bdixStatusMessage = "Status not initialized"
                }
            }
        }

        LaunchedEffect(Unit) {
            val firebaseManager = FirebaseManager(this@MainActivity)
            val token = firebaseManager.getGitHubToken()
            githubTokenAvailable = token.isNotEmpty()
            if (githubTokenAvailable) {
                GitHubDataManager.initialize(token)
            }
            val syncLogFile = File(this@MainActivity.filesDir, "github_sync_log.json")
            if (syncLogFile.exists()) {
                try {
                    val log = JSONObject(syncLogFile.readText())
                    lastSyncTime = log.optLong("last_sync_time", 0)
                } catch (_: Exception) { }
            }
        }

        LaunchedEffect(Unit, refreshTrigger) {
            if (initialLoadComplete && refreshTrigger == 0) return@LaunchedEffect

            isSyncing = true
            pythonStatus = "🔄 Loading channels..."

            FirebaseSetupHelper.initializeFirebase(this@MainActivity)

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    PythonScriptsDownloader.initialize(this@MainActivity)
                } catch (e: Exception) {
                    Log.e("SCRIPTS", "Scripts init error: ${e.message}")
                }
            }

            val firebaseManager = FirebaseManager(this@MainActivity)
            firebaseManager.fetchAndActivate()
            var username = firebaseManager.getAynaUsername()
            var password = firebaseManager.getAynaPassword()

            if (username == null || password == null || password!!.isEmpty()) {
                username = "username@email.com"
                password = ""
            }

            val cacheResult = ChannelCacheManager.loadChannelsWithSmartCache(
                context = this@MainActivity,
                username = username,
                password = password
            )

            allChannels = cacheResult.allChannels
            val (bdixList, aynaList) = ChannelCacheManager.separateChannelsBySource(allChannels)
            bdixChannels = bdixList
            aynaChannels = aynaList

            if (cacheResult.needsBackgroundRefresh) {
                CoroutineScope(Dispatchers.IO).launch {
                    pythonStatus = "🔄 Syncing channels..."
                    val firebaseManager = FirebaseManager(this@MainActivity)
                    val bgUsername = firebaseManager.getAynaUsername() ?: "username@email.com"
                    val bgPassword = firebaseManager.getAynaPassword() ?: ""

                    try {
                        val success = RefreshCoordinator.requestManualRefresh(
                            this@MainActivity,
                            bgUsername,
                            bgPassword
                        )
                        if (success) {
                            val newCacheResult = ChannelCacheManager.loadChannelsWithSmartCache(
                                context = this@MainActivity,
                                username = bgUsername,
                                password = bgPassword
                            )
                            allChannels = newCacheResult.allChannels
                            val (newBdixList, newAynaList) = ChannelCacheManager.separateChannelsBySource(allChannels)
                            bdixChannels = newBdixList
                            aynaChannels = newAynaList
                            channelViewModel.updateChannels(allChannels)
                            pythonStatus = "✅ Refresh completed"
                        } else {
                            Log.w("CHANNEL_LOADING", "⚠️ Background refresh skipped")
                        }
                    } catch (e: Exception) {
                        Log.e("CHANNEL_LOADING", "❌ Background refresh error: ${e.message}")
                    }
                }
            } else {
                pythonStatus = "✅ Channels loaded from ${cacheResult.source}"
            }

            val cacheFile = File(this@MainActivity.filesDir, "all_channels_cache.json")
            if (cacheFile.exists()) {
                cacheAgeMinutes = (System.currentTimeMillis() - cacheFile.lastModified()) / (60 * 1000)
            }

            pythonStatus = buildString {
                append("✅ ${allChannels.size} channels")
                val ageText = SyncConfig.getCacheAgeText(cacheAgeMinutes)
                if (cacheResult.isFromCache) {
                    append(" [Cached $ageText]")
                    if (cacheResult.needsBackgroundRefresh) {
                        append(" • Refreshing in background...")
                    }
                } else {
                    append(" [Live]")
                }
            }

            CoroutineScope(Dispatchers.IO).launch {
                ServerPingHelper.checkBdixServers(this@MainActivity)
            }

            isSyncing = false
            initialLoadComplete = true
            channelViewModel.updateChannels(allChannels)
        }

        LaunchedEffect(Unit) {
            if (allSeries.isEmpty()) {
                loadSeries()
            }
        }

        UnifiedSyncManager(
            context = this@MainActivity,
            allChannels = allChannels,
            onCacheAgeChanged = { ageMinutes -> cacheAgeMinutes = ageMinutes },
            onSyncStatusChanged = { status -> lastSyncStatus = status },
            onBackgroundSyncTriggered = { username, password ->
                val cacheIsOld = ChannelCacheManager.isCacheOlderThan(
                    context = this@MainActivity,
                    minutes = SyncConfig.getChannelCacheExpiryMinutes()
                )
                if (cacheIsOld) {
                    ChannelCacheManager.startBackgroundRefresh(this@MainActivity, username, password)
                }
            },
            onAutoRefreshTriggered = { },
            onSportsDataUpdated = {
                // Reload sports data when sync manager triggers an update
                CoroutineScope(Dispatchers.IO).launch {
                    sportsViewModel.loadSportsData(this@MainActivity)
                }
            }
        )

        LaunchedEffect(Unit) {
            delay(2000)
            updateViewModel.checkForUpdates(this@MainActivity, force = false)
        }

        if (showDialog && updateInfo != null) {
            AppUpdateManager.UpdateDialog(
                updateInfo = updateInfo!!,
                downloadState = downloadState,
                onDismiss = { updateViewModel.dismissDialog() },
                onConfirmDownload = { updateViewModel.startDownload(this@MainActivity) },
                onInstall = { updateViewModel.installDownloadedApk(this@MainActivity) }
            )
        }

        BackHandler {
            when (currentNav) {
                NavTarget.MOVIE_DETAIL -> {
                    currentNav = NavTarget.MOVIES
                    selectedMovie = null
                }
                NavTarget.MOVIES, NavTarget.MOVIES_HINDI, NavTarget.MOVIES_SOUTH, NavTarget.MOVIES_HOLLYWOOD -> {
                    currentNav = NavTarget.HOME
                }
                NavTarget.SERIES -> {
                    currentNav = NavTarget.HOME
                    selectedSeries = null
                }
                NavTarget.SERIES_DETAIL -> {
                    currentNav = NavTarget.SERIES
                    selectedSeries = null
                }
                NavTarget.DOWNLOADS, NavTarget.PYTHON_TEST, NavTarget.SEARCH, NavTarget.SETTINGS -> {
                    currentNav = NavTarget.HOME
                }
                else -> showExitDialog = true
            }
        }

        if (showExitDialog) {
            AlertDialog(
                onDismissRequest = { showExitDialog = false },
                title = { Text("Exit App") },
                text = { Text("Are you sure you want to exit?") },
                confirmButton = {
                    TextButton(onClick = { context.finish() }) {
                        Text("Exit", color = Color.Red)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showExitDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        if (showPythonDebugDialog) {
            AlertDialog(
                onDismissRequest = { showPythonDebugDialog = false },
                title = { Text("Python Debug Info") },
                text = {
                    Column {
                        Text(
                            "Status: $pythonStatus",
                            color = when {
                                pythonStatus.contains("✅") -> Color.Green
                                pythonStatus.contains("⚠️") -> Color.Yellow
                                pythonStatus.contains("❌") -> Color.Red
                                else -> Color.White
                            }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Channels Loaded: ${allChannels.size}", color = if (allChannels.isNotEmpty()) Color.Green else Color.Red)
                        Text("BDIX Available: $isBdixAvailable", color = if (isBdixAvailable) Color.Green else Color.Red)
                        Text("BDIX Status: $bdixStatusMessage", color = Color.Gray)
                        Text("Cache Age: ${cacheAgeMinutes} minutes", color = if (cacheAgeMinutes > 2) Color.Yellow else Color.Green)
                        if (githubTokenAvailable) {
                            Text("GitHub Sync: Enabled", color = Color.Green)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showPythonDebugDialog = false }) {
                        Text("Close")
                    }
                }
            )
        }

        Column(
            Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0A0A))
        ) {
            if (currentNav == NavTarget.HOME) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .background(Color(0xFF111111))
                        .padding(horizontal = 16.dp, vertical = 20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("BDIX TV", color = Color.Red, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("Watch Live TV, Movies & Series", color = Color.White, fontSize = 12.sp)
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TopNavItem(
                                "Downloads",
                                Icons.Filled.Download,
                                selected = currentNav == NavTarget.DOWNLOADS
                            ) {
                                currentNav = NavTarget.DOWNLOADS
                            }
                            TopNavItem(
                                "Search",
                                Icons.Filled.Search,
                                selected = currentNav == NavTarget.SEARCH
                            ) {
                                currentNav = NavTarget.SEARCH
                            }
                            TopNavItem(
                                "Settings",
                                Icons.Filled.Settings,
                                selected = currentNav == NavTarget.SETTINGS
                            ) {
                                currentNav = NavTarget.SETTINGS
                            }
                        }
                    }
                }
            }

            Box(
                Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                when (currentNav) {
                    NavTarget.HOME -> HomeContent(
                        bdixChannels = bdixChannels,
                        aynaChannels = aynaChannels,
                        allChannels = allChannels,
                        isSyncing = isSyncing,
                        showDebugInfo = showDebugInfo,
                        pythonStatus = pythonStatus,
                        isBdixAvailable = isBdixAvailable,
                        isCheckingBdix = isCheckingBdix,
                        bdixStatusMessage = bdixStatusMessage,
                        cacheAgeMinutes = cacheAgeMinutes,
                        githubTokenAvailable = githubTokenAvailable,
                        isBackgroundSyncing = isBackgroundSyncing,
                        lastSyncStatus = lastSyncStatus,
                        lastSyncTime = lastSyncTime,
                        onToggleDebugInfo = { showDebugInfo = !showDebugInfo },
                        onRefreshChannels = { refreshTrigger++ },
                        onManualRefresh = {
                            scope.launch {
                                val firebaseManager = FirebaseManager(this@MainActivity)
                                val username = firebaseManager.getAynaUsername() ?: "username@email.com"
                                val password = firebaseManager.getAynaPassword() ?: ""
                                val success = RefreshCoordinator.requestManualRefresh(
                                    this@MainActivity,
                                    username,
                                    password
                                )
                                if (success) {
                                    val cacheResult = ChannelCacheManager.loadChannelsWithSmartCache(
                                        context = this@MainActivity,
                                        username = username,
                                        password = password
                                    )
                                    allChannels = cacheResult.allChannels
                                    val (bdixList, aynaList) = ChannelCacheManager.separateChannelsBySource(allChannels)
                                    bdixChannels = bdixList
                                    aynaChannels = aynaList
                                    channelViewModel.updateChannels(allChannels)
                                    pythonStatus = "✅ Refresh completed"
                                } else {
                                    pythonStatus = "⚠️ Refresh skipped"
                                }
                            }
                        },
                        onRetryBdixCheck = {
                            CoroutineScope(Dispatchers.IO).launch {
                                ServerPingHelper.forceImmediateCheck(context)
                            }
                        },
                        onManualSync = {
                            scope.launch {
                                val firebaseManager = FirebaseManager(this@MainActivity)
                                val token = firebaseManager.getGitHubToken()
                                if (token.isNotEmpty()) {
                                    GitHubDataManager.initialize(token)
                                    val result = GitHubDataManager.checkAndSyncData(this@MainActivity)
                                    saveSyncLog(this@MainActivity, result)
                                    lastSyncStatus = when (result) {
                                        is GitHubDataManager.SyncResult.NoToken -> "⚠️ No GitHub token"
                                        is GitHubDataManager.SyncResult.Downloaded -> "✅ Using GitHub data (${result.ageMinutes}m old)"
                                        is GitHubDataManager.SyncResult.ScrapedAndUploaded -> "✅ Fresh data scraped & uploaded (${result.channelCount} channels)"
                                        is GitHubDataManager.SyncResult.ScrapedOnly -> "✅ Fresh data scraped (${result.channelCount} channels)"
                                        is GitHubDataManager.SyncResult.ScrapingFailed -> "❌ Scraping failed"
                                        is GitHubDataManager.SyncResult.Error -> "⚠️ Sync error: ${result.message}"
                                    }
                                } else {
                                    lastSyncStatus = "⚠️ GitHub token not available"
                                    githubTokenAvailable = false
                                }

                                try {
                                    val seriesResult = SeriesSyncService.syncSeries(this@MainActivity)
                                    when (seriesResult) {
                                        is SeriesSyncService.SyncResult.GitHubDownload -> Log.d("SERIES_SYNC", "Downloaded ${seriesResult.count} series")
                                        is SeriesSyncService.SyncResult.ScrapedAndUploaded -> Log.d("SERIES_SYNC", "Scraped and uploaded ${seriesResult.count} series")
                                        is SeriesSyncService.SyncResult.ScrapedOnly -> Log.d("SERIES_SYNC", "Scraped ${seriesResult.count} series")
                                        is SeriesSyncService.SyncResult.ScrapingFailed -> Log.d("SERIES_SYNC", "Series scraping failed")
                                        is SeriesSyncService.SyncResult.Error -> Log.e("SERIES_SYNC", "Series sync error: ${seriesResult.message}")
                                        else -> { }
                                    }
                                } catch (e: Exception) {
                                    Log.e("SERIES_SYNC", "Series sync error: ${e.message}")
                                }

                                try {
                                    val movieResult = MovieSyncService.syncMovies(this@MainActivity)
                                    when (movieResult) {
                                        is MovieSyncService.SyncResult.GitHubDownload -> Log.d("MOVIE_SYNC", "Downloaded ${movieResult.count} movies")
                                        is MovieSyncService.SyncResult.ScrapedAndUploaded -> Log.d("MOVIE_SYNC", "Scraped and uploaded ${movieResult.count} movies")
                                        is MovieSyncService.SyncResult.ScrapedOnly -> Log.d("MOVIE_SYNC", "Scraped ${movieResult.count} movies")
                                        is MovieSyncService.SyncResult.ScrapingFailed -> Log.d("MOVIE_SYNC", "Movie scraping failed")
                                        is MovieSyncService.SyncResult.Error -> Log.e("MOVIE_SYNC", "Movie sync error: ${movieResult.message}")
                                        else -> { }
                                    }
                                } catch (e: Exception) {
                                    Log.e("MOVIE_SYNC", "Movie sync error: ${e.message}")
                                }
                            }
                        },
                        onMoviesClick = { currentNav = NavTarget.MOVIES },
                        onMovieClick = { movie ->
                            selectedMovie = movie
                            currentNav = NavTarget.MOVIE_DETAIL
                        },
                        onMoviePlayClick = { movie -> launchMoviePlayer(movie) },
                        onSeriesClick = { currentNav = NavTarget.SERIES },
                        onSeriesItemClick = { series ->
                            selectedSeries = series
                            currentNav = NavTarget.SERIES_DETAIL
                        },
                        onLiveTvClick = { playLastWatched(context, allChannels) },
                        movieViewModel = movieViewModel,
                        seriesViewModel = seriesViewModel,
                        sportsViewModel = sportsViewModel
                    )

                    NavTarget.ALL_CONTENT -> FullGridContent("All Content", allChannels)

                    NavTarget.MOVIES -> {
                        MoviesScreen(
                            viewModel = movieViewModel,
                            onMovieClick = { movie ->
                                selectedMovie = movie
                                currentNav = NavTarget.MOVIE_DETAIL
                            },
                            onMovieDetailClick = { movie ->
                                selectedMovie = movie
                                currentNav = NavTarget.MOVIE_DETAIL
                            },
                            onBack = { currentNav = NavTarget.HOME }
                        )
                    }

                    NavTarget.MOVIE_DETAIL -> {
                        selectedMovie?.let { movie ->
                            MovieDetailScreen(
                                movie = movie,
                                isFavorite = movieViewModel.isFavorite(movie.id),
                                relatedMovies = movieViewModel.getRelatedMovies(movie),
                                onPlayClick = { streamUrl -> launchMoviePlayer(movie, streamUrl) },
                                onBackClick = {
                                    currentNav = NavTarget.MOVIES
                                    selectedMovie = null
                                },
                                onFavoriteClick = { movieViewModel.toggleFavorite(movie) },
                                onRelatedMovieClick = { related -> selectedMovie = related }
                            )
                        } ?: run { currentNav = NavTarget.MOVIES }
                    }

                    NavTarget.MOVIES_HINDI, NavTarget.MOVIES_SOUTH, NavTarget.MOVIES_HOLLYWOOD -> {
                        MoviesScreen(
                            viewModel = movieViewModel,
                            onMovieClick = { movie ->
                                selectedMovie = movie
                                currentNav = NavTarget.MOVIE_DETAIL
                            },
                            onMovieDetailClick = { movie ->
                                selectedMovie = movie
                                currentNav = NavTarget.MOVIE_DETAIL
                            },
                            onBack = { currentNav = NavTarget.HOME }
                        )
                    }

                    NavTarget.SERIES_KOREAN -> FullGridContent("Korean Series", emptyList())

                    NavTarget.SEARCH -> SearchScreen(
                        movieViewModel = movieViewModel,
                        onMovieClick = { movie ->
                            selectedMovie = movie
                            currentNav = NavTarget.MOVIE_DETAIL
                        },
                        onChannelClick = { index, channels -> launchPlayer(index, channels) },
                        allChannels = allChannels,
                        onBack = { currentNav = NavTarget.HOME }
                    )

                    NavTarget.SETTINGS -> SettingsContent(
                        onRefresh = { refreshTrigger++ },
                        githubTokenAvailable = githubTokenAvailable,
                        isBackgroundSyncing = isBackgroundSyncing,
                        lastSyncStatus = lastSyncStatus,
                        lastSyncTime = lastSyncTime,
                        movieViewModel = movieViewModel,
                        onBack = { currentNav = NavTarget.HOME },
                        updateViewModel = updateViewModel
                    )

                    NavTarget.DOWNLOADS -> DownloadsScreen(
                        onBack = { currentNav = NavTarget.HOME },
                        onPlayDownload = { filePath ->
                            val file = java.io.File(filePath)
                            if (file.exists()) {
                                try {
                                    val uri = androidx.core.content.FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        file
                                    )
                                    val intent = Intent(context, MoviePlayerActivity::class.java).apply {
                                        putExtra("MOVIE_URL", uri.toString())
                                        putExtra("MOVIE_TITLE", file.nameWithoutExtension)
                                        putExtra("MOVIE_ID", file.nameWithoutExtension)
                                        putExtra("MOVIE_QUALITY", "Offline")
                                        flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Log.w("DOWNLOADS", "FileProvider failed: ${e.message}")
                                    val oldPolicy = android.os.StrictMode.getVmPolicy()
                                    try {
                                        android.os.StrictMode.setVmPolicy(
                                            android.os.StrictMode.VmPolicy.Builder().build()
                                        )
                                        val fileUri = android.net.Uri.fromFile(file)
                                        val intent = Intent(context, MoviePlayerActivity::class.java).apply {
                                            putExtra("MOVIE_URL", fileUri.toString())
                                            putExtra("MOVIE_TITLE", file.nameWithoutExtension)
                                            putExtra("MOVIE_ID", file.nameWithoutExtension)
                                            putExtra("MOVIE_QUALITY", "Offline")
                                        }
                                        context.startActivity(intent)
                                    } catch (e2: Exception) {
                                        Log.e("DOWNLOADS", "Failed to play video: ${e2.message}", e2)
                                        android.widget.Toast.makeText(
                                            context,
                                            "Error playing video. Please restart the app.",
                                            android.widget.Toast.LENGTH_LONG
                                        ).show()
                                    } finally {
                                        android.os.StrictMode.setVmPolicy(oldPolicy)
                                    }
                                }
                            }
                        },
                        onResumeDownload = { download ->
                            scope.launch {
                                try {
                                    val movie = allMovies.find { it.id == download.movieId }
                                    if (movie != null && download.quality < movie.streamUrls.size) {
                                        val streamUrl = movie.streamUrls[download.quality]
                                        DownloadManager.getInstance(context).resumeDownload(
                                            download.id, movie, streamUrl, download.quality
                                        )
                                    }
                                } catch (e: Exception) {
                                    Log.e("DOWNLOADS", "Error resuming download: ${e.message}", e)
                                }
                            }
                        },
                        onRetryDownload = { download ->
                            scope.launch {
                                try {
                                    val movie = allMovies.find { it.id == download.movieId }
                                    if (movie != null && download.quality < movie.streamUrls.size) {
                                        val streamUrl = movie.streamUrls[download.quality]
                                        DownloadManager.getInstance(context).retryDownload(
                                            download.id, movie, streamUrl, download.quality
                                        )
                                    }
                                } catch (e: Exception) {
                                    Log.e("DOWNLOADS", "Error retrying download: ${e.message}", e)
                                }
                            }
                        }
                    )

                    NavTarget.SERIES -> SeriesScreen(
                        series = allSeries,
                        onSeriesClick = { series ->
                            selectedSeries = series
                            currentNav = NavTarget.SERIES_DETAIL
                        },
                        onBack = { currentNav = NavTarget.HOME },
                        selectedCategory = selectedSeriesCategory,
                        onCategoryChange = { category ->
                            selectedSeriesCategory = category
                            seriesViewModel.filterByCategory(category)
                        },
                        searchQuery = seriesSearchQuery,
                        onSearchChange = { query ->
                            seriesSearchQuery = query
                            seriesViewModel.searchSeries(query)
                        },
                        isLoading = isLoadingSeries
                    )

                    NavTarget.SERIES_DETAIL -> selectedSeries?.let { series ->
                        SeriesDetailScreen(
                            series = series,
                            onBack = { currentNav = NavTarget.SERIES },
                            onEpisodeClick = { episode -> playSeriesEpisode(episode, series) },
                            onSeasonClick = { }
                        )
                    } ?: Box(Modifier.fillMaxSize(), Alignment.Center) {
                        Text("Series not found", color = Color.White, fontSize = 18.sp)
                    }

                    NavTarget.PYTHON_TEST -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Python Test", color = Color.White, fontSize = 24.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(pythonStatus, color = Color.Gray)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    CoroutineScope(Dispatchers.IO).launch {
                                        pythonStatus = if (PythonHelper.testPython(context)) "✅ Python working!" else "❌ Python failed"
                                    }
                                }
                            ) {
                                Text("Test Python")
                            }
                        }
                    }
                }
            }
        }
    }

    // ───────────────────── Search Screen (unchanged, but ensure no redundant .focusable) ─────────────────────
    @Composable
    fun SearchScreen(
        movieViewModel: MovieViewModel,
        onMovieClick: (Movie) -> Unit,
        onChannelClick: (Int, List<Channel>) -> Unit,
        allChannels: List<Channel>,
        onBack: () -> Unit
    ) {
        var searchQuery by remember { mutableStateOf("") }
        val searchResults by movieViewModel.searchResults.collectAsState()

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0A0A))
        ) {
            // Back button – non‑focusable
            Box(
                modifier = Modifier
                    .padding(16.dp)
                    .align(Alignment.TopStart)
                    .size(48.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    .clickable(
                        onClick = onBack,
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    )
                    .focusable(false),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .padding(top = 60.dp)
            ) {
                Text("Search", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        movieViewModel.search(it)
                    },
                    label = { Text("Search movies and channels...") },
                    leadingIcon = { Icon(Icons.Filled.Search, null, tint = Color.Gray) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = {
                                searchQuery = ""
                                movieViewModel.clearSearch()
                            }) {
                                Icon(Icons.Filled.Clear, null, tint = Color.Gray)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Red,
                        unfocusedBorderColor = Color.Gray,
                        focusedLabelColor = Color.Red
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(16.dp))

                if (searchQuery.isNotEmpty()) {
                    LazyColumn {
                        if (searchResults.isNotEmpty()) {
                            item {
                                Text(
                                    "Movies (${searchResults.size})",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                            items(searchResults.take(10), key = { it.id }) { movie ->
                                MovieSearchResultItem(movie = movie, onClick = { onMovieClick(movie) })
                            }
                        }

                        val channelResults = allChannels.filter {
                            it.name.contains(searchQuery, ignoreCase = true)
                        }
                        if (channelResults.isNotEmpty()) {
                            item {
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    "Channels (${channelResults.size})",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                            itemsIndexed(channelResults.take(10)) { index, channel ->
                                ChannelSearchResultItem(
                                    channel = channel,
                                    onClick = { onChannelClick(index, channelResults) }
                                )
                            }
                        }

                        if (searchResults.isEmpty() && channelResults.isEmpty()) {
                            item {
                                Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) {
                                    Text("No results found", color = Color.Gray)
                                }
                            }
                        }
                    }
                } else {
                    Box(Modifier.fillMaxSize(), Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.Search, null, tint = Color.Gray, modifier = Modifier.size(64.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Search for movies and channels", color = Color.Gray)
                        }
                    }
                }
            }
        }
    }

    @Composable
    fun MovieSearchResultItem(movie: Movie, onClick: () -> Unit) {
        Card(
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
        ) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(60.dp, 90.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF2A2A2A))
                ) {
                    if (!movie.poster.isNullOrEmpty()) {
                        AsyncImage(
                            model = movie.poster,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(Icons.Filled.Movie, null, tint = Color.Gray, modifier = Modifier.align(Alignment.Center))
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(movie.title, color = Color.White, fontWeight = FontWeight.Medium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                        Text(movie.year, color = Color.Gray, fontSize = 12.sp)
                        Text(movie.quality, color = Color.Green, fontSize = 12.sp)
                        Text(movie.language, color = Color.Cyan, fontSize = 12.sp)
                    }
                    Text(movie.category.displayName, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }
                Icon(Icons.Filled.PlayCircle, null, tint = Color.Red)
            }
        }
    }

    @Composable
    fun ChannelSearchResultItem(channel: Channel, onClick: () -> Unit) {
        Card(
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
        ) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(50.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF2A2A2A)),
                    contentAlignment = Alignment.Center
                ) {
                    if (!channel.logo.isNullOrEmpty()) {
                        AsyncImage(
                            model = channel.logo,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize().padding(4.dp),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Text(channel.name.take(2), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(channel.name, color = Color.White, fontWeight = FontWeight.Medium)
                    Text("${channel.urls.size} servers • ${channel.source}", color = Color.Gray, fontSize = 12.sp)
                }
                Icon(Icons.Filled.LiveTv, null, tint = Color.Magenta)
            }
        }
    }

    // ───────────────────── Settings ─────────────────────
    @Composable
    fun SettingsContent(
        onRefresh: () -> Unit,
        githubTokenAvailable: Boolean,
        isBackgroundSyncing: Boolean,
        lastSyncStatus: String?,
        lastSyncTime: Long,
        movieViewModel: MovieViewModel? = null,
        onBack: () -> Unit,
        updateViewModel: AppUpdateChecker
    ) {
        val context = LocalContext.current as MainActivity
        val firebaseManager = remember { FirebaseManager(context) }
        var username by remember { mutableStateOf(firebaseManager.getAynaUsername() ?: "") }
        var password by remember { mutableStateOf("") }
        var deviceId by remember { mutableStateOf(firebaseManager.getDeviceId()) }
        var showPassword by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf<String?>(null) }
        var isSaving by remember { mutableStateOf(false) }
        var cacheStatus by remember { mutableStateOf<ChannelCacheManager.CacheStatus?>(null) }
        var serverStatus by remember { mutableStateOf("Checking...") }
        var isCheckingServers by remember { mutableStateOf(false) }
        var movieCacheInfo by remember { mutableStateOf<String?>(null) }

        LaunchedEffect(Unit) {
            cacheStatus = ChannelCacheManager.getCacheStatus(context)
            isCheckingServers = true
            CoroutineScope(Dispatchers.IO).launch {
                val isReachable = ServerPingHelper.quickCheck(context)
                serverStatus = if (isReachable) "✅ All servers reachable" else "❌ Some servers offline"
                isCheckingServers = false
            }
            movieViewModel?.let {
                val info = it.getCacheInfo()
                movieCacheInfo = if (info.exists) "Movies: ${info.sizeKb}KB, ${info.ageMinutes}m old" else "Movies: No cache"
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0A0A))
        ) {
            // Back button – non‑focusable
            Box(
                modifier = Modifier
                    .padding(16.dp)
                    .align(Alignment.TopStart)
                    .size(48.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    .clickable(
                        onClick = onBack,
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    )
                    .focusable(false),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .padding(top = 60.dp)
            ) {
                item {
                    Text("Settings", style = MaterialTheme.typography.headlineMedium, color = Color.White, modifier = Modifier.padding(bottom = 24.dp))
                }

                // Python scripts card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Scripts Auto-Update", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            var scriptsStatus by remember { mutableStateOf("Loading...") }
                            var isUpdating by remember { mutableStateOf(false) }
                            LaunchedEffect(Unit) { scriptsStatus = PythonScriptsDownloader.getStatusInfo(context) }
                            Text("GitHub: /BDIX-TV/scripts", color = Color.Cyan, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(scriptsStatus, color = Color.Gray, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(
                                    onClick = {
                                        isUpdating = true
                                        CoroutineScope(Dispatchers.IO).launch {
                                            val updated = PythonScriptsDownloader.forceUpdate(context)
                                            scriptsStatus = if (updated) "✅ Updated from GitHub!" else "❌ Update failed"
                                            isUpdating = false
                                            PythonHelper.resetPythonState()
                                        }
                                    },
                                    enabled = !isUpdating,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Green)
                                ) {
                                    if (isUpdating) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Updating...")
                                    } else {
                                        Icon(Icons.Filled.Update, null, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Update Now")
                                    }
                                }
                                Button(
                                    onClick = {
                                        PythonScriptsDownloader.clearScripts(context)
                                        PythonHelper.resetPythonState()
                                        scriptsStatus = "🧹 Scripts cleared. Will auto-download on next use."
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                                ) {
                                    Icon(Icons.Filled.Delete, null, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Clear All")
                                }
                            }
                        }
                    }
                }

                // App Updates card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("App Updates", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Icon(Icons.Filled.SystemUpdate, null, tint = Color(0xFF4CAF50))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Current Version: ${BuildConfig.VERSION_NAME}", color = Color.Gray, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { updateViewModel.checkForUpdates(context, force = true) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.Refresh, null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Check for Updates")
                            }
                        }
                    }
                }

                // Movie cache card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Movie Cache", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Button(
                                    onClick = {
                                        movieViewModel?.clearCacheAndReload()
                                        message = "✅ Movie cache cleared"
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("Clear", fontSize = 12.sp)
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(movieCacheInfo ?: "Loading...", color = Color.Gray, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { movieViewModel?.loadMoviesWithGitHubSync(forceRefresh = true) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
                            ) {
                                Icon(Icons.Filled.Refresh, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Refresh Movies")
                            }
                        }
                    }
                }

                // Server status
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Server Status", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                if (isCheckingServers) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                } else {
                                    Button(
                                        onClick = {
                                            CoroutineScope(Dispatchers.IO).launch {
                                                isCheckingServers = true
                                                serverStatus = if (ServerPingHelper.quickCheck(context)) "✅ All servers reachable" else "❌ Some servers offline"
                                                isCheckingServers = false
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.Blue),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("Re-check", fontSize = 12.sp)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(serverStatus, color = when {
                                serverStatus.contains("✅") -> Color.Green
                                serverStatus.contains("❌") -> Color.Red
                                else -> Color.Yellow
                            }, fontSize = 14.sp)
                        }
                    }
                }

                // Channel cache card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Channel Cache", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Button(
                                    onClick = {
                                        CoroutineScope(Dispatchers.IO).launch {
                                            ChannelCacheManager.clearAllCache(context)
                                            cacheStatus = ChannelCacheManager.getCacheStatus(context)
                                            message = "✅ All cache cleared"
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("Clear All", fontSize = 12.sp)
                                }
                            }
                            cacheStatus?.combinedCache?.let { cache ->
                                val timeAgo = formatTimeAgo(cache.lastUpdated)
                                Text("Combined: ${cache.channelCount} channels", color = if (cache.isExpired) Color.Yellow else Color.Green, fontSize = 14.sp)
                                Text("Updated: $timeAgo ${if (cache.isExpired) "(Expired)" else "(Fresh)"}", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // AynaOTT credentials
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("OTT Credentials", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 16.dp))
                            OutlinedTextField(
                                value = "username@email.com",
                                onValueChange = { username = it },
                                label = { Text("Email/Username") },
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Red, unfocusedBorderColor = Color.Gray),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it },
                                label = { Text("Password") },
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Red, unfocusedBorderColor = Color.Gray),
                                visualTransformation = if (showPassword) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { showPassword = !showPassword }) {
                                        Icon(if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null, tint = Color.Gray)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(
                                    onClick = {
                                        if (username.isEmpty() || password.isEmpty()) {
                                            message = "Please enter both username and password"
                                            return@Button
                                        }
                                        isSaving = true
                                        firebaseManager.saveAynaCredentials(username, password)
                                        message = "✅ Credentials saved locally"
                                        isSaving = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Blue),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(if (isSaving) "Saving..." else "Save")
                                }
                                Button(
                                    onClick = {
                                        onRefresh()
                                        message = "✅ Refreshing channels..."
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Refresh Channels")
                                }
                            }
                            if (!message.isNullOrEmpty()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(message!!, color = if (message!!.contains("✅")) Color.Green else Color.Red, fontSize = 14.sp)
                            }
                        }
                    }
                }

                // App info
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("App Information", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("BDIX TV App", color = Color.Gray, fontSize = 14.sp)
                            Text("Version ${BuildConfig.VERSION_NAME}", color = Color.Gray, fontSize = 14.sp)
                            //Text("Python 3.8 with Chaquopy", color = Color.Gray, fontSize = 14.sp)
                            Text("Sources: Public BDIX servers", color = Color.Gray, fontSize = 14.sp)
                            Text("Movie/Series Servers: DHAKA-FLIX", color = Color.Gray, fontSize = 14.sp)
                            //Text("Device ID: $deviceId", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    // ───────────────────── Home Content ─────────────────────
    @Composable
    fun HomeContent(
        bdixChannels: List<Channel>,
        aynaChannels: List<Channel>,
        allChannels: List<Channel>,
        isSyncing: Boolean,
        showDebugInfo: Boolean,
        pythonStatus: String,
        isBdixAvailable: Boolean,
        isCheckingBdix: Boolean,
        bdixStatusMessage: String,
        cacheAgeMinutes: Long,
        githubTokenAvailable: Boolean,
        isBackgroundSyncing: Boolean,
        lastSyncStatus: String?,
        lastSyncTime: Long,
        onToggleDebugInfo: () -> Unit,
        onRefreshChannels: () -> Unit,
        onManualRefresh: () -> Unit,
        onRetryBdixCheck: () -> Unit,
        onManualSync: () -> Unit,
        onMoviesClick: () -> Unit,
        onMovieClick: (Movie) -> Unit,
        onMoviePlayClick: (Movie) -> Unit,
        onSeriesClick: () -> Unit,
        onSeriesItemClick: (Series) -> Unit,
        onLiveTvClick: () -> Unit,
        movieViewModel: MovieViewModel,
        seriesViewModel: SeriesViewModel,
        sportsViewModel: com.shimulfp.bdixlivetv.viewmodel.SportsViewModel
    ) {
        LazyColumn(Modifier.fillMaxSize()) {
            // Movies / Series / LiveTV cards
            item {
                var moviesFocused by remember { mutableStateOf(false) }
                var seriesFocused by remember { mutableStateOf(false) }
                var liveTvFocused by remember { mutableStateOf(false) }

                val moviesScale by animateFloatAsState(if (moviesFocused) 1.05f else 1f, tween(150))
                val seriesScale by animateFloatAsState(if (seriesFocused) 1.05f else 1f, tween(150))
                val liveTvScale by animateFloatAsState(if (liveTvFocused) 1.05f else 1f, tween(150))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        onClick = onMoviesClick,
                        modifier = Modifier
                            .weight(1f)
                            .scale(moviesScale)
                            .border(
                                width = if (moviesFocused) 3.dp else 1.dp,
                                color = if (moviesFocused) Color.Red else Color(0xFF333333),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .onFocusChanged { moviesFocused = it.isFocused },
                        colors = CardDefaults.cardColors(
                            containerColor = if (moviesFocused) Color(0xFF2A2A2A) else Color(0xFF1A1A1A)
                        )
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Movie, null, tint = Color.Red, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Movies", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("Watch HD Movies", color = if (moviesFocused) Color.White else Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }

                    Card(
                        onClick = onSeriesClick,
                        modifier = Modifier
                            .weight(1f)
                            .scale(seriesScale)
                            .border(
                                width = if (seriesFocused) 3.dp else 1.dp,
                                color = if (seriesFocused) Color(0xFF9C27B0) else Color(0xFF333333),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .onFocusChanged { seriesFocused = it.isFocused },
                        colors = CardDefaults.cardColors(
                            containerColor = if (seriesFocused) Color(0xFF2A2A2A) else Color(0xFF1A1A1A)
                        )
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.LiveTv, null, tint = Color(0xFF9C27B0), modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Series", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("Watch TV Series", color = if (seriesFocused) Color.White else Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }

                    Card(
                        onClick = onLiveTvClick,
                        modifier = Modifier
                            .weight(1f)
                            .scale(liveTvScale)
                            .border(
                                width = if (liveTvFocused) 3.dp else 1.dp,
                                color = if (liveTvFocused) Color.Magenta else Color(0xFF333333),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .onFocusChanged { liveTvFocused = it.isFocused },
                        colors = CardDefaults.cardColors(
                            containerColor = if (liveTvFocused) Color(0xFF2A2A2A) else Color(0xFF1A1A1A)
                        )
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Tv, null, tint = Color.Magenta, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Live TV", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("Live Channels", color = if (liveTvFocused) Color.White else Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Channel status bar
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 20.dp)
                        .background(
                            when {
                                !isBdixAvailable && bdixChannels.isNotEmpty() -> Color.Yellow.copy(alpha = 0.1f)
                                isSyncing -> Color.Blue.copy(alpha = 0.1f)
                                else -> Color.Green.copy(alpha = 0.1f)
                            },
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            1.dp,
                            when {
                                !isBdixAvailable && bdixChannels.isNotEmpty() -> Color.Yellow
                                isSyncing -> Color.Blue
                                else -> Color.Green
                            },
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { onToggleDebugInfo() }
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("Channel Status", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(pythonStatus, color = when {
                                    !isBdixAvailable && bdixChannels.isNotEmpty() -> Color.Yellow
                                    isSyncing -> Color.Blue
                                    else -> Color.Green
                                }, fontSize = 12.sp)
                            }
                            Row {
                                if (isCheckingBdix) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                IconButton(onClick = onManualRefresh, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Filled.Refresh, "Refresh", tint = Color.White)
                                }
                            }
                        }
                    }
                }
            }

            if (isSyncing) {
                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .background(Color.Green.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                            CircularProgressIndicator(color = Color.Green, strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Loading channels...", color = Color.Green, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Live TV Channels
            item {
                if (allChannels.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Live TV Channels", color = Color.Cyan, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (bdixChannels.isNotEmpty()) {
                                Surface(color = Color(0xFF00BCD4), shape = RoundedCornerShape(12.dp)) {
                                    Text("BDIX: ${bdixChannels.size}", color = Color.Black, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                }
                            }
                            if (aynaChannels.isNotEmpty()) {
                                Surface(color = Color(0xFFE91E63), shape = RoundedCornerShape(12.dp)) {
                                    Text("Premium: ${aynaChannels.size}", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                }
                            }
                        }
                    }
                    ChannelRow(channels = allChannels, channelColor = Color.Cyan, sourceName = "All Sources", isEnabled = true)
                }
            }

            // Live Sports Events Section
            item {
                val ctx = LocalContext.current

                // Load sports data on component mount
                LaunchedEffect(Unit) {
                    sportsViewModel.loadSportsData(ctx)
                }

                com.shimulfp.bdixlivetv.components.sports.SportsSection(
                    viewModel = sportsViewModel,
                    onEventClick = { clickedEvent ->
                        Log.d("SPORTS", "Sports event clicked: ${clickedEvent.title} with ${clickedEvent.streamUrls.size} URLs")

                        // Convert ALL live sports events to Channels and show them in player ribbon
                        val allLiveEvents = sportsViewModel.liveEvents.value
                        val sportsChannels = allLiveEvents.map { event ->
                            Channel(
                                name = event.title,
                                urls = event.streamUrls,  // All validated URLs (BD, IN, etc.)
                                logo = event.thumbnail,
                                category = event.sport,
                                source = "Sports"
                            )
                        }

                        if (sportsChannels.isNotEmpty()) {
                            // Find the index of the clicked event
                            val clickedIndex = allLiveEvents.indexOf(clickedEvent)
                            val safeIndex = if (clickedIndex >= 0) clickedIndex else 0
                            launchPlayer(safeIndex, sportsChannels)
                        } else {
                            Log.e("SPORTS", "No live sports events available to play")
                        }
                    }
                )
            }

            // Continue Watching
            item {
                ContinueWatchingSection(
                    movieViewModel = movieViewModel,
                    seriesViewModel = seriesViewModel,
                    onMovieClick = onMovieClick,
                    onMoviePlayClick = onMoviePlayClick,
                    onSeriesItemClick = onSeriesItemClick
                )
            }

            // Movies preview row
            item {
                val recentMovies by movieViewModel.recentlyAdded.collectAsState()
                LaunchedEffect(Unit) { movieViewModel.loadMoviesWithGitHubSync() }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("🎬 Movies", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    var moviesSeeAllFocused by remember { mutableStateOf(false) }
                    val moviesSeeAllScale by animateFloatAsState(if (moviesSeeAllFocused) 1.05f else 1f, tween(150))
                    TextButton(
                        onClick = onMoviesClick,
                        modifier = Modifier
                            .scale(moviesSeeAllScale)
                            .border(
                                width = if (moviesSeeAllFocused) 1.dp else 0.dp,
                                color = if (moviesSeeAllFocused) Color.Red else Color.Transparent,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .onFocusChanged { moviesSeeAllFocused = it.isFocused }
                    ) {
                        Text("See All", color = Color.Red)
                        Icon(Icons.Filled.ChevronRight, null, tint = Color.Red)
                    }
                }

                if (recentMovies.isEmpty()) {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(5) {
                            Box(
                                Modifier
                                    .width(140.dp).height(200.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF1E1E1E))
                                    .border(1.dp, Color(0xFF333333), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.Red, strokeWidth = 2.dp)
                            }
                        }
                    }
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(recentMovies.take(20), key = { it.id }) { movie ->
                            HomeMovieCard(
                                movie = movie,
                                onClick = { onMovieClick(movie) },
                                onPlayClick = { onMoviePlayClick(movie) }
                            )
                        }
                    }
                }
            }

            // Series preview row
            item {
                val allSeries by seriesViewModel.allSeries.collectAsState()
                LaunchedEffect(Unit) { if (allSeries.isEmpty()) seriesViewModel.loadAllSeries() }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("📺 Series", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    var seriesSeeAllFocused by remember { mutableStateOf(false) }
                    val seriesSeeAllScale by animateFloatAsState(if (seriesSeeAllFocused) 1.05f else 1f, tween(150))
                    TextButton(
                        onClick = onSeriesClick,
                        modifier = Modifier
                            .scale(seriesSeeAllScale)
                            .border(
                                width = if (seriesSeeAllFocused) 1.dp else 0.dp,
                                color = if (seriesSeeAllFocused) Color(0xFF9C27B0) else Color.Transparent,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .onFocusChanged { seriesSeeAllFocused = it.isFocused }
                    ) {
                        Text("See All", color = Color(0xFF9C27B0))
                        Icon(Icons.Filled.ChevronRight, null, tint = Color(0xFF9C27B0))
                    }
                }

                if (allSeries.isEmpty()) {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(5) {
                            Box(
                                Modifier
                                    .width(140.dp).height(200.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF1E1E1E))
                                    .border(1.dp, Color(0xFF333333), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color(0xFF9C27B0), strokeWidth = 2.dp)
                            }
                        }
                    }
                } else {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(allSeries.take(20), key = { it.id }) { series ->
                            HomeSeriesCard(series = series, onClick = { onSeriesItemClick(series) })
                        }
                    }
                }
            }
        }
    }

    // ───────────────────── Channel Row ─────────────────────
    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    fun ChannelRow(
        channels: List<Channel>,
        channelColor: Color,
        sourceName: String,
        isEnabled: Boolean
    ) {
        if (channels.isEmpty()) return

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.height(160.dp)
        ) {
            itemsIndexed(channels) { index, channel ->
                var isFocused by remember { mutableStateOf(false) }

                val scale by animateFloatAsState(if (isFocused) 1.15f else 1f, tween(150))
                val borderColor by animateColorAsState(
                    when {
                        isFocused -> Color.Red
                        isEnabled -> channelColor.copy(alpha = 0.3f)
                        else -> Color.Gray.copy(alpha = 0.2f)
                    }, tween(150)
                )
                val backgroundColor by animateColorAsState(
                    when {
                        isFocused -> Color(0xFF2A2A2A)
                        isEnabled -> Color(0xFF1A1A1A)
                        else -> Color(0xFF111111)
                    }, tween(150)
                )

                Column(
                    Modifier
                        .width(110.dp)
                        .scale(scale)
                        .onFocusChanged { focusState -> isFocused = focusState.isFocused }
                        // ❌ Removed .focusable() – combinedClickable handles focus
                        .combinedClickable(
                            onClick = { if (isEnabled) launchPlayer(index, channels) },
                            onLongClick = null,
                            onDoubleClick = null
                        )
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(90.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(backgroundColor)
                            .border(if (isFocused) 4.dp else 1.dp, borderColor, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!channel.logo.isNullOrEmpty() && channel.logo.startsWith("http")) {
                            AsyncImage(
                                model = channel.logo,
                                contentDescription = channel.name,
                                modifier = Modifier.fillMaxSize().padding(8.dp),
                                contentScale = ContentScale.Fit,
                                alpha = if (isEnabled) 1f else 0.5f
                            )
                        } else {
                            Text(
                                channel.name.take(3),
                                color = when {
                                    isFocused -> Color.White
                                    isEnabled -> channelColor
                                    else -> Color.Gray
                                },
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (isFocused && isEnabled) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        Brush.verticalGradient(listOf(Color.Transparent, Color.Red.copy(alpha = 0.7f)))
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Filled.PlayCircle, "Play", tint = Color.White, modifier = Modifier.size(36.dp))
                                    Text("WATCH", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Text(
                        channel.name,
                        color = when {
                            isFocused -> Color.White
                            isEnabled -> Color.Gray
                            else -> Color.DarkGray
                        },
                        fontSize = if (isFocused) 11.sp else 10.sp,
                        fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                    )
                }
            }
        }
    }

    @Composable
    fun TopNavItem(title: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
        var isFocused by remember { mutableStateOf(false) }

        val backgroundColor by animateColorAsState(
            when {
                isFocused -> Color.Red.copy(alpha = 0.3f)
                selected -> Color.Red
                else -> Color.Transparent
            }, tween(150)
        )

        val borderColor by animateColorAsState(if (isFocused) Color.Red else Color.Transparent, tween(150))

        Box(
            modifier = Modifier
                .size(48.dp)
                .background(backgroundColor, RoundedCornerShape(8.dp))
                .border(if (isFocused) 2.dp else 0.dp, borderColor, RoundedCornerShape(8.dp))
                .onFocusChanged { isFocused = it.isFocused }
                .clickable { onClick() },  // ❌ Removed .focusable()
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, title, tint = when {
                isFocused -> Color.White
                selected -> Color.White
                else -> Color.Gray
            }, modifier = Modifier.size(24.dp))
        }
    }

    // ───────────────────── Full Grid Content ─────────────────────
    @Composable
    fun FullGridContent(title: String, channels: List<Channel>) {
        Column {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(16.dp))
            if (channels.isEmpty()) {
                Box(Modifier.fillMaxSize(), Alignment.Center) { Text("No channels available", color = Color.Gray) }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 150.dp),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(channels) { index, channel ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1E1E1E))
                                .clickable { launchPlayer(index, channels) },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(16f / 9f)
                                    .background(Color(0xFF0A0A0A)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (!channel.logo.isNullOrEmpty() && channel.logo.startsWith("http")) {
                                    AsyncImage(
                                        model = channel.logo,
                                        contentDescription = channel.name,
                                        modifier = Modifier.fillMaxSize().padding(8.dp),
                                        contentScale = ContentScale.Fit
                                    )
                                } else {
                                    Text(channel.name.take(2), color = Color.White, fontSize = 20.sp)
                                }
                            }
                            Text(channel.name, color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                            Text("${channel.urls.size} servers • ${channel.source}", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.padding(bottom = 8.dp))
                        }
                    }
                }
            }
        }
    }

    // ───────────────────── Helpers (unchanged) ─────────────────────
    private fun launchPlayer(index: Int, list: List<Channel>) {
        getSharedPreferences("TV_DATA", MODE_PRIVATE).edit().putInt("last_channel_index", index).apply()
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra("CHANNEL_INDEX", index)
            putParcelableArrayListExtra("CHANNEL_LIST", ArrayList(list))
        })
    }

    @OptIn(UnstableApi::class)
    private fun launchMoviePlayer(movie: Movie, streamUrl: StreamUrl? = null) {
        val downloadManager = DownloadManager.getInstance(this)
        val allDownloads = downloadManager.getAllDownloads()
        val completedDownload = allDownloads.find { it.movieId == movie.id && it.status == com.shimulfp.bdixlivetv.models.DownloadStatus.COMPLETED }

        if (completedDownload != null && completedDownload.filePath != null) {
            val file = java.io.File(completedDownload.filePath)
            if (file.exists()) {
                try {
                    val uri = androidx.core.content.FileProvider.getUriForFile(
                        this,
                        "${this.packageName}.fileprovider",
                        file
                    )
                    startActivity(Intent(this, MoviePlayerActivity::class.java).apply {
                        putExtra("MOVIE_ID", movie.id)
                        putExtra("MOVIE_TITLE", movie.title)
                        putExtra("MOVIE_URL", uri.toString())
                        putExtra("MOVIE_QUALITY", "Offline")
                        putExtra("MOVIE_POSTER", movie.poster)
                        putParcelableArrayListExtra("STREAM_URLS", ArrayList(movie.streamUrls))
                        flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                    })
                    return
                } catch (e: Exception) {
                    Log.w("MOVIE_PLAYER", "FileProvider failed, trying fallback: ${e.message}")
                    val oldPolicy = android.os.StrictMode.getVmPolicy()
                    try {
                        android.os.StrictMode.setVmPolicy(android.os.StrictMode.VmPolicy.Builder().build())
                        val fileUri = android.net.Uri.fromFile(file)
                        startActivity(Intent(this, MoviePlayerActivity::class.java).apply {
                            putExtra("MOVIE_ID", movie.id)
                            putExtra("MOVIE_TITLE", movie.title)
                            putExtra("MOVIE_URL", fileUri.toString())
                            putExtra("MOVIE_QUALITY", "Offline")
                            putExtra("MOVIE_POSTER", movie.poster)
                            putParcelableArrayListExtra("STREAM_URLS", ArrayList(movie.streamUrls))
                        })
                        return
                    } finally {
                        android.os.StrictMode.setVmPolicy(oldPolicy)
                    }
                }
            }
        }

        val url = streamUrl?.url ?: movie.getBestStreamUrl() ?: return

        startActivity(Intent(this, MoviePlayerActivity::class.java).apply {
            putExtra("MOVIE_ID", movie.id)
            putExtra("MOVIE_TITLE", movie.title)
            putExtra("MOVIE_URL", url)
            putExtra("MOVIE_QUALITY", streamUrl?.quality ?: movie.quality)
            putExtra("MOVIE_POSTER", movie.poster)
            putParcelableArrayListExtra("STREAM_URLS", ArrayList(movie.streamUrls))
        })
    }

    fun playSeriesEpisode(episode: Episode, series: Series) {
        val intent = Intent(this, MoviePlayerActivity::class.java).apply {
            putExtra("ALL_EPISODES", gson.toJson(series.seasons.flatMap { it.episodes }))
            putExtra("IS_SERIES", true)
            putExtra("SERIES_ID", series.id)
            putExtra("SERIES_TITLE", series.title)
            putExtra("SEASON_NUMBER", episode.seasonNumber)
            putExtra("EPISODE_NUMBER", episode.episodeNumber)
            putExtra("MOVIE_URL", episode.getBestStreamUrl())
            putExtra("MOVIE_QUALITY", episode.quality)
            putExtra("MOVIE_POSTER", series.poster)
            putExtra("SERIES_POSTER", series.poster)
        }
        startActivity(intent)
    }

    private fun playLastWatched(context: Context, channels: List<Channel>) {
        if (channels.isEmpty()) return
        val lastIndex = getSharedPreferences("TV_DATA", MODE_PRIVATE).getInt("last_channel_index", 0)
        val safeIndex = if (lastIndex < channels.size) lastIndex else 0
        launchPlayer(safeIndex, channels)
    }

    private fun formatTimeAgo(timestamp: Long): String {
        val diff = System.currentTimeMillis() - timestamp
        val minutes = diff / (60 * 1000)
        val hours = diff / (60 * 60 * 1000)
        val days = diff / (24 * 60 * 60 * 1000)
        return when {
            days > 0 -> "${days}d ago"
            hours > 0 -> "${hours}h ago"
            minutes > 0 -> "${minutes}m ago"
            else -> "Just now"
        }
    }

    @Composable
    fun ContinueWatchingSection(
        movieViewModel: MovieViewModel,
        seriesViewModel: SeriesViewModel,
        onMovieClick: (Movie) -> Unit,
        onMoviePlayClick: (Movie) -> Unit,
        onSeriesItemClick: (Series) -> Unit
    ) {
        val context = LocalContext.current
        var continueWatchingEntries by remember { mutableStateOf<List<com.shimulfp.bdixlivetv.data.MovieRepository.ContinueWatchingEntry>>(emptyList()) }
        var isLoading by remember { mutableStateOf(true) }

        LaunchedEffect(Unit) {
            isLoading = true
            try {
                val repo = com.shimulfp.bdixlivetv.data.MovieRepository.getInstance(context)
                val entries = repo.getContinueWatchingEpisodes()
                val allSeries = seriesViewModel.allSeries.value
                entries.forEach { entry ->
                    if (entry.type == com.shimulfp.bdixlivetv.data.MovieRepository.ContinueWatchingType.SERIES_EPISODE) {
                        val series = allSeries.find { it.id == entry.seriesId }
                        series?.let {
                            entry.poster = it.poster
                            entry.title = it.title
                        }
                    }
                }
                continueWatchingEntries = entries
            } catch (e: Exception) {
                Log.e("CONTINUE_WATCHING", "Error: ${e.message}", e)
            } finally {
                isLoading = false
            }
        }

        if (isLoading) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .background(Color(0xFF1A1A1A), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center), color = Color.Red)
            }
        } else if (continueWatchingEntries.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.PlayCircle, null, tint = Color.Red, modifier = Modifier.size(24.dp))
                        Text("Continue Watching", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("(${continueWatchingEntries.size})", color = Color.Gray, fontSize = 14.sp)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(continueWatchingEntries, key = { it.id }) { entry ->
                        ContinueWatchingCard(
                            entry = entry,
                            onClick = {
                                when (entry.type) {
                                    com.shimulfp.bdixlivetv.data.MovieRepository.ContinueWatchingType.MOVIE -> {
                                        entry.movie?.let { onMovieClick(it) }
                                    }
                                    com.shimulfp.bdixlivetv.data.MovieRepository.ContinueWatchingType.SERIES_EPISODE -> {
                                        val allSeries = seriesViewModel.allSeries.value
                                        val series = allSeries.find { it.id == entry.seriesId }
                                        if (series != null) {
                                            val episode = series.seasons
                                                .flatMap { it.episodes }
                                                .find { it.seasonNumber == entry.seasonNumber && it.episodeNumber == entry.episodeNumber }
                                            if (episode != null) {
                                                playSeriesEpisode(episode, series)
                                            }
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    @Composable
    fun ContinueWatchingCard(
        entry: com.shimulfp.bdixlivetv.data.MovieRepository.ContinueWatchingEntry,
        onClick: () -> Unit
    ) {
        var isFocused by remember { mutableStateOf(false) }

        Card(
            onClick = onClick,
            modifier = Modifier
                .width(180.dp)
                .onFocusChanged { isFocused = it.isFocused }
                .then(if (isFocused) Modifier.border(3.dp, Color.Red, RoundedCornerShape(12.dp)) else Modifier),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = if (isFocused) Color(0xFF2A2A2A) else Color(0xFF1A1A1A))
        ) {
            Box {
                if (!entry.poster.isNullOrEmpty()) {
                    AsyncImage(
                        model = entry.poster,
                        contentDescription = entry.title,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .background(
                                when (entry.type) {
                                    com.shimulfp.bdixlivetv.data.MovieRepository.ContinueWatchingType.MOVIE -> Color(0xFFE91E63)
                                    com.shimulfp.bdixlivetv.data.MovieRepository.ContinueWatchingType.SERIES_EPISODE -> Color(0xFF9C27B0)
                                },
                                RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            when (entry.type) {
                                com.shimulfp.bdixlivetv.data.MovieRepository.ContinueWatchingType.MOVIE -> Icons.Filled.Movie
                                com.shimulfp.bdixlivetv.data.MovieRepository.ContinueWatchingType.SERIES_EPISODE -> Icons.Filled.LiveTv
                            },
                            null,
                            tint = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.size(48.dp)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(80.dp)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                                )
                            )
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Spacer(modifier = Modifier.weight(1f))
                        Box(Modifier.fillMaxWidth().height(4.dp).background(Color.White.copy(alpha = 0.3f), RoundedCornerShape(2.dp))) {
                            Box(Modifier.fillMaxWidth(entry.progress.coerceIn(0f, 1f)).height(4.dp).background(Color.Red, RoundedCornerShape(2.dp)))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Surface(
                                color = when (entry.type) {
                                    com.shimulfp.bdixlivetv.data.MovieRepository.ContinueWatchingType.MOVIE -> Color.Red
                                    com.shimulfp.bdixlivetv.data.MovieRepository.ContinueWatchingType.SERIES_EPISODE -> Color(0xFF9C27B0)
                                },
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    if (entry.type == com.shimulfp.bdixlivetv.data.MovieRepository.ContinueWatchingType.MOVIE) "MOVIE" else "S${String.format("%02d", entry.seasonNumber)}-E${String.format("%02d", entry.episodeNumber)}",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                entry.title,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                if (isFocused) {
                    Box(Modifier.matchParentSize().border(3.dp, Color.Red, RoundedCornerShape(12.dp)))
                }
            }
        }
    }

    private suspend fun manualRefresh(
        context: Context,
        allChannels: List<Channel>,
        bdixChannels: List<Channel>,
        aynaChannels: List<Channel>
    ) {
        val firebaseManager = FirebaseManager(context)
        var username = firebaseManager.getAynaUsername()
        var password = firebaseManager.getAynaPassword()
        if (username == null || password == null || password!!.isEmpty()) {
            username = "username@email.com"
            password = ""
        }
        ChannelCacheManager.manualRefresh(context, username, password)
    }

    private suspend fun manualGitHubSync(context: Context) {
        val firebaseManager = FirebaseManager(context)
        val token = firebaseManager.getGitHubToken()
        if (token.isNotEmpty()) {
            GitHubDataManager.initialize(token)
            val result = GitHubDataManager.checkAndSyncData(context)
            saveSyncLog(context, result)
        }
    }

    private fun saveSyncLog(context: Context, result: GitHubDataManager.SyncResult) {
        try {
            val logFile = File(context.filesDir, "github_sync_log.json")
            val log = JSONObject().apply {
                put("last_sync_time", System.currentTimeMillis())
                put("last_sync_date", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))
                val resultType = when (result) {
                    is GitHubDataManager.SyncResult.Downloaded -> "DOWNLOADED"
                    is GitHubDataManager.SyncResult.ScrapedAndUploaded -> "SCRAPED_UPLOADED"
                    is GitHubDataManager.SyncResult.ScrapedOnly -> "SCRAPED_ONLY"
                    is GitHubDataManager.SyncResult.ScrapingFailed -> "SCRAPING_FAILED"
                    is GitHubDataManager.SyncResult.Error -> "ERROR"
                    else -> "OTHER"
                }
                put("last_result", resultType)
            }
            logFile.writeText(log.toString())
        } catch (e: Exception) {
            Log.e("SYNC_LOG", "Error saving log: ${e.message}")
        }
    }
}
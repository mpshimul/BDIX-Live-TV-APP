package com.shimulfp.bdixlivetv

import android.app.Application
import android.content.Context
import android.util.Log
//import androidx.databinding.tool.Context
import kotlinx.coroutines.*
import java.io.File
import com.google.gson.Gson

class BDIXApplication : Application() {
    private val TAG = "BDIXApplication"
    private val gson = Gson()

    companion object {
        lateinit var instance: BDIXApplication
            private set

        fun getAppContext() = instance.applicationContext
    }

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()

        // In your MainActivity.onCreate() or Application.onCreate():
        val firebaseManager = FirebaseManager(this)
        val githubToken = firebaseManager.getGitHubToken()

        if (githubToken.isNotEmpty()) {
            // Initialize GitHubDataManager with the token
            GitHubDataManager.initialize(githubToken)

            // Also save it locally for MovieRepository
            val prefs = getSharedPreferences("github_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString("github_token", githubToken).apply()

            Log.d("MainActivity", "✅ GitHub token initialized: ${githubToken.take(5)}...")
        } else {
            Log.w("MainActivity", "⚠️ No GitHub token in Firebase")
        }

        instance = this

        Log.d(TAG, "🚀 BDIX Application starting...")

        // Clean up any old stop flags on startup
        cleanUpStopFlags()

        // Initialize Firebase
        FirebaseSetupHelper.initializeFirebase(this)

        // Schedule background sync (works even when app is closed)
        scheduleBackgroundSync()

        Log.d(TAG, "✅ BDIX Application started - GitHub-first strategy enabled")
    }

    /**
     * Schedule background sync using WorkManager
     * This ensures sync continues even when the app is closed or in background
     */
    private fun scheduleBackgroundSync() {
        try {
            val firebaseManager = FirebaseManager(this)
            val githubToken = firebaseManager.getGitHubToken()

            if (githubToken.isEmpty()) {
                Log.w(TAG, "⚠️ No GitHub token, background sync not scheduled")
                return
            }

            // Check if background sync is enabled in settings
            if (!BackgroundSyncSettings.isEnabled(this)) {
                Log.d(TAG, "⏭ Background sync disabled in settings")
                return
            }

            // Schedule periodic background sync
            val intervalMinutes = BackgroundSyncSettings.getSyncIntervalMinutes(this)
            BackgroundSyncManager.scheduleBackgroundSync(
                context = this,
                intervalMinutes = intervalMinutes
            )

            val (isEnabled, nextRunTime) = BackgroundSyncManager.getSyncStatus(this)
            val nextSyncTime = if (nextRunTime > 0) {
                java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
                    .format(java.util.Date(nextRunTime))
            } else {
                "N/A"
            }

            Log.d(TAG, "✅ Background sync enabled: $isEnabled, next run: $nextSyncTime")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to schedule background sync: ${e.message}", e)
        }
    }

    /**
     * Clean up any old stop flags from previous sessions
     */
    private fun cleanUpStopFlags() {
        try {
            val stopFile = File(filesDir, "stop_scraping.flag")
            if (stopFile.exists()) {
                stopFile.delete()
                Log.d(TAG, "🧹 Cleaned up old stop flag")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error cleaning stop flags: ${e.message}")
        }
    }

    /**
     * Check if movie data needs refresh (conservative check)
     */
    private fun checkIfMovieDataNeedsRefresh(): Boolean {
        return try {
            // Check movie cache file only
            val cacheFile = File(filesDir, "movies_cache.json")

            if (!cacheFile.exists()) {
                Log.d(TAG, "No movie cache file, needs refresh")
                return true
            }

            val cacheAgeMinutes = (System.currentTimeMillis() - cacheFile.lastModified()) / (60 * 1000)
            val needsRefresh = cacheAgeMinutes > 360 // >6 hours (conservative)

            Log.d(TAG, "Movie cache age: ${cacheAgeMinutes}m, needs refresh: $needsRefresh")
            needsRefresh

        } catch (e: Exception) {
            Log.e(TAG, "Error checking if movie data needs refresh: ${e.message}")
            false // Don't trigger sync on error
        }
    }

    /**
     * Save movies to cache
     */
    private fun saveMoviesToCache(movies: List<com.shimulfp.bdixlivetv.models.Movie>) {
        try {
            val file = File(filesDir, "movies_cache.json")
            file.writeText(gson.toJson(movies))
            file.setLastModified(System.currentTimeMillis())
            Log.d(TAG, "💾 Saved ${movies.size} movies to cache")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving movies to cache: ${e.message}")
        }
    }

    /**
     * Save sync time with details
     */
    private fun saveMovieSyncTime(syncType: String, movieCount: Int) {
        try {
            val syncFile = File(filesDir, "movie_sync_status.json")
            val syncData = mapOf(
                "last_sync_time" to System.currentTimeMillis(),
                "last_sync_type" to syncType,
                "movie_count" to movieCount,
                "timestamp" to System.currentTimeMillis()
            )
            syncFile.writeText(gson.toJson(syncData))
            Log.d(TAG, "💾 Saved sync time: $syncType")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving sync time: ${e.message}")
        }
    }

    /**
     * Get sync status for UI
     */
    fun getSyncStatus(): String {
        return try {
            val syncFile = File(filesDir, "movie_sync_status.json")
            if (!syncFile.exists()) {
                return "Never synced"
            }

            val content = syncFile.readText()
            if (content.isBlank()) {
                return "No sync data"
            }

            val data = gson.fromJson(content, Map::class.java)
            val lastSyncTime = (data["last_sync_time"] as? Double)?.toLong() ?: 0L
            val syncType = data["last_sync_type"] as? String ?: "unknown"
            val movieCount = (data["movie_count"] as? Double)?.toInt() ?: 0

            if (lastSyncTime == 0L) {
                return "Never synced"
            }

            val hoursAgo = (System.currentTimeMillis() - lastSyncTime) / (1000 * 60 * 60)

            val status = when {
                hoursAgo < 1 -> "Synced <1 hour ago"
                hoursAgo < 2 -> "Synced $hoursAgo hours ago"
                else -> "Synced $hoursAgo hours ago"
            }

            "$status ($movieCount movies, via $syncType)"

        } catch (e: Exception) {
            "Error reading status"
        }
    }

    /**
     * Quick check if GitHub data is available
     */
    fun isGitHubDataAvailable(): Boolean {
        return try {
            val file = File(filesDir, "movies_cache.json")
            file.exists() && file.length() > 100000 // At least 100KB
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Get movie cache info for UI
     */
    fun getMovieCacheInfo(): String {
        return try {
            val file = File(filesDir, "movies_cache.json")
            if (!file.exists()) {
                return "No cache"
            }

            val sizeKB = file.length() / 1024
            val ageMinutes = (System.currentTimeMillis() - file.lastModified()) / (60 * 1000)
            val ageHours = ageMinutes / 60

            "$sizeKB KB, ${if (ageHours > 0) "${ageHours}h" else "${ageMinutes}m"} ago"
        } catch (e: Exception) {
            "Error"
        }
    }

    /**
     * Create stop flag file for Python scraper
     */
    private fun createStopFlag() {
        try {
            val stopFile = File(filesDir, "stop_scraping.flag")
            stopFile.writeText("STOP")
            Log.d(TAG, "🛑 Created stop flag for Python scraper")
        } catch (e: Exception) {
            Log.e(TAG, "Error creating stop flag: ${e.message}")
        }
    }

    /**
     * Remove stop flag file
     */
    fun removeStopFlag() {
        try {
            val stopFile = File(filesDir, "stop_scraping.flag")
            if (stopFile.exists()) {
                stopFile.delete()
                Log.d(TAG, "🧹 Removed stop flag")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error removing stop flag: ${e.message}")
        }
    }

    override fun onTerminate() {
        super.onTerminate()
        appScope.cancel()
        Log.d(TAG, "BDIX Application terminating")
    }
}
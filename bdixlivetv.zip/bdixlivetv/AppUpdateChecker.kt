package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Log
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shimulfp.bdixlivetv.models.AppUpdateInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class AppUpdateChecker(private val savedStateHandle: SavedStateHandle) : ViewModel() {
    private val TAG = "AppUpdateChecker"

    // State
    private val _updateInfo = MutableStateFlow<AppUpdateInfo?>(null)
    val updateInfo: StateFlow<AppUpdateInfo?> = _updateInfo.asStateFlow()

    private val _downloadState = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val downloadState: StateFlow<DownloadState> = _downloadState.asStateFlow()

    private val _showDialog = MutableStateFlow(false)
    val showDialog: StateFlow<Boolean> = _showDialog.asStateFlow()

    // Saved values
    private var currentDownloadId: Long
        get() = savedStateHandle.get<Long>("downloadId") ?: -1L
        set(value) = savedStateHandle.set("downloadId", value)

    private var downloadedVersionName: String?
        get() = savedStateHandle.get<String>("versionName")
        set(value) = savedStateHandle.set("versionName", value)

    private var lastCheckTime: Long
        get() = savedStateHandle.get<Long>("lastCheck") ?: 0L
        set(value) = savedStateHandle.set("lastCheck", value)

    private val CHECK_INTERVAL = TimeUnit.HOURS.toMillis(6)

    init {
        // If there's a saved download ID, restore downloading state
        if (currentDownloadId != -1L && downloadedVersionName != null) {
            _downloadState.value = DownloadState.Downloading(0f)
            // Start progress observer
            startProgressObserver()
        }
    }

    fun checkForUpdates(context: Context, force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && (now - lastCheckTime) < CHECK_INTERVAL) return

        viewModelScope.launch {
            lastCheckTime = now
            val info = AppUpdateManager.checkForUpdates(context)
            if (info != null) {
                _updateInfo.value = info
                _showDialog.value = true
                _downloadState.value = DownloadState.Idle
            } else {
                // No update
            }
        }
    }

    fun startDownload(context: Context) {
        val info = _updateInfo.value ?: return
        viewModelScope.launch {
            _downloadState.value = DownloadState.Downloading(0f)
            val id = AppUpdateManager.startDownload(context, info.downloadUrl, info.versionName)
            currentDownloadId = id
            downloadedVersionName = info.versionName

            // Register receiver for completion
            AppUpdateManager.registerDownloadReceiver(context) { success ->
                if (success) {
                    _downloadState.value = DownloadState.Downloaded
                } else {
                    _downloadState.value = DownloadState.Error("Download failed")
                    currentDownloadId = -1
                    downloadedVersionName = null
                }
            }

            // Start progress polling
            startProgressObserver(context)
        }
    }

    private fun startProgressObserver(context: Context? = null) {
        viewModelScope.launch {
            while (currentDownloadId != -1L && _downloadState.value is DownloadState.Downloading) {
                if (context != null) {
                    val progress = AppUpdateManager.getDownloadProgress(currentDownloadId, context)
                    if (progress != null) {
                        _downloadState.value = DownloadState.Downloading(progress)
                    }
                }
                delay(1000)
            }
        }
    }

    fun installDownloadedApk(context: Context) {
        val id = currentDownloadId
        if (id == -1L) return
        val uri = AppUpdateManager.getDownloadedFileUri(id, context)
        if (uri != null) {
            AppUpdateManager.installApk(context, uri)
        } else {
            _downloadState.value = DownloadState.Error("APK file not found")
        }
    }

    fun dismissDialog() {
        _showDialog.value = false
        // Optionally reset download state if not completed
        if (_downloadState.value !is DownloadState.Downloaded) {
            _downloadState.value = DownloadState.Idle
            currentDownloadId = -1
            downloadedVersionName = null
        }
    }

    fun reset() {
        _updateInfo.value = null
        _showDialog.value = false
        _downloadState.value = DownloadState.Idle
        currentDownloadId = -1
        downloadedVersionName = null
    }

    // Called when returning from permission settings – retry install if download complete
    fun onReturnFromSettings(context: Context) {
        if (_downloadState.value is DownloadState.Downloaded) {
            installDownloadedApk(context)
        }
    }
}

// Singleton wrapper for easy access (optional)
object UpdateChecker {
    private lateinit var viewModel: AppUpdateChecker

    fun initialize(savedStateHandle: SavedStateHandle) {
        viewModel = AppUpdateChecker(savedStateHandle)
    }

    val updateInfo: StateFlow<AppUpdateInfo?> get() = viewModel.updateInfo
    val downloadState: StateFlow<DownloadState> get() = viewModel.downloadState
    val showDialog: StateFlow<Boolean> get() = viewModel.showDialog

    fun checkForUpdates(context: Context, force: Boolean) = viewModel.checkForUpdates(context, force)
    fun startDownload(context: Context) = viewModel.startDownload(context)
    fun installDownloadedApk(context: Context) = viewModel.installDownloadedApk(context)
    fun dismissDialog() = viewModel.dismissDialog()
    fun onReturnFromSettings(context: Context) = viewModel.onReturnFromSettings(context)
}